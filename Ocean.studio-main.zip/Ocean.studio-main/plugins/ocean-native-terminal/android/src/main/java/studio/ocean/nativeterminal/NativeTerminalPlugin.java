package studio.ocean.nativeterminal;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.HashMap;
import java.util.Map;

@CapacitorPlugin(name = "OceanNativeTerminal")
public class NativeTerminalPlugin extends Plugin {
    private final Map<String, ShellSession> sessions = new HashMap<>();
    private OceanLinuxSetup linuxSetup;

    @Override
    public void load() {
        linuxSetup = new OceanLinuxSetup(getContext());
        if (!linuxSetup.isReady()) {
            linuxSetup.setup();
        }
    }

    @PluginMethod
    public void setup(PluginCall call) {
        OceanLinuxSetup.SetupResult result = linuxSetup.setup();
        JSObject ret = new JSObject();
        ret.put("ready", result.ready);
        ret.put("prefix", result.prefix);
        ret.put("shell", result.shell);
        ret.put("message", result.message);
        call.resolve(ret);
    }

    @PluginMethod
    public void getSetupStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("ready", linuxSetup.isReady());
        ret.put("prefix", linuxSetup.getPrefixDir().getAbsolutePath());
        ret.put("shell", linuxSetup.getShellPath());
        ret.put("message", linuxSetup.isReady() ? "Ready" : "Not set up");
        call.resolve(ret);
    }

    @PluginMethod
    public void create(PluginCall call) {
        String id = call.getString("id", "default");
        String cwd = call.getString("cwd", linuxSetup.getHomeDir().getAbsolutePath());

        if (sessions.containsKey(id)) {
            sessions.get(id).kill();
            sessions.remove(id);
        }

        try {
            ShellSession session = new ShellSession(id, linuxSetup, cwd, new ShellSession.Listener() {
                @Override
                public void onData(String data) {
                    JSObject event = new JSObject();
                    event.put("id", id);
                    event.put("data", data);
                    notifyListeners("terminalData", event);
                }

                @Override
                public void onExit(int code) {
                    JSObject event = new JSObject();
                    event.put("id", id);
                    event.put("code", code);
                    notifyListeners("terminalExit", event);
                    sessions.remove(id);
                }

                @Override
                public void onPortDetected(int port, String url) {
                    JSObject event = new JSObject();
                    event.put("port", port);
                    event.put("url", url);
                    notifyListeners("portDetected", event);
                }
            });
            session.start();
            sessions.put(id, session);
            call.resolve();
        } catch (Exception e) {
            call.reject("Failed to create native terminal: " + e.getMessage());
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        String id = call.getString("id");
        String data = call.getString("data", "");
        ShellSession session = sessions.get(id);
        if (session == null) {
            call.reject("Session not found: " + id);
            return;
        }
        session.write(data);
        call.resolve();
    }

    @PluginMethod
    public void resize(PluginCall call) {
        String id = call.getString("id");
        int cols = call.getInt("cols", 80);
        int rows = call.getInt("rows", 24);
        ShellSession session = sessions.get(id);
        if (session != null) session.resize(cols, rows);
        call.resolve();
    }

    @PluginMethod
    public void kill(PluginCall call) {
        String id = call.getString("id");
        ShellSession session = sessions.remove(id);
        if (session != null) session.kill();
        call.resolve();
    }

    @PluginMethod
    public void restart(PluginCall call) {
        String id = call.getString("id");
        ShellSession old = sessions.remove(id);
        if (old != null) old.kill();
        create(call);
    }

    @PluginMethod
    public void clear(PluginCall call) {
        String id = call.getString("id");
        ShellSession session = sessions.get(id);
        if (session != null) session.clear();
        call.resolve();
    }
}
