export type TerminalType = 'shell' | 'cloud' | 'native';

export interface CreateOptions {
  id: string;
  cwd?: string;
}

export interface WriteOptions {
  id: string;
  data: string;
}

export interface ResizeOptions {
  id: string;
  cols: number;
  rows: number;
}

export interface SessionOptions {
  id: string;
}

export interface SetupStatus {
  ready: boolean;
  prefix: string;
  shell: string;
  message: string;
}

export interface OceanNativeTerminalPlugin {
  setup(): Promise<SetupStatus>;
  getSetupStatus(): Promise<SetupStatus>;
  create(options: CreateOptions): Promise<void>;
  write(options: WriteOptions): Promise<void>;
  resize(options: ResizeOptions): Promise<void>;
  kill(options: SessionOptions): Promise<void>;
  restart(options: SessionOptions): Promise<void>;
  clear(options: SessionOptions): Promise<void>;
  addListener(
    eventName: 'terminalData',
    listenerFunc: (event: { id: string; data: string }) => void
  ): Promise<{ remove: () => void }>;
  addListener(
    eventName: 'terminalExit',
    listenerFunc: (event: { id: string; code: number }) => void
  ): Promise<{ remove: () => void }>;
  addListener(
    eventName: 'portDetected',
    listenerFunc: (event: { port: number; url: string }) => void
  ): Promise<{ remove: () => void }>;
}
