import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';

function oceanFsApiPlugin(): Plugin {
  const workspaceRoot = process.cwd();
  return {
    name: 'ocean-fs-api',
    configureServer(server) {
      server.middlewares.use('/api/fs/list', (req, res) => {
        const url = new URL(req.url ?? '', 'http://localhost');
        const target = url.searchParams.get('path') ?? workspaceRoot;
        try {
          const entries = fs.readdirSync(target, { withFileTypes: true }).map((d) => ({
            name: d.name,
            isDirectory: d.isDirectory(),
          }));
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(entries));
        } catch (err) {
          res.statusCode = 500;
          res.end(JSON.stringify({ error: err instanceof Error ? err.message : 'list failed' }));
        }
      });
      server.middlewares.use('/api/fs/read', (req, res) => {
        const url = new URL(req.url ?? '', 'http://localhost');
        const target = url.searchParams.get('path') ?? '';
        try {
          const content = fs.readFileSync(target, 'utf-8');
          res.setHeader('Content-Type', 'text/plain');
          res.end(content);
        } catch (err) {
          res.statusCode = 500;
          res.end(err instanceof Error ? err.message : 'read failed');
        }
      });
      server.middlewares.use('/api/fs/write', (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end('Method not allowed');
          return;
        }
        let body = '';
        req.on('data', (chunk) => { body += chunk; });
        req.on('end', () => {
          try {
            const { path: filePath, content } = JSON.parse(body) as { path: string; content: string };
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
            fs.writeFileSync(filePath, content, 'utf-8');
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ ok: true }));
          } catch (err) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: err instanceof Error ? err.message : 'write failed' }));
          }
        });
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), oceanFsApiPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    strictPort: true,
  },
  build: {
    outDir: 'dist',
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('marketplaceSeed')) return 'marketplace-seeds';
          if (id.includes('node_modules/@monaco-editor') || id.includes('node_modules/monaco-editor')) {
            return 'monaco';
          }
          if (id.includes('node_modules/firebase')) return 'firebase';
          if (id.includes('node_modules/framer-motion')) return 'motion';
          if (id.includes('skills/builtinCatalog')) return 'skills-builtin';
          if (id.includes('extensions/builtinCatalog')) return 'extensions-builtin';
        },
      },
    },
  },
});
