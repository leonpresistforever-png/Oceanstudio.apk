import { spawn } from 'child_process';
import { existsSync } from 'fs';
import os from 'os';

export type SandboxRuntime = 'host' | 'docker' | 'docker-socket';

export interface SandboxMount {
  host: string;
  container: string;
  mode?: 'ro' | 'rw';
}

export interface SandboxDockerConfig {
  image: string;
  entrypoint?: string[];
  cmd?: string[];
  mounts?: SandboxMount[];
  network?: 'bridge' | 'host' | 'none' | 'isolated';
  memory?: string;
  cpus?: string;
  readOnlyRootfs?: boolean;
  user?: string;
  workdir?: string;
  extraRunArgs?: string[];
  mountDockerSocket?: boolean;
}

export interface SandboxInitCommand {
  command: string;
  args?: string[];
  description?: string;
  optional?: boolean;
}

export interface SandboxSpawnInput {
  runtime: SandboxRuntime;
  command?: string;
  args?: string[];
  docker?: SandboxDockerConfig;
  env?: Record<string, string>;
}

export interface ResolvedSpawn {
  command: string;
  args: string[];
  env: Record<string, string>;
}

const DOCKER_SOCKET = process.platform === 'win32'
  ? '//var/run/docker.sock'
  : '/var/run/docker.sock';

function expandHome(p: string): string {
  if (p.startsWith('~/')) return `${os.homedir()}${p.slice(1)}`;
  if (p === '~') return os.homedir();
  return p;
}

export function resolveSandboxSpawn(input: SandboxSpawnInput): ResolvedSpawn {
  const env = { ...input.env };
  if (input.runtime === 'host') {
    if (!input.command) throw new Error('Host runtime requires command');
    return { command: input.command, args: input.args ?? [], env };
  }

  const docker = input.docker;
  if (!docker?.image) throw new Error('Docker runtime requires image');

  const runArgs: string[] = ['run', '-i', '--rm'];
  const network = docker.network ?? (input.runtime === 'docker-socket' ? 'bridge' : 'bridge');
  if (network === 'isolated' || network === 'none') {
    runArgs.push('--network', 'none');
  } else if (network === 'host') {
    runArgs.push('--network', 'host');
  }

  if (docker.memory) runArgs.push('--memory', docker.memory);
  if (docker.cpus) runArgs.push('--cpus', docker.cpus);
  if (docker.readOnlyRootfs) runArgs.push('--read-only');
  if (docker.user) runArgs.push('--user', docker.user);
  if (docker.workdir) runArgs.push('--workdir', docker.workdir);

  const mounts = [...(docker.mounts ?? [])];
  if (input.runtime === 'docker-socket' || docker.mountDockerSocket) {
    if (existsSync(DOCKER_SOCKET) || process.platform === 'win32') {
      mounts.push({ host: DOCKER_SOCKET, container: '/var/run/docker.sock', mode: 'rw' });
    }
  }

  for (const m of mounts) {
    const host = expandHome(m.host);
    const mode = m.mode === 'ro' ? ':ro' : '';
    runArgs.push('-v', `${host}:${m.container}${mode}`);
  }

  for (const [k, v] of Object.entries(env)) {
    runArgs.push('-e', `${k}=${v}`);
  }

  if (docker.extraRunArgs?.length) runArgs.push(...docker.extraRunArgs);

  runArgs.push(docker.image);
  if (docker.entrypoint?.length) {
    runArgs.push(...docker.entrypoint);
  }
  if (docker.cmd?.length) {
    runArgs.push(...docker.cmd);
  } else if (input.args?.length) {
    runArgs.push(...input.args);
  }

  return { command: 'docker', args: runArgs, env: process.env as Record<string, string> };
}

export async function checkDockerAvailable(): Promise<{ ok: boolean; message: string; version?: string }> {
  return new Promise((resolve) => {
    const child = spawn('docker', ['version', '--format', '{{.Server.Version}}'], { shell: process.platform === 'win32' });
    let out = '';
    let err = '';
    child.stdout?.on('data', (d) => { out += d.toString(); });
    child.stderr?.on('data', (d) => { err += d.toString(); });
    child.on('close', (code) => {
      if (code === 0 && out.trim()) {
        resolve({ ok: true, message: 'Docker is running', version: out.trim() });
      } else {
        resolve({ ok: false, message: err.trim() || 'Docker is not available. Install Docker Desktop or docker engine.' });
      }
    });
    child.on('error', () => {
      resolve({ ok: false, message: 'Docker CLI not found. Install Docker to use sandbox MCP servers.' });
    });
  });
}

export async function runInitCommands(
  commands: SandboxInitCommand[],
  onLog?: (line: string) => void
): Promise<{ ok: boolean; message: string }> {
  for (const cmd of commands) {
    const ok = await new Promise<boolean>((resolve) => {
      const child = spawn(cmd.command, cmd.args ?? [], {
        shell: process.platform === 'win32',
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      child.stdout?.on('data', (d) => onLog?.(d.toString()));
      child.stderr?.on('data', (d) => onLog?.(d.toString()));
      child.on('close', (code) => resolve(code === 0));
      child.on('error', () => resolve(false));
    });
    if (!ok && !cmd.optional) {
      return { ok: false, message: `Init failed: ${cmd.command} ${(cmd.args ?? []).join(' ')}` };
    }
  }
  return { ok: true, message: 'Init complete' };
}
