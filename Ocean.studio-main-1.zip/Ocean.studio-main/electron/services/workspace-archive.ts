import fs from 'fs/promises';
import { existsSync, statSync } from 'fs';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'dist-electron', 'release']);

async function collectFiles(dir: string, base = dir): Promise<{ rel: string; abs: string }[]> {
  const out: { rel: string; abs: string }[] = [];
  if (!existsSync(dir)) return out;
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    if (e.name.startsWith('.') && e.name !== '.env' && e.name !== '.ocean') continue;
    if (e.isDirectory() && SKIP_DIRS.has(e.name)) continue;
    const abs = path.join(dir, e.name);
    const rel = path.relative(base, abs);
    if (e.isDirectory()) {
      out.push(...(await collectFiles(abs, base)));
    } else {
      const st = statSync(abs);
      if (st.size < 50 * 1024 * 1024) out.push({ rel, abs });
    }
  }
  return out;
}

export async function exportWorkspaceZip(
  workspacePath: string,
  destPath: string,
  compressionLevel = 6,
): Promise<{ ok: true; path: string; fileCount: number } | { ok: false; error: string }> {
  try {
    const files = await collectFiles(workspacePath);
    if (process.platform === 'win32') {
      const tempDir = path.join(path.dirname(destPath), `.ocean-export-${Date.now()}`);
      await fs.mkdir(tempDir, { recursive: true });
      for (const f of files) {
        const dest = path.join(tempDir, f.rel);
        await fs.mkdir(path.dirname(dest), { recursive: true });
        await fs.copyFile(f.abs, dest);
      }
      if (existsSync(destPath)) await fs.unlink(destPath);
      await execFileAsync('powershell', [
        '-Command',
        `Compress-Archive -Path '${tempDir.replace(/'/g, "''")}\\*' -DestinationPath '${destPath.replace(/'/g, "''")}' -CompressionLevel ${compressionLevel >= 7 ? 'Optimal' : 'Fastest'}`,
      ]);
      await fs.rm(tempDir, { recursive: true, force: true });
      return { ok: true, path: destPath, fileCount: files.length };
    }
    const excludes = ['node_modules/*', '.git/*', 'dist/*', 'dist-electron/*', 'release/*'];
    const args = ['-r', destPath, '.', ...excludes.flatMap((x) => ['-x', x])];
    if (compressionLevel >= 7) args.splice(1, 0, '-9');
    await execFileAsync('zip', args, { cwd: workspacePath });
    return { ok: true, path: destPath, fileCount: files.length };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function exportWorkspaceTarGz(
  workspacePath: string,
  destPath: string,
): Promise<{ ok: true; path: string; fileCount: number } | { ok: false; error: string }> {
  try {
    const files = await collectFiles(workspacePath);
    if (process.platform === 'win32') {
      return exportWorkspaceZip(workspacePath, destPath.replace(/\.tar\.gz$/, '.zip'), 6);
    }
    await execFileAsync('tar', [
      '-czf', destPath,
      '--exclude=node_modules', '--exclude=.git', '--exclude=dist',
      '--exclude=dist-electron', '--exclude=release',
      '-C', workspacePath, '.',
    ]);
    return { ok: true, path: destPath, fileCount: files.length };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function importZipToWorkspace(
  zipPath: string,
  workspacePath: string,
): Promise<{ ok: true; extracted: number } | { ok: false; error: string }> {
  try {
    if (process.platform === 'win32') {
      await execFileAsync('powershell', [
        '-Command',
        `Expand-Archive -Path '${zipPath.replace(/'/g, "''")}' -DestinationPath '${workspacePath.replace(/'/g, "''")}' -Force`,
      ]);
      return { ok: true, extracted: 1 };
    }
    await execFileAsync('unzip', ['-o', zipPath, '-d', workspacePath]);
    return { ok: true, extracted: 1 };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function copyFolderToWorkspace(
  sourceDir: string,
  workspacePath: string,
  subfolder?: string,
): Promise<number> {
  const destRoot = subfolder ? path.join(workspacePath, subfolder) : workspacePath;
  const files = await collectFiles(sourceDir);
  let copied = 0;
  for (const f of files) {
    const dest = path.join(destRoot, f.rel);
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.copyFile(f.abs, dest);
    copied++;
  }
  return copied;
}

export async function writeUploadedFiles(
  workspacePath: string,
  files: { name: string; contentBase64: string; relativePath?: string }[],
): Promise<number> {
  let written = 0;
  for (const f of files) {
    const rel = f.relativePath ?? f.name;
    const dest = path.join(workspacePath, rel);
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.writeFile(dest, Buffer.from(f.contentBase64, 'base64'));
    written++;
  }
  return written;
}

export async function exportWorkspaceJsonManifest(workspacePath: string): Promise<string> {
  const files = await collectFiles(workspacePath);
  const manifest: { path: string; size: number }[] = [];
  for (const f of files) {
    manifest.push({ path: f.rel.replace(/\\/g, '/'), size: statSync(f.abs).size });
  }
  return JSON.stringify({ workspace: workspacePath, exportedAt: new Date().toISOString(), files: manifest }, null, 2);
}
