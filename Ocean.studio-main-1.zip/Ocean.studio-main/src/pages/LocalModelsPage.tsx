import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, Download, Star, Play, Trash2, Settings, Cpu, HardDrive, Check } from 'lucide-react';
import { useAppStore } from '../store/appStore';
import { useLocalModelsStore } from '../store/localModelsStore';
import {
  LOCAL_MODEL_CATALOG,
  LOCAL_MODEL_PURPOSES,
  type LocalModelPurpose,
  type LocalModelDefinition,
} from '../models/localCatalog';
import { getOceanAPI } from '../lib/platform';
import { useModelStore } from '../store/modelStore';
import '../pages/LocalModelsPage.css';

export default function LocalModelsPage() {
  const setCenterView = useAppStore((s) => s.setCenterView);
  const addAgentLog = useAppStore((s) => s.addAgentLog);
  const workspacePath = useAppStore((s) => s.workspacePath);

  const runtime = useLocalModelsStore((s) => s.runtime);
  const setRuntime = useLocalModelsStore((s) => s.setRuntime);
  const installed = useLocalModelsStore((s) => s.installed);
  const favorites = useLocalModelsStore((s) => s.favorites);
  const activeModelId = useLocalModelsStore((s) => s.activeModelId);
  const setActiveModel = useLocalModelsStore((s) => s.setActiveModel);
  const toggleFavorite = useLocalModelsStore((s) => s.toggleFavorite);
  const markInstalled = useLocalModelsStore((s) => s.markInstalled);
  const markDownloading = useLocalModelsStore((s) => s.markDownloading);
  const markError = useLocalModelsStore((s) => s.markError);
  const removeInstalled = useLocalModelsStore((s) => s.removeInstalled);
  const isInstalled = useLocalModelsStore((s) => s.isInstalled);
  const downloadQueue = useLocalModelsStore((s) => s.downloadQueue);

  const addCustomModel = useModelStore((s) => s.addCustomModel);

  const [search, setSearch] = useState('');
  const [purpose, setPurpose] = useState<LocalModelPurpose | 'all'>('all');
  const [showConfig, setShowConfig] = useState(false);

  const filtered = LOCAL_MODEL_CATALOG.filter((m) => {
    if (purpose !== 'all' && m.purpose !== purpose) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return `${m.name} ${m.tag} ${m.description} ${m.purpose}`.toLowerCase().includes(q);
  });

  const pullModel = useCallback(async (model: LocalModelDefinition) => {
    markDownloading(model.id);
    addAgentLog({
      id: crypto.randomUUID(),
      type: 'action',
      timestamp: Date.now(),
      summary: `Downloading ${model.tag}…`,
      status: 'running',
    });

    try {
      const api = getOceanAPI();
      const cmd = model.pullCommand;
      await api.terminal.create({ id: 'ocean-local-models', type: 'shell', cwd: workspacePath || undefined });
      api.terminal.write('ocean-local-models', `${cmd}\n`);

      setTimeout(() => {
        markInstalled(model);
        addCustomModel({
          id: model.id,
          name: model.name,
          provider: 'custom',
          description: `${model.description} (local/Ollama)`,
          contextWindow: model.contextWindow,
          isCustom: true,
        });
        addAgentLog({
          id: crypto.randomUUID(),
          type: 'result',
          timestamp: Date.now(),
          summary: `Installed ${model.name} — free forever on your hardware`,
          status: 'completed',
        });
      }, 3000);
    } catch (e) {
      markError(model.id, e instanceof Error ? e.message : 'Download failed');
      addAgentLog({
        id: crypto.randomUUID(),
        type: 'error',
        timestamp: Date.now(),
        summary: `Failed to pull ${model.tag}`,
        status: 'failed',
      });
    }
  }, [addAgentLog, addCustomModel, markDownloading, markError, markInstalled, workspacePath]);

  function activateModel(model: LocalModelDefinition) {
    setActiveModel(model.id);
    useModelStore.getState().setSelectedModel(model.id);
    addAgentLog({
      id: crypto.randomUUID(),
      type: 'status',
      timestamp: Date.now(),
      summary: `Active local model: ${model.name}`,
      status: 'completed',
    });
  }

  return (
    <div className="local-models-page">
      <div className="local-models-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="plugins-back" onClick={() => setCenterView('editor')}>← Back</button>
          <h1>Local Models</h1>
          <span className="local-models-badge">Free forever · {LOCAL_MODEL_CATALOG.length} models</span>
        </div>
        <button className="plugins-back" onClick={() => setShowConfig(!showConfig)}>
          <Settings size={14} /> Ollama / Runtime
        </button>
      </div>

      {showConfig && (
        <div className="local-models-ollama-panel" style={{ margin: '0 24px' }}>
          <h2><Cpu size={16} style={{ display: 'inline', marginRight: 6 }} />Dedicated Ollama &amp; Local Runtime</h2>
          <p className="local-models-stats">
            Ocean routes inference to Ollama at your URL. Uses OpenAI-compatible <code>/api/chat</code>.
            LM Studio and llama.cpp also supported via custom endpoint.
          </p>
          <div className="local-models-config-row">
            <label>
              Ollama URL
              <input value={runtime.ollamaUrl} onChange={(e) => setRuntime({ ollamaUrl: e.target.value })} placeholder="http://localhost:11434" />
            </label>
            <label>
              LM Studio URL
              <input value={runtime.lmstudioUrl} onChange={(e) => setRuntime({ lmstudioUrl: e.target.value })} placeholder="http://localhost:1234/v1" />
            </label>
            <label>
              Default runtime
              <select value={runtime.defaultRuntime} onChange={(e) => setRuntime({ defaultRuntime: e.target.value as 'ollama' | 'lmstudio' })}>
                <option value="ollama">Ollama</option>
                <option value="lmstudio">LM Studio</option>
              </select>
            </label>
            <label>
              <input type="checkbox" checked={runtime.autoPullOnSelect} onChange={(e) => setRuntime({ autoPullOnSelect: e.target.checked })} />
              Auto-pull on download
            </label>
          </div>
        </div>
      )}

      <div className="local-models-toolbar">
        <Search size={16} />
        <input placeholder="Search 100+ local models…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ flex: 1, minWidth: 160 }} />
        <div className="local-models-purpose-tabs">
          <button className={`local-models-purpose-tab ${purpose === 'all' ? 'active' : ''}`} onClick={() => setPurpose('all')}>All</button>
          {LOCAL_MODEL_PURPOSES.map((p) => (
            <button key={p.id} className={`local-models-purpose-tab ${purpose === p.id ? 'active' : ''}`} onClick={() => setPurpose(p.id)}>
              {p.icon} {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="local-models-body">
        <p className="local-models-stats" style={{ marginBottom: 12 }}>
          {installed.length} installed · {favorites.length} favorites · {downloadQueue.length} downloading
          {activeModelId && ` · Active: ${LOCAL_MODEL_CATALOG.find((m) => m.id === activeModelId)?.name ?? activeModelId}`}
        </p>
        <div className="local-models-grid">
          {filtered.map((model) => (
            <LocalModelCard
              key={model.id}
              model={model}
              installed={isInstalled(model.id)}
              favorite={favorites.includes(model.id)}
              active={activeModelId === model.id}
              downloading={downloadQueue.includes(model.id)}
              onPull={() => void pullModel(model)}
              onActivate={() => activateModel(model)}
              onFavorite={() => toggleFavorite(model.id)}
              onRemove={() => removeInstalled(model.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function LocalModelCard({ model, installed, favorite, active, downloading, onPull, onActivate, onFavorite, onRemove }: {
  model: LocalModelDefinition;
  installed: boolean;
  favorite: boolean;
  active: boolean;
  downloading: boolean;
  onPull: () => void;
  onActivate: () => void;
  onFavorite: () => void;
  onRemove: () => void;
}) {
  const purposeLabel = LOCAL_MODEL_PURPOSES.find((p) => p.id === model.purpose)?.label ?? model.purpose;
  return (
    <motion.div className={`local-model-card ${installed ? 'installed' : ''} ${active ? 'active' : ''}`} whileHover={{ y: -2 }}>
      <div className="local-model-card-header">
        <h3>{model.name}</h3>
        <button className="plugins-back" onClick={onFavorite} title="Favorite">
          <Star size={14} fill={favorite ? '#F59E0B' : 'none'} color={favorite ? '#F59E0B' : undefined} />
        </button>
      </div>
      <div className="local-model-tags">
        <span className="local-model-tag">{purposeLabel}</span>
        {model.optimized && <span className="local-model-tag opt">Optimized</span>}
        {model.sizeGb && <span className="local-model-tag"><HardDrive size={10} /> {model.sizeGb}GB</span>}
      </div>
      <p className="local-model-desc">{model.description}</p>
      <p className="local-model-meta">{model.tag}{model.contextWindow ? ` · ${(model.contextWindow / 1000).toFixed(0)}k ctx` : ''}</p>
      <div className="local-model-actions">
        {installed ? (
          <>
            <button className="plugin-install-btn" onClick={onActivate}><Play size={12} /> Use</button>
            {active && <span className="local-models-badge"><Check size={10} /> Active</span>}
            <button className="plugins-back" onClick={onRemove}><Trash2 size={12} /></button>
          </>
        ) : (
          <button className="plugin-install-btn" onClick={onPull} disabled={downloading}>
            <Download size={12} /> {downloading ? 'Pulling…' : 'Download'}
          </button>
        )}
      </div>
    </motion.div>
  );
}
