import { useState } from 'react';
import { Key, Plus, Trash2, Shield, Plug } from 'lucide-react';
import { useAppStore } from '../store/appStore';
import { useByokStore, type ByokCredential } from '../store/byokStore';
import { PROVIDER_CATALOG } from '../providers/catalog';
import '../pages/PluginsPage.css';

const SERVICE_FIELDS: { key: keyof ByokCredential | string; label: string; secret?: boolean; placeholder?: string }[] = [
  { key: 'apiKey', label: 'API Key', secret: true, placeholder: 'sk-...' },
  { key: 'clientId', label: 'Client ID', placeholder: 'OAuth client ID' },
  { key: 'clientSecret', label: 'Client Secret', secret: true },
  { key: 'baseUrl', label: 'Base URL', placeholder: 'https://api.example.com/v1' },
  { key: 'orgId', label: 'Organization ID' },
  { key: 'region', label: 'Region', placeholder: 'us-east-1' },
  { key: 'bearerToken', label: 'Bearer Token', secret: true },
  { key: 'webhookUrl', label: 'Webhook URL' },
];

export default function ByokPage() {
  const setCenterView = useAppStore((s) => s.setCenterView);
  const enabled = useByokStore((s) => s.enabled);
  const fallbackForAgents = useByokStore((s) => s.fallbackForAgents);
  const credentials = useByokStore((s) => s.credentials);
  const setEnabled = useByokStore((s) => s.setEnabled);
  const setFallbackForAgents = useByokStore((s) => s.setFallbackForAgents);
  const upsertCredential = useByokStore((s) => s.upsertCredential);
  const removeCredential = useByokStore((s) => s.removeCredential);

  const [selectedProvider, setSelectedProvider] = useState('openai');
  const [form, setForm] = useState<Partial<ByokCredential>>({ providerId: 'openai' });
  const [search, setSearch] = useState('');

  const providers = PROVIDER_CATALOG.filter((p) =>
    !search || `${p.name} ${p.id} ${p.category}`.toLowerCase().includes(search.toLowerCase())
  );

  function loadProvider(id: string) {
    setSelectedProvider(id);
    const existing = credentials.find((c) => c.providerId === id);
    setForm(existing ?? { providerId: id, label: PROVIDER_CATALOG.find((p) => p.id === id)?.name });
  }

  function save() {
    if (!form.providerId) return;
    upsertCredential({
      providerId: form.providerId,
      apiKey: form.apiKey,
      clientId: form.clientId,
      clientSecret: form.clientSecret,
      baseUrl: form.baseUrl,
      orgId: form.orgId,
      region: form.region,
      bearerToken: form.bearerToken,
      webhookUrl: form.webhookUrl,
      label: form.label ?? form.providerId,
    });
  }

  const def = PROVIDER_CATALOG.find((p) => p.id === selectedProvider);

  return (
    <div className="plugins-page">
      <div className="plugins-header">
        <div className="plugins-header-left">
          <button className="plugins-back" onClick={() => setCenterView('editor')}>← Back</button>
          <h1>BYOK — API Keys &amp; Service APIs</h1>
          <span className="plugins-platform-badge"><Key size={14} /> Bring Your Own Key</span>
        </div>
      </div>

      <div className="plugins-body" style={{ padding: 24 }}>
        <div className="sandbox-mcp-status-bar" style={{ marginBottom: 16 }}>
          <Shield size={16} />
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.8125rem' }}>
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            BYOK enabled
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.8125rem' }}>
            <input type="checkbox" checked={fallbackForAgents} onChange={(e) => setFallbackForAgents(e.target.checked)} />
            Use for all agents when provider not directly connected
          </label>
        </div>

        <p style={{ fontSize: '0.8125rem', color: '#78716C', marginBottom: 16 }}>
          Omni-style service integration — configure API keys, OAuth client credentials, base URLs, regions, and webhooks per provider.
          Agents use the full service API, not just model endpoints.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16 }}>
          <div>
            <input className="plugins-search" style={{ width: '100%', marginBottom: 8 }} placeholder="Search providers…" value={search} onChange={(e) => setSearch(e.target.value)} />
            <div style={{ maxHeight: 400, overflow: 'auto', border: '1px solid #E7E5E4', borderRadius: 8 }}>
              {providers.slice(0, 60).map((p) => (
                <button
                  key={p.id}
                  className={`sidebar-item ${selectedProvider === p.id ? 'active' : ''}`}
                  style={{ width: '100%', border: 'none', background: selectedProvider === p.id ? '#F5F5F4' : 'transparent', cursor: 'pointer', textAlign: 'left', padding: '8px 12px' }}
                  onClick={() => loadProvider(p.id)}
                >
                  <span style={{ color: p.brandColor, fontWeight: 600 }}>{p.logoLetter}</span> {p.name}
                  {credentials.some((c) => c.providerId === p.id) && <Plug size={12} style={{ marginLeft: 4, color: '#22C55E' }} />}
                </button>
              ))}
            </div>
          </div>

          <div className="sandbox-mcp-form">
            <h3 style={{ margin: '0 0 8px' }}>{def?.name ?? selectedProvider}</h3>
            <p style={{ fontSize: '0.75rem', color: '#78716C', marginBottom: 12 }}>{def?.description}</p>
            {def?.envFields && (
              <p style={{ fontSize: '0.6875rem', color: '#A8A29E', marginBottom: 12 }}>
                Provider fields: {def.envFields.map((f) => f.key).join(', ')}
              </p>
            )}
            {SERVICE_FIELDS.map((f) => (
              <label key={f.key} className="sandbox-mcp-field">
                <span>{f.label}</span>
                <input
                  type={f.secret ? 'password' : 'text'}
                  placeholder={f.placeholder}
                  value={String((form as Record<string, unknown>)[f.key] ?? '')}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                />
              </label>
            ))}
            <div className="sandbox-mcp-actions">
              <button className="plugin-install-btn" onClick={save}><Plus size={14} /> Save credentials</button>
              {credentials.some((c) => c.providerId === selectedProvider) && (
                <button className="plugins-back" onClick={() => removeCredential(selectedProvider)}><Trash2 size={14} /> Remove</button>
              )}
            </div>
          </div>
        </div>

        {credentials.length > 0 && (
          <div style={{ marginTop: 24 }}>
            <h3 style={{ fontSize: '0.9375rem' }}>Saved credentials ({credentials.length})</h3>
            {credentials.map((c) => (
              <div key={c.providerId} className="plugins-installed-row" style={{ marginTop: 8 }}>
                <strong>{c.label ?? c.providerId}</strong>
                <span style={{ fontSize: '0.75rem', color: '#78716C' }}>
                  {c.apiKey ? 'API key · ' : ''}{c.baseUrl ? `URL: ${c.baseUrl}` : 'configured'}
                </span>
                <button className="plugins-back" onClick={() => loadProvider(c.providerId)}>Edit</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
