/** Curated open-source agent/coding tools — ClawCode, Aider, Continue, etc. */

export type OpenSourceToolCategory =
  | 'agent'
  | 'cli'
  | 'mcp'
  | 'scraper'
  | 'terminal'
  | 'framework';

export type OpenSourceInstallMethod = 'git' | 'pip' | 'npm' | 'cargo' | 'brew' | 'npx' | 'manual';

export interface OpenSourceToolDefinition {
  id: string;
  name: string;
  displayName: string;
  description: string;
  category: OpenSourceToolCategory;
  repository: string;
  homepage?: string;
  license?: string;
  installMethod: OpenSourceInstallMethod;
  /** Shell commands to install on user hardware */
  installCommands: string[];
  /** Verify installation */
  verifyCommand?: string;
  /** How the agent should use this tool */
  agentGuide: string;
  /** Env vars or API keys needed */
  envRequirements?: string[];
  /** Ocean plugin id if bundled */
  oceanPluginId?: string;
  /** Related MCP preset */
  mcpPresetId?: string;
  tags: string[];
  verified?: boolean;
  platforms: ('electron' | 'web' | 'mobile')[];
}

export const OPEN_SOURCE_TOOLS: OpenSourceToolDefinition[] = [
  {
    id: 'oss.claw-code',
    name: 'claw-code',
    displayName: 'Claw Code',
    description: 'Open-source AI coding agent framework — clean-room Claude Code architecture (Python + Rust)',
    category: 'agent',
    repository: 'https://github.com/instructkr/claw-code',
    homepage: 'https://claw-code.codes',
    license: 'MIT',
    installMethod: 'git',
    installCommands: [
      'git clone https://github.com/instructkr/claw-code.git tools/claw-code',
      'cd tools/claw-code && pip install -r requirements.txt',
    ],
    verifyCommand: 'python tools/claw-code/src/main.py --help || ls tools/claw-code',
    agentGuide: `**Claw Code** — open-source agent harness (tool system, query engine, multi-agent, memory).

Install: clone to \`tools/claw-code\`, pip install requirements.
Run: \`python tools/claw-code/src/main.py\` with your API keys in env.
Use when user wants Claude Code–style terminal agent without proprietary stack.
Pair with Ocean Self-Control: \`OCEAN_TOOL install_app\` or \`run_terminal\` for deps.
Alternative Python-only: HarnessLab/claw-code-agent (zero deps, Ollama/vLLM).`,
    envRequirements: ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY'],
    tags: ['claw-code', 'agent', 'claude-code', 'python', 'rust'],
    verified: true,
    platforms: ['electron', 'web'],
  },
  {
    id: 'oss.claw-code-agent',
    name: 'claw-code-agent',
    displayName: 'Claw Code Agent (Python)',
    description: 'Pure Python reimplementation — local models via Ollama/vLLM, zero dependencies',
    category: 'agent',
    repository: 'https://github.com/HarnessLab/claw-code-agent',
    license: 'MIT',
    installMethod: 'git',
    installCommands: [
      'git clone https://github.com/HarnessLab/claw-code-agent.git tools/claw-code-agent',
    ],
    verifyCommand: 'python tools/claw-code-agent/main.py --help 2>/dev/null || ls tools/claw-code-agent',
    agentGuide: `**Claw Code Agent** — stdlib-only Python agent for local models (Qwen3-Coder, Ollama, vLLM).

Run: \`python tools/claw-code-agent/main.py\` with OPENAI_BASE_URL pointing to Ollama (\`http://localhost:11434/v1\`).
Best for offline/hardware-level coding on user machine.`,
    envRequirements: ['OPENAI_API_KEY', 'OPENAI_BASE_URL'],
    tags: ['claw-code', 'python', 'ollama', 'local'],
    verified: true,
    platforms: ['electron'],
  },
  {
    id: 'oss.ultraworkers-claw',
    name: 'ultraworkers-claw-code',
    displayName: 'UltraWorkers Claw (Rust)',
    description: 'Rust CLI agent harness — build from source, `claw` binary',
    category: 'agent',
    repository: 'https://github.com/ultraworkers/claw-code',
    license: 'MIT',
    installMethod: 'cargo',
    installCommands: [
      'git clone https://github.com/ultraworkers/claw-code.git tools/ultraworkers-claw',
      'cd tools/ultraworkers-claw/rust && cargo build --release',
    ],
    verifyCommand: 'tools/ultraworkers-claw/rust/target/release/claw --version 2>/dev/null || echo claw-built',
    agentGuide: `**UltraWorkers Claw** — Rust \`claw\` CLI. Do NOT \`cargo install claw-code\` (deprecated stub).

Build from source in \`tools/ultraworkers-claw/rust\`.
Ecosystem: gajae-code, oh-my-claudecode, oh-my-codex, oh-my-openagent.`,
    tags: ['claw', 'rust', 'ultraworkers'],
    verified: true,
    platforms: ['electron'],
  },
  {
    id: 'oss.gajae-code',
    name: 'gajae-code',
    displayName: 'Gajae Code',
    description: 'Agent harness companion to Claw Code / UltraWorkers toolchain',
    category: 'framework',
    repository: 'https://github.com/Yeachan-Heo/gajae-code',
    installMethod: 'git',
    installCommands: ['git clone https://github.com/Yeachan-Heo/gajae-code.git tools/gajae-code'],
    agentGuide: '**Gajae Code** — agent harness framework. Clone to tools/gajae-code; follow README for setup with claw/oh-my-* tools.',
    tags: ['gajae', 'agent', 'harness'],
    verified: true,
    platforms: ['electron'],
  },
  {
    id: 'oss.oh-my-claudecode',
    name: 'oh-my-claudecode',
    displayName: 'Oh My Claude Code',
    description: 'Enhanced Claude Code–style workflows and harness plugins',
    category: 'framework',
    repository: 'https://github.com/Yeachan-Heo/oh-my-claudecode',
    installMethod: 'git',
    installCommands: ['git clone https://github.com/Yeachan-Heo/oh-my-claudecode.git tools/oh-my-claudecode'],
    agentGuide: '**Oh My Claude Code** — workflow plugins for agent harnesses. Use with Claw/gajae ecosystem.',
    tags: ['claude', 'workflow', 'harness'],
    verified: true,
    platforms: ['electron', 'web'],
  },
  {
    id: 'oss.aider',
    name: 'aider',
    displayName: 'Aider',
    description: 'AI pair programming in terminal — edits git repos with LLMs',
    category: 'cli',
    repository: 'https://github.com/Aider-AI/aider',
    homepage: 'https://aider.chat',
    license: 'Apache-2.0',
    installMethod: 'pip',
    installCommands: ['pip install aider-chat'],
    verifyCommand: 'aider --version',
    agentGuide: `**Aider** — terminal pair programmer. Run \`aider\` in git repo with API keys set.
Use for multi-file edits when user wants git-aware AI coding outside Ocean panel.`,
    envRequirements: ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY'],
    tags: ['aider', 'pair-programming', 'git'],
    verified: true,
    platforms: ['electron', 'web'],
  },
  {
    id: 'oss.continue',
    name: 'continue',
    displayName: 'Continue',
    description: 'Open-source IDE autopilot — VS Code/JetBrains extension + CLI',
    category: 'agent',
    repository: 'https://github.com/continuedev/continue',
    homepage: 'https://continue.dev',
    license: 'Apache-2.0',
    installMethod: 'npm',
    installCommands: ['npm install -g @continuedev/cli'],
    verifyCommand: 'cn --version 2>/dev/null || continue --version 2>/dev/null || echo continue',
    agentGuide: '**Continue** — open IDE agent. Install CLI globally; configure models in ~/.continue/config.json.',
    tags: ['continue', 'ide', 'autopilot'],
    verified: true,
    platforms: ['electron', 'web'],
  },
  {
    id: 'oss.opencode',
    name: 'opencode',
    displayName: 'OpenCode',
    description: 'Open-source terminal coding agent (sst/opencode)',
    category: 'cli',
    repository: 'https://github.com/sst/opencode',
    installMethod: 'npm',
    installCommands: ['npm install -g opencode-ai@latest'],
    verifyCommand: 'opencode --version 2>/dev/null || echo opencode',
    agentGuide: '**OpenCode** — terminal coding agent. Run `opencode` in project root; supports multiple providers.',
    tags: ['opencode', 'terminal', 'agent'],
    verified: true,
    platforms: ['electron'],
  },
  {
    id: 'oss.open-interpreter',
    name: 'open-interpreter',
    displayName: 'Open Interpreter',
    description: 'Natural language interface for local code execution',
    category: 'terminal',
    repository: 'https://github.com/OpenInterpreter/open-interpreter',
    license: 'AGPL-3.0',
    installMethod: 'pip',
    installCommands: ['pip install open-interpreter'],
    verifyCommand: 'interpreter --version 2>/dev/null || echo interpreter',
    agentGuide: '**Open Interpreter** — run `interpreter` for local code execution from natural language. Desktop shell required.',
    tags: ['interpreter', 'local', 'python'],
    verified: true,
    platforms: ['electron'],
  },
  {
    id: 'oss.firecrawl-cli',
    name: 'firecrawl-cli',
    displayName: 'Firecrawl CLI',
    description: 'Search, scrape, crawl the web from terminal',
    category: 'scraper',
    repository: 'https://github.com/mendableai/firecrawl',
    homepage: 'https://firecrawl.dev',
    installMethod: 'npm',
    installCommands: ['npm install -g firecrawl-cli'],
    verifyCommand: 'firecrawl --version 2>/dev/null || npx firecrawl --version',
    agentGuide: `**Firecrawl CLI** — \`firecrawl search "query" -o .firecrawl/out.json --json\`.
Use for web research when OCEAN_TOOL web_search needs full page content.
Requires FIRECRAWL_API_KEY in env.`,
    envRequirements: ['FIRECRAWL_API_KEY'],
    oceanPluginId: 'ocean.scrape-firecrawl',
    tags: ['firecrawl', 'scrape', 'search'],
    verified: true,
    platforms: ['electron', 'web', 'mobile'],
  },
  {
    id: 'oss.cline',
    name: 'cline',
    displayName: 'Cline',
    description: 'Autonomous coding agent for VS Code (formerly Claude Dev)',
    category: 'agent',
    repository: 'https://github.com/cline/cline',
    homepage: 'https://cline.bot',
    license: 'Apache-2.0',
    installMethod: 'manual',
    installCommands: [],
    agentGuide: '**Cline** — VS Code extension agent. Install from Open VSX / marketplace; use extension id `saoudrizwan.claude-dev`. Ocean agents reference its patterns for tool-use loops.',
    tags: ['cline', 'vscode', 'agent'],
    verified: true,
    platforms: ['electron', 'web'],
  },
  {
    id: 'oss.goose',
    name: 'goose',
    displayName: 'Goose',
    description: 'Block open-source AI agent for developers',
    category: 'agent',
    repository: 'https://github.com/block/goose',
    installMethod: 'manual',
    installCommands: ['curl -fsSL https://github.com/block/goose/releases/latest/download/download_cli.sh | CONFIGURE=false bash'],
    verifyCommand: 'goose --version 2>/dev/null || echo goose',
    agentGuide: '**Goose** — Block\'s open agent CLI. Install via release script; configure providers in ~/.config/goose.',
    tags: ['goose', 'block', 'agent'],
    verified: true,
    platforms: ['electron'],
  },
];

export const OPEN_SOURCE_TOOL_COUNT = OPEN_SOURCE_TOOLS.length;

export function getOpenSourceTool(id: string): OpenSourceToolDefinition | undefined {
  return OPEN_SOURCE_TOOLS.find((t) => t.id === id);
}

export function serializeOpenSourceToolsForAgent(
  tools: OpenSourceToolDefinition[],
  installedIds?: Set<string>,
): string {
  if (!tools.length) return '';
  const lines = ['## Open Source Tools (configured)\n'];
  for (const t of tools) {
    const status = installedIds?.has(t.id) ? '✓ installed' : 'catalog';
    lines.push(`### ${t.displayName} (${t.id}) — ${status}`);
    lines.push(`Repo: ${t.repository} · ${t.category} · install: ${t.installMethod}`);
    lines.push(t.agentGuide);
    if (t.installCommands.length) {
      lines.push('**Install:**', ...t.installCommands.map((c) => `- \`${c}\``));
    }
    if (t.verifyCommand) lines.push(`**Verify:** \`${t.verifyCommand}\``);
    if (t.envRequirements?.length) lines.push(`**Env:** ${t.envRequirements.join(', ')}`);
    if (t.oceanPluginId) lines.push(`**Ocean plugin:** \`${t.oceanPluginId}\``);
    lines.push('');
  }
  return lines.join('\n');
}

export function serializeOpenSourceCatalogSummary(): string {
  const byCat = new Map<string, string[]>();
  for (const t of OPEN_SOURCE_TOOLS) {
    const list = byCat.get(t.category) ?? [];
    list.push(`${t.displayName} (${t.id})`);
    byCat.set(t.category, list);
  }
  const lines = ['## Open Source Tools Catalog', `Total: ${OPEN_SOURCE_TOOLS.length} curated tools\n`];
  for (const [cat, items] of byCat) {
    lines.push(`### ${cat}`, ...items.map((i) => `- ${i}`), '');
  }
  return lines.join('\n');
}
