import type { SandboxDockerConfig, SandboxInitCommand, SandboxMcpConnectPayload, SandboxMcpInstance, SandboxMcpPreset, SandboxRuntime } from './sandboxTypes';

export function connectorIdForSandbox(instanceId: string): string {
  return `sandbox.${instanceId}`;
}

export function buildSandboxConnectPayload(
  instance: SandboxMcpInstance,
  preset?: SandboxMcpPreset
): SandboxMcpConnectPayload {
  const env = { ...preset?.defaultEnv, ...instance.env };
  const docker = runtimeNeedsDocker(instance.runtime)
    ? mergeDockerConfig(preset?.docker, instance.docker, instance.workspaceMount)
    : undefined;

  if (docker && instance.workspaceMount) {
    const mounts = [...(docker.mounts ?? [])];
    const hasWorkspace = mounts.some((m) => m.container === '/workspace' || m.container === '/files');
    if (!hasWorkspace) {
      mounts.push({ host: instance.workspaceMount, container: '/workspace', mode: 'rw' });
    }
    docker.mounts = mounts;
  }

  return {
    id: connectorIdForSandbox(instance.id),
    name: instance.name,
    transport: 'stdio',
    hosting: 'local',
    runtime: instance.runtime,
    command: instance.command ?? preset?.command,
    args: instance.args ?? preset?.args,
    docker,
    env,
    initCommands: instance.initOnConnect ? preset?.initCommands : undefined,
  };
}

function mergeDockerConfig(
  preset?: SandboxDockerConfig,
  override?: SandboxDockerConfig,
  workspaceMount?: string
): SandboxDockerConfig | undefined {
  if (!preset && !override) return undefined;
  const image = override?.image ?? preset?.image ?? 'alpine:latest';
  const merged: SandboxDockerConfig = {
    ...preset,
    ...override,
    image,
    mounts: [...(preset?.mounts ?? []), ...(override?.mounts ?? [])],
  };
  if (workspaceMount && merged.mounts) {
    const idx = merged.mounts.findIndex((m) => m.container === '/workspace');
    if (idx >= 0) merged.mounts[idx] = { ...merged.mounts[idx], host: workspaceMount };
  }
  return merged;
}

export function instanceFromPreset(preset: SandboxMcpPreset, name?: string): SandboxMcpInstance {
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    presetId: preset.id,
    name: name ?? preset.name,
    runtime: preset.runtime,
    command: preset.command,
    args: preset.args ? [...preset.args] : undefined,
    docker: preset.docker ? { ...preset.docker, mounts: preset.docker.mounts ? [...preset.docker.mounts] : undefined } : undefined,
    env: { ...preset.defaultEnv },
    workspaceMount: preset.defaultEnv?.FILES_DIR?.replace('/files', '') ?? '~/sandbox-workspace',
    initOnConnect: Boolean(preset.initCommands?.length),
    enabled: true,
    createdAt: now,
    updatedAt: now,
  };
}

export function runtimeNeedsDocker(runtime: SandboxRuntime): boolean {
  return runtime === 'docker' || runtime === 'docker-socket';
}

export function parseArgsString(raw: string): string[] {
  const trimmed = raw.trim();
  if (!trimmed) return [];
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) return parsed.map(String);
  } catch { /* fall through */ }
  return trimmed.split(/\s+/).filter(Boolean);
}

export function formatArgsString(args?: string[]): string {
  if (!args?.length) return '';
  return args.join(' ');
}

export function summarizeInitCommands(commands?: SandboxInitCommand[]): string {
  if (!commands?.length) return 'None';
  return commands.map((c) => `${c.command} ${(c.args ?? []).join(' ')}`.trim()).join(' → ');
}
