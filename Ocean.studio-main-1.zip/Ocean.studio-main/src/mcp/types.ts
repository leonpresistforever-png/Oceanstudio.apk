export type McpTransport = 'stdio' | 'sse' | 'http' | 'websocket';
export type McpHosting = 'local' | 'cloud';
export type McpRuntime = 'host' | 'docker' | 'docker-socket';

export interface McpDockerConfig {
  image: string;
  entrypoint?: string[];
  cmd?: string[];
  mounts?: { host: string; container: string; mode?: 'ro' | 'rw' }[];
  network?: 'bridge' | 'host' | 'none' | 'isolated';
  memory?: string;
  cpus?: string;
  readOnlyRootfs?: boolean;
  user?: string;
  workdir?: string;
  extraRunArgs?: string[];
  mountDockerSocket?: boolean;
}
export type McpAuthType = 'none' | 'api_key' | 'oauth' | 'bearer' | 'client_credentials';
export type McpPlatform = 'electron' | 'web' | 'mobile';

export interface McpEnvField {
  key: string;
  label: string;
  secret?: boolean;
  placeholder?: string;
  required?: boolean;
}

export interface McpConnectorDefinition {
  id: string;
  name: string;
  description: string;
  category: string;
  transport: McpTransport;
  hosting: McpHosting;
  platforms: McpPlatform[];
  command?: string;
  args?: string[];
  url?: string;
  headers?: Record<string, string>;
  envFields?: McpEnvField[];
  auth?: {
    type: McpAuthType;
    oauthAuthorizeUrl?: string;
    oauthTokenUrl?: string;
    oauthScopes?: string[];
    tokenHeader?: string;
  };
  verified: boolean;
  docsUrl?: string;
  icon?: string;
}

export interface McpConnection {
  connectorId: string;
  name: string;
  transport: McpTransport;
  hosting: McpHosting;
  runtime?: McpRuntime;
  config: Record<string, string>;
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  error?: string;
  connectedAt?: number;
  custom?: boolean;
  sandbox?: boolean;
}

export interface McpConnectionStatus {
  id: string;
  status: McpConnection['status'];
  message: string;
  toolCount?: number;
}
