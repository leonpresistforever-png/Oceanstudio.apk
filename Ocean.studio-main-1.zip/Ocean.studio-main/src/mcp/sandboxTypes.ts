import type { McpEnvField } from './types';

/** How the MCP server process is launched on the user's machine */
export type SandboxRuntime =
  | 'host'           // Direct stdio: npx, uvx, go binary, python
  | 'docker'         // docker run -i --rm <image> ...
  | 'docker-socket'; // docker run with /var/run/docker.sock for nested containers

export type SandboxNetworkMode = 'bridge' | 'host' | 'none' | 'isolated';

export interface SandboxMount {
  host: string;
  container: string;
  mode?: 'ro' | 'rw';
}

export interface SandboxDockerConfig {
  image: string;
  entrypoint?: string[];
  cmd?: string[];
  mounts?: SandboxMount[];
  network?: SandboxNetworkMode;
  memory?: string;
  cpus?: string;
  readOnlyRootfs?: boolean;
  user?: string;
  workdir?: string;
  extraRunArgs?: string[];
  /** Mount Docker socket for servers that spawn nested containers */
  mountDockerSocket?: boolean;
}

export interface SandboxInitCommand {
  command: string;
  args?: string[];
  description?: string;
  optional?: boolean;
}

export type SandboxCompatibilityLayer =
  | 'stdio-host'
  | 'stdio-docker'
  | 'stdio-docker-socket'
  | 'npx'
  | 'uvx'
  | 'go-install'
  | 'pip-uv'
  | 'deno'
  | 'wasm-pyodide'
  | 'e2b-cloud';

export interface SandboxMcpPreset {
  id: string;
  name: string;
  description: string;
  runtime: SandboxRuntime;
  category: 'docker' | 'javascript' | 'python' | 'multi-lang' | 'cloud' | 'custom';
  command?: string;
  args?: string[];
  docker?: SandboxDockerConfig;
  envFields?: McpEnvField[];
  defaultEnv?: Record<string, string>;
  initCommands?: SandboxInitCommand[];
  requirements?: string[];
  compatibility: SandboxCompatibilityLayer[];
  docsUrl?: string;
  githubUrl?: string;
  archived?: boolean;
  recommendedAlternative?: string;
  tags?: string[];
}

/** User-editable instance saved in sandbox store */
export interface SandboxMcpInstance {
  id: string;
  presetId?: string;
  name: string;
  runtime: SandboxRuntime;
  command?: string;
  args?: string[];
  docker?: SandboxDockerConfig;
  env: Record<string, string>;
  workspaceMount?: string;
  initOnConnect: boolean;
  enabled: boolean;
  connectorId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface SandboxMcpConnectPayload {
  id: string;
  name: string;
  transport: 'stdio';
  hosting: 'local';
  runtime: SandboxRuntime;
  command?: string;
  args?: string[];
  docker?: SandboxDockerConfig;
  env?: Record<string, string>;
  initCommands?: SandboxInitCommand[];
}
