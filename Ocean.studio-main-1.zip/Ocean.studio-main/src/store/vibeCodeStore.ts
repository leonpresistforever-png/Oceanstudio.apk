import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { VibeCodeConfig, VibePendingAction } from '../lib/vibeCode/types';
import { DEFAULT_VIBE_CODE_CONFIG } from '../lib/vibeCode/types';

interface VibeCodeState {
  config: VibeCodeConfig;
  pendingActions: VibePendingAction[];
  lastRunTools: number;
  lastRunIterations: number;

  setConfig: (patch: Partial<VibeCodeConfig>) => void;
  setEnabled: (enabled: boolean) => void;
  addPendingAction: (action: VibePendingAction) => void;
  removePendingAction: (id: string) => void;
  clearPendingActions: () => void;
  setLastRunStats: (tools: number, iterations: number) => void;
  approveAction: (id: string) => boolean;
  rejectAction: (id: string) => void;
}

export const useVibeCodeStore = create<VibeCodeState>()(
  persist(
    (set, get) => ({
      config: { ...DEFAULT_VIBE_CODE_CONFIG },
      pendingActions: [],
      lastRunTools: 0,
      lastRunIterations: 0,

      setConfig: (patch) => set((s) => ({ config: { ...s.config, ...patch } })),
      setEnabled: (enabled) => set((s) => ({ config: { ...s.config, enabled } })),
      addPendingAction: (action) =>
        set((s) => ({ pendingActions: [...s.pendingActions, action] })),
      removePendingAction: (id) =>
        set((s) => ({ pendingActions: s.pendingActions.filter((a) => a.id !== id) })),
      clearPendingActions: () => set({ pendingActions: [] }),
      setLastRunStats: (lastRunTools, lastRunIterations) => set({ lastRunTools, lastRunIterations }),
      approveAction: (id) => {
        const action = get().pendingActions.find((a) => a.id === id);
        if (!action) return false;
        set((s) => ({ pendingActions: s.pendingActions.filter((a) => a.id !== id) }));
        return true;
      },
      rejectAction: (id) => {
        set((s) => ({ pendingActions: s.pendingActions.filter((a) => a.id !== id) }));
      },
    }),
    {
      name: 'ocean-vibe-code-store',
      partialize: (s) => ({ config: s.config }),
    }
  )
);
