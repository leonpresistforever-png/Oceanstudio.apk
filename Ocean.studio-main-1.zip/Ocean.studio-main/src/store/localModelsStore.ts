import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { LocalModelDefinition } from '../models/localCatalog';

export interface InstalledLocalModel {
  modelId: string;
  tag: string;
  installedAt: number;
  runtime: 'ollama' | 'lmstudio' | 'llamacpp';
  ollamaUrl?: string;
  status: 'installed' | 'downloading' | 'error' | 'configured';
  error?: string;
  customParams?: { temperature?: number; topP?: number; numCtx?: number };
}

export interface LocalModelsRuntimeConfig {
  ollamaUrl: string;
  lmstudioUrl: string;
  defaultRuntime: 'ollama' | 'lmstudio';
  autoPullOnSelect: boolean;
  gpuLayers?: number;
  numThread?: number;
}

interface LocalModelsState {
  installed: InstalledLocalModel[];
  favorites: string[];
  activeModelId?: string;
  runtime: LocalModelsRuntimeConfig;
  downloadQueue: string[];

  setRuntime: (patch: Partial<LocalModelsRuntimeConfig>) => void;
  setActiveModel: (modelId: string | undefined) => void;
  toggleFavorite: (modelId: string) => void;
  markInstalled: (model: LocalModelDefinition, runtime?: InstalledLocalModel['runtime']) => void;
  markDownloading: (modelId: string) => void;
  markError: (modelId: string, error: string) => void;
  removeInstalled: (modelId: string) => void;
  updateParams: (modelId: string, params: InstalledLocalModel['customParams']) => void;
  isInstalled: (modelId: string) => boolean;
  getInstalled: (modelId: string) => InstalledLocalModel | undefined;
}

export const useLocalModelsStore = create<LocalModelsState>()(
  persist(
    (set, get) => ({
      installed: [],
      favorites: [],
      activeModelId: undefined,
      runtime: {
        ollamaUrl: 'http://localhost:11434',
        lmstudioUrl: 'http://localhost:1234/v1',
        defaultRuntime: 'ollama',
        autoPullOnSelect: true,
      },
      downloadQueue: [],

      setRuntime: (patch) => set((s) => ({ runtime: { ...s.runtime, ...patch } })),
      setActiveModel: (activeModelId) => set({ activeModelId }),

      toggleFavorite: (modelId) =>
        set((s) => ({
          favorites: s.favorites.includes(modelId)
            ? s.favorites.filter((id) => id !== modelId)
            : [...s.favorites, modelId],
        })),

      markInstalled: (model, runtime) =>
        set((s) => ({
          installed: [
            {
              modelId: model.id,
              tag: model.tag,
              installedAt: Date.now(),
              runtime: runtime ?? s.runtime.defaultRuntime,
              ollamaUrl: s.runtime.ollamaUrl,
              status: 'installed',
            },
            ...s.installed.filter((i) => i.modelId !== model.id),
          ],
          downloadQueue: s.downloadQueue.filter((id) => id !== model.id),
        })),

      markDownloading: (modelId) =>
        set((s) => ({
          downloadQueue: s.downloadQueue.includes(modelId) ? s.downloadQueue : [...s.downloadQueue, modelId],
        })),

      markError: (modelId, error) =>
        set((s) => ({
          installed: s.installed.map((i) => (i.modelId === modelId ? { ...i, status: 'error' as const, error } : i)),
          downloadQueue: s.downloadQueue.filter((id) => id !== modelId),
        })),

      removeInstalled: (modelId) =>
        set((s) => ({
          installed: s.installed.filter((i) => i.modelId !== modelId),
          activeModelId: s.activeModelId === modelId ? undefined : s.activeModelId,
        })),

      updateParams: (modelId, customParams) =>
        set((s) => ({
          installed: s.installed.map((i) => (i.modelId === modelId ? { ...i, customParams } : i)),
        })),

      isInstalled: (modelId) => get().installed.some((i) => i.modelId === modelId && i.status === 'installed'),
      getInstalled: (modelId) => get().installed.find((i) => i.modelId === modelId),
    }),
    { name: 'ocean-local-models-store' }
  )
);
