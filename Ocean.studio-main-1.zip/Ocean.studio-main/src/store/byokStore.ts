import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/** Per-provider BYOK credentials when not using OAuth/direct provider connection */
export interface ByokCredential {
  providerId: string;
  apiKey?: string;
  clientId?: string;
  clientSecret?: string;
  baseUrl?: string;
  orgId?: string;
  region?: string;
  bearerToken?: string;
  webhookUrl?: string;
  extra?: Record<string, string>;
  label?: string;
  updatedAt: number;
}

interface ByokState {
  enabled: boolean;
  /** Use BYOK keys for all agents when provider not directly connected */
  fallbackForAgents: boolean;
  credentials: ByokCredential[];

  setEnabled: (enabled: boolean) => void;
  setFallbackForAgents: (v: boolean) => void;
  upsertCredential: (cred: Omit<ByokCredential, 'updatedAt'> & { updatedAt?: number }) => void;
  removeCredential: (providerId: string) => void;
  getCredential: (providerId: string) => ByokCredential | undefined;
  toProviderConfig: (providerId: string) => Record<string, string>;
}

function credToConfig(c: ByokCredential): Record<string, string> {
  const cfg: Record<string, string> = { ...(c.extra ?? {}) };
  if (c.apiKey) {
    cfg.API_KEY = c.apiKey;
    cfg.OPENAI_API_KEY = c.apiKey;
    cfg.ANTHROPIC_API_KEY = c.apiKey;
    cfg.GOOGLE_API_KEY = c.apiKey;
  }
  if (c.clientId) cfg.CLIENT_ID = c.clientId;
  if (c.clientSecret) cfg.CLIENT_SECRET = c.clientSecret;
  if (c.baseUrl) {
    cfg.BASE_URL = c.baseUrl;
    cfg.CUSTOM_ENDPOINT = c.baseUrl;
    cfg.MODELS_API_BASE_URL = c.baseUrl;
    cfg.OLLAMA_URL = c.baseUrl;
  }
  if (c.orgId) cfg.ORG_ID = c.orgId;
  if (c.region) cfg.REGION = c.region;
  if (c.bearerToken) cfg.BEARER_TOKEN = c.bearerToken;
  if (c.webhookUrl) cfg.WEBHOOK_URL = c.webhookUrl;
  return cfg;
}

export const useByokStore = create<ByokState>()(
  persist(
    (set, get) => ({
      enabled: true,
      fallbackForAgents: true,
      credentials: [],

      setEnabled: (enabled) => set({ enabled }),
      setFallbackForAgents: (fallbackForAgents) => set({ fallbackForAgents }),

      upsertCredential: (cred) =>
        set((s) => ({
          credentials: [
            { ...cred, updatedAt: cred.updatedAt ?? Date.now() },
            ...s.credentials.filter((c) => c.providerId !== cred.providerId),
          ],
        })),

      removeCredential: (providerId) =>
        set((s) => ({ credentials: s.credentials.filter((c) => c.providerId !== providerId) })),

      getCredential: (providerId) => get().credentials.find((c) => c.providerId === providerId),

      toProviderConfig: (providerId) => {
        const cred = get().credentials.find((c) => c.providerId === providerId);
        return cred ? credToConfig(cred) : {};
      },
    }),
    { name: 'ocean-byok-store' }
  )
);

/** Resolve BYOK config for inference when provider connection is missing */
export function resolveByokConfig(providerId: string): Record<string, string> | null {
  const store = useByokStore.getState();
  if (!store.enabled || !store.fallbackForAgents) return null;
  const cred = store.getCredential(providerId);
  if (!cred) return null;
  return store.toProviderConfig(providerId);
}
