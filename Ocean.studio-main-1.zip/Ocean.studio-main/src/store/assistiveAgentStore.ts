import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type AssistiveAgentSource = 'provider' | 'byok' | 'mcp' | 'plugin' | 'local';

export interface AssistiveAgentConfig {
  enabled: boolean;
  source: AssistiveAgentSource;
  providerId: string;
  modelId: string;
  mcpConnectorId: string;
  pluginId: string;
  byokProviderId: string;
  /** 0–100 — how aggressively assist while typing */
  assistLevel: number;
  autoFixOnSave: boolean;
  inlineHints: boolean;
  debounceMs: number;
}

const DEFAULT_CONFIG: AssistiveAgentConfig = {
  enabled: true,
  source: 'plugin',
  providerId: 'openai',
  modelId: 'gpt-4o-mini',
  mcpConnectorId: 'mcp.ocean-assistive',
  pluginId: 'ocean.assistive-code',
  byokProviderId: '',
  assistLevel: 60,
  autoFixOnSave: true,
  inlineHints: true,
  debounceMs: 1800,
};

interface AssistiveAgentState {
  config: AssistiveAgentConfig;
  lastSuggestion: string;
  lastFix: string;
  isRunning: boolean;
  setConfig: (partial: Partial<AssistiveAgentConfig>) => void;
  setLastSuggestion: (s: string) => void;
  setLastFix: (s: string) => void;
  setRunning: (v: boolean) => void;
}

export const useAssistiveAgentStore = create<AssistiveAgentState>()(
  persist(
    (set) => ({
      config: { ...DEFAULT_CONFIG },
      lastSuggestion: '',
      lastFix: '',
      isRunning: false,
      setConfig: (partial) => set((s) => ({ config: { ...s.config, ...partial } })),
      setLastSuggestion: (lastSuggestion) => set({ lastSuggestion }),
      setLastFix: (lastFix) => set({ lastFix }),
      setRunning: (isRunning) => set({ isRunning }),
    }),
    { name: 'ocean-assistive-agent' },
  ),
);
