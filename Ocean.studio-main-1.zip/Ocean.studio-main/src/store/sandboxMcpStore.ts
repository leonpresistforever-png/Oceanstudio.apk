import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { SandboxMcpInstance } from '../mcp/sandboxTypes';

interface SandboxMcpState {
  instances: SandboxMcpInstance[];
  addInstance: (instance: SandboxMcpInstance) => void;
  updateInstance: (id: string, patch: Partial<SandboxMcpInstance>) => void;
  removeInstance: (id: string) => void;
  getInstance: (id: string) => SandboxMcpInstance | undefined;
}

export const useSandboxMcpStore = create<SandboxMcpState>()(
  persist(
    (set, get) => ({
      instances: [],

      addInstance: (instance) =>
        set((s) => ({ instances: [...s.instances, instance] })),

      updateInstance: (id, patch) =>
        set((s) => ({
          instances: s.instances.map((i) =>
            i.id === id ? { ...i, ...patch, updatedAt: Date.now() } : i
          ),
        })),

      removeInstance: (id) =>
        set((s) => ({ instances: s.instances.filter((i) => i.id !== id) })),

      getInstance: (id) => get().instances.find((i) => i.id === id),
    }),
    { name: 'ocean-sandbox-mcp-store' }
  )
);
