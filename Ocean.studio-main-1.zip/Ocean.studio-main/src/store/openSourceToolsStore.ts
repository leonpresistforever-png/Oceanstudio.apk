import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  OPEN_SOURCE_TOOLS,
  getOpenSourceTool,
  type OpenSourceToolDefinition,
} from '../tools/openSourceCatalog';

export const MAX_CONFIGURED_OSS_TOOLS = 50;

export interface ConfiguredOpenSourceTool {
  id: string;
  enabled: boolean;
  configuredAt: number;
  installPath?: string;
  notes?: string;
}

interface OpenSourceToolsState {
  configured: ConfiguredOpenSourceTool[];
  installTool: (id: string, installPath?: string) => { ok: true } | { ok: false; reason: 'unknown' | 'duplicate' | 'cap' };
  uninstallTool: (id: string) => void;
  toggleTool: (id: string, enabled: boolean) => void;
  getEnabledDefinitions: () => OpenSourceToolDefinition[];
  isConfigured: (id: string) => boolean;
}

/** Default pre-configured tools agents should know about */
const DEFAULT_CONFIGURED_IDS = [
  'oss.claw-code',
  'oss.claw-code-agent',
  'oss.aider',
  'oss.firecrawl-cli',
  'oss.continue',
  'oss.opencode',
];

function defaultConfigured(): ConfiguredOpenSourceTool[] {
  return DEFAULT_CONFIGURED_IDS.map((id) => ({
    id,
    enabled: true,
    configuredAt: Date.now(),
  }));
}

export const useOpenSourceToolsStore = create<OpenSourceToolsState>()(
  persist(
    (set, get) => ({
      configured: defaultConfigured(),

      installTool: (id, installPath) => {
        const def = getOpenSourceTool(id);
        if (!def) return { ok: false, reason: 'unknown' };
        const s = get();
        if (s.configured.some((c) => c.id === id)) return { ok: false, reason: 'duplicate' };
        if (s.configured.length >= MAX_CONFIGURED_OSS_TOOLS) return { ok: false, reason: 'cap' };
        set({
          configured: [
            { id, enabled: true, configuredAt: Date.now(), installPath },
            ...s.configured,
          ],
        });
        return { ok: true };
      },

      uninstallTool: (id) =>
        set((s) => ({ configured: s.configured.filter((c) => c.id !== id) })),

      toggleTool: (id, enabled) =>
        set((s) => ({
          configured: s.configured.map((c) => (c.id === id ? { ...c, enabled } : c)),
        })),

      getEnabledDefinitions: () => {
        const enabledIds = new Set(
          get().configured.filter((c) => c.enabled).map((c) => c.id),
        );
        return OPEN_SOURCE_TOOLS.filter((t) => enabledIds.has(t.id));
      },

      isConfigured: (id) => get().configured.some((c) => c.id === id),
    }),
    {
      name: 'ocean-open-source-tools',
      partialize: (s) => ({ configured: s.configured }),
      merge: (persisted, current) => {
        const p = persisted as Partial<OpenSourceToolsState> | undefined;
        const configured = p?.configured?.length ? p.configured : current.configured;
        return { ...current, configured };
      },
    },
  ),
);

export function getDefaultOpenSourceToolIds(): string[] {
  return [...DEFAULT_CONFIGURED_IDS];
}
