import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  DEFAULT_VOICE_CHANGER_CONFIG,
  VOICE_CHANGER_PRESETS,
  type VoiceChangerConfig,
  type VoiceChangerPreset,
} from '../playground/voiceChangerTypes';

export type VoiceChangerStatus = 'idle' | 'listening' | 'processing' | 'playing' | 'error';

interface VoiceChangerState {
  config: VoiceChangerConfig;
  status: VoiceChangerStatus;
  lastOutput: string;
  inputFileName: string;
  setConfig: (patch: Partial<VoiceChangerConfig>) => void;
  applyPreset: (preset: VoiceChangerPreset) => void;
  setStatus: (status: VoiceChangerStatus) => void;
  setLastOutput: (text: string) => void;
  setInputFileName: (name: string) => void;
}

export const useVoiceChangerStore = create<VoiceChangerState>()(
  persist(
    (set) => ({
      config: { ...DEFAULT_VOICE_CHANGER_CONFIG },
      status: 'idle',
      lastOutput: '',
      inputFileName: '',
      setConfig: (patch) => set((s) => ({ config: { ...s.config, ...patch } })),
      applyPreset: (preset) =>
        set((s) => ({
          config: {
            ...s.config,
            preset,
            ...VOICE_CHANGER_PRESETS[preset],
          },
        })),
      setStatus: (status) => set({ status }),
      setLastOutput: (lastOutput) => set({ lastOutput }),
      setInputFileName: (inputFileName) => set({ inputFileName }),
    }),
    {
      name: 'ocean-voice-changer',
      partialize: (s) => ({ config: s.config }),
    },
  ),
);
