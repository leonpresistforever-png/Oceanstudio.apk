/**
 * Universal agent system prompt — injected into EVERY provider inference call:
 * main agent, multi-agent workers, playground, vibe code, web/mobile, all providers.
 */

const MAX_SYSTEM_PROMPT_CHARS = 120_000;

export function assembleAgentSystemPrompt(context: Record<string, unknown>): string {
  const modelConfig = (context.modelConfig ?? {}) as Record<string, unknown>;
  const bypassDefaults = Boolean(modelConfig.bypassDefaultInstructions);
  const parts: string[] = [];

  if (!bypassDefaults) {
    const providerCtx = context.providerContext as {
      serialized?: string;
      oceanCoreSkill?: string;
    } | undefined;
    if (providerCtx?.serialized?.trim()) {
      parts.push(providerCtx.serialized);
    } else if (providerCtx?.oceanCoreSkill?.trim()) {
      parts.push(providerCtx.oceanCoreSkill);
    }

    const routing = context.routing as { serialized?: string } | undefined;
    if (routing?.serialized?.trim()) {
      parts.push(routing.serialized);
    }
  }

  const member = context.multiAgentMember as {
    memberName?: string;
    role?: string;
    systemPrompt?: string;
    serializedSkills?: string;
    task?: string;
  } | undefined;

  if (member?.memberName) {
    parts.push(`## Active Agent: ${member.memberName} (${member.role ?? 'worker'})`);
  }
  if (member?.systemPrompt?.trim()) {
    parts.push(member.systemPrompt);
  }
  if (member?.serializedSkills?.trim()) {
    parts.push(member.serializedSkills);
  }
  if (member?.task?.trim()) {
    parts.push(`## Current Task\n${member.task}`);
  }

  const customInstructions = modelConfig.customInstructions as string | undefined;
  if (customInstructions?.trim()) {
    parts.push(customInstructions);
  }

  const extensionsGuide = modelConfig.extensionsGuide as string | undefined;
  if (extensionsGuide?.trim()) {
    parts.push(extensionsGuide);
  }

  const openSourceToolsGuide = modelConfig.openSourceToolsGuide as string | undefined;
  if (openSourceToolsGuide?.trim()) {
    parts.push(openSourceToolsGuide);
  }

  const skills = (modelConfig.skills as { name: string; content: string }[] | undefined) ?? [];
  if (skills.length) {
    const skillBlocks = skills
      .filter((s) => s.name && s.content?.trim())
      .map((s) => `## Skill: ${s.name}\n${s.content.trim()}`)
      .join('\n\n');
    if (skillBlocks.trim()) {
      parts.push(`## Installed Skills\n\n${skillBlocks}`);
    }
  }

  const contextInjectionGuide = modelConfig.contextInjectionGuide as string | undefined;
  if (contextInjectionGuide?.trim()) {
    parts.push(contextInjectionGuide);
  }

  const extHealth = context.extensionHealth as { serialized?: string } | undefined;
  if (extHealth?.serialized?.trim()) {
    parts.push(extHealth.serialized);
  }

  const vibe = context.vibeCode as { enabled?: boolean; serialized?: string } | undefined;
  const customHasVibe = customInstructions?.includes('OCEAN_TOOL');
  if (vibe?.enabled && vibe.serialized?.trim() && !customHasVibe) {
    parts.push(vibe.serialized);
  }

  const multiAgent = context.multiAgent as { serializedCombo?: string; enabled?: boolean } | undefined;
  if (multiAgent?.enabled && multiAgent.serializedCombo?.trim() && !member) {
    parts.push(multiAgent.serializedCombo);
  }

  const mcpCount = Object.keys((context.mcpServers as object) ?? {}).length;
  const pluginCount = ((context.pluginTools as unknown[]) ?? []).length;
  const activeProviders = (
    (context.providerMeta as { activeProviderIds?: string[] } | undefined)?.activeProviderIds ?? []
  ).join(', ');
  parts.push(
    [
      '## Session Runtime',
      `Workspace: ${context.workspacePath ?? 'none'}`,
      `Terminal: ${context.terminalType ?? 'shell'}`,
      `Agent mode: ${context.agentMode ?? 'review'}`,
      `MCP connectors: ${mcpCount}`,
      `Plugin tools: ${pluginCount}`,
      activeProviders ? `Active providers: ${activeProviders}` : '',
    ].filter(Boolean).join('\n'),
  );

  const combined = parts.filter((p) => p?.trim()).join('\n\n');
  if (combined.length <= MAX_SYSTEM_PROMPT_CHARS) return combined;
  return combined.slice(0, MAX_SYSTEM_PROMPT_CHARS) + '\n\n[Context truncated for model limits]';
}

/** Quick check that universal context layers are present */
export function validateUniversalAgentContext(context: Record<string, unknown>): {
  ok: boolean;
  missing: string[];
} {
  const missing: string[] = [];
  const modelConfig = (context.modelConfig ?? {}) as Record<string, unknown>;

  if (!(context.providerContext as { serialized?: string })?.serialized?.trim()) {
    missing.push('providerContext.serialized');
  }
  if (!modelConfig.extensionsGuide) missing.push('modelConfig.extensionsGuide');
  if (!modelConfig.openSourceToolsGuide) missing.push('modelConfig.openSourceToolsGuide');
  if (!(context.extensionHealth as { serialized?: string })?.serialized) {
    missing.push('extensionHealth');
  }

  return { ok: missing.length === 0, missing };
}
