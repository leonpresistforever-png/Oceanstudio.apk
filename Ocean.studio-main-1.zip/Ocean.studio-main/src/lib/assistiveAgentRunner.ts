/** Assistive codebase agent — fast inline help while user types manually */

import { buildAgentContext } from './agentContext';
import { runAgentInference } from './providerInference';
import type { AssistiveAgentConfig } from '../store/assistiveAgentStore';

export interface AssistiveRequest {
  action: 'suggest' | 'fix' | 'complete' | 'explain';
  filePath: string;
  content: string;
  selection?: string;
  cursorLine?: number;
  errorHint?: string;
}

function buildAssistivePrompt(req: AssistiveRequest): string {
  const sel = req.selection?.trim();
  const base = `[Assistive Agent — ${req.action}] File: ${req.filePath}\n`;
  if (req.action === 'fix') {
    return `${base}Fix errors in this code. Return ONLY the corrected code block, no explanation.\n${req.errorHint ? `Error: ${req.errorHint}\n` : ''}\n\`\`\`\n${sel || req.content.slice(0, 8000)}\n\`\`\``;
  }
  if (req.action === 'complete') {
    return `${base}Complete the code at cursor (line ${req.cursorLine ?? '?'}). Return only the completion snippet.\n\`\`\`\n${req.content.slice(-2000)}\n\`\`\``;
  }
  if (req.action === 'explain') {
    return `${base}Briefly explain this selection:\n\`\`\`\n${sel || req.content.slice(0, 4000)}\n\`\`\``;
  }
  return `${base}Suggest improvements for speed and correctness. Be concise.\n\`\`\`\n${req.content.slice(0, 6000)}\n\`\`\``;
}

function resolveModelFromConfig(config: AssistiveAgentConfig): { providerId: string; modelId: string } {
  switch (config.source) {
    case 'byok':
      return { providerId: config.byokProviderId || config.providerId, modelId: config.modelId };
    case 'mcp':
    case 'plugin':
    case 'local':
      return { providerId: config.providerId || 'openai', modelId: config.modelId };
    default:
      return { providerId: config.providerId, modelId: config.modelId };
  }
}

export async function runAssistiveAgent(
  req: AssistiveRequest,
  config: AssistiveAgentConfig,
  workspacePath: string,
  activeFile: string | null,
  terminalType: 'shell' | 'cloud' | 'native',
): Promise<string> {
  const ctx = await buildAgentContext({
    workspacePath,
    activeFile: activeFile ?? req.filePath,
    terminalType,
    skillScope: 'main',
    agentMode: 'auto',
  });

  const { providerId, modelId } = resolveModelFromConfig(config);
  const modelConfig = {
    ...(ctx.modelConfig as Record<string, unknown>),
    provider: providerId,
    modelId,
    selectedModelId: `${providerId}.${modelId}`,
    temperature: 0.2,
    maxTokens: 2048,
  };

  const assistiveContext = {
    ...ctx,
    modelConfig,
    assistiveAgent: {
      source: config.source,
      mcpConnectorId: config.mcpConnectorId,
      pluginId: config.pluginId,
      action: req.action,
    },
    _assistiveOnly: true,
  };

  const message = buildAssistivePrompt(req);
  const result = await runAgentInference(message, assistiveContext as unknown as Record<string, unknown>);
  return result.content;
}

/** Lightweight local syntax heuristics before calling AI */
export function detectQuickIssues(content: string, language: string): string[] {
  const issues: string[] = [];
  const lines = content.split('\n');
  if (language === 'typescript' || language === 'javascript') {
    const open = (content.match(/\{/g) ?? []).length;
    const close = (content.match(/\}/g) ?? []).length;
    if (open !== close) issues.push(`Unbalanced braces: ${open} open, ${close} close`);
    if (content.includes('console.log') && lines.length > 5) issues.push('Debug console.log present');
  }
  if (language === 'python') {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.trim().endsWith(':') && lines[i + 1] !== undefined && lines[i + 1].trim() && !lines[i + 1].startsWith(' ') && !lines[i + 1].startsWith('\t')) {
        issues.push(`Line ${i + 2}: possible missing indent after block on line ${i + 1}`);
      }
    }
  }
  return issues;
}
