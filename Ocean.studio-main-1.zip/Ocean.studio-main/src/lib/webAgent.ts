/** Web/mobile agent — real provider inference + vibe code tool loop */

import { runAgentInference } from './providerInference';
import { recordAgentResponse } from './agentSession';
import { runVibeCodeAgent } from './vibeCode/runner';
import { useVibeCodeStore } from '../store/vibeCodeStore';
import type { VibeToolCall, VibeToolResult } from './vibeCode/types';
import { shouldUseSelfControl } from './vibeCode/selfControl';

export type WebAgentEvent = {
  type: string;
  id: string;
  timestamp: number;
  summary: string;
  detail?: string;
  duration?: number;
  status?: string;
  metadata?: Record<string, unknown>;
};

type Listener = (event: WebAgentEvent) => void;

const listeners = new Set<Listener>();
let processing = false;
const queue: { message: string; context: Record<string, unknown>; resolve: (text: string) => void }[] = [];

export function onWebAgentEvent(cb: Listener): () => void {
  listeners.add(cb);
  return () => { listeners.delete(cb); };
}

function emit(event: WebAgentEvent) {
  listeners.forEach((cb) => cb(event));
}

async function processWebAgentQueue(): Promise<void> {
  if (processing) return;
  processing = true;

  while (queue.length > 0) {
    const item = queue.shift()!;
    const text = await executeWebAgent(item.message, item.context);
    item.resolve(text);
  }

  processing = false;
}

export async function runWebAgent(message: string, context: Record<string, unknown>): Promise<string> {
  return new Promise((resolve) => {
    queue.push({ message, context, resolve });
    void processWebAgentQueue();
  });
}

function isVibeCodeEligible(context: Record<string, unknown>, message?: string): boolean {
  const vibe = context.vibeCode as { enabled?: boolean; config?: { autoBootstrap?: boolean } } | undefined;
  const member = context.multiAgentMember as { archetype?: string } | undefined;
  const config = useVibeCodeStore.getState().config;
  const workspacePath = String(context.workspacePath ?? '');
  return shouldUseSelfControl({
    vibeEnabled: Boolean(vibe?.enabled ?? config.enabled),
    autoBootstrap: config.autoBootstrap,
    workspacePath: workspacePath || undefined,
    message,
    archetype: member?.archetype,
  });
}

async function executeWebAgent(message: string, context: Record<string, unknown>): Promise<string> {
  const phase = context._multiAgentPhase as string | undefined;
  const isSubAgent = phase === 'parallel-worker' || phase === 'collaborative' || phase === 'parallel-plan' || phase === 'parallel-synthesize';
  const member = context.multiAgentMember as { memberName?: string; providerId?: string; modelId?: string; archetype?: string } | undefined;

  const thoughtId = crypto.randomUUID();
  const start = Date.now();

  emit({
    type: 'thought',
    id: thoughtId,
    timestamp: start,
    summary: isSubAgent ? `${member?.memberName ?? 'Sub-agent'} working` : 'Analyzing request',
    status: 'running',
  });

  const vibeConfig = useVibeCodeStore.getState().config;
  const workspacePath = String(context.workspacePath ?? '');
  const agentMode = context.agentMode as 'review' | 'auto' | 'bypass' | undefined;
  const useVibe = isVibeCodeEligible(context, message) && workspacePath.length > 0;

  let inferenceContent: string;
  let inferenceMeta: { providerId: string; model?: string; source: string; toolsExecuted?: number };

  if (useVibe) {
    const vibeResult = await runVibeCodeAgent(message, context, vibeConfig, {
      workspacePath,
      agentMode: agentMode ?? vibeConfig.applyMode,
      terminalType: context.terminalType as 'shell' | 'cloud' | 'native' | undefined,
      onToolStart: (call: VibeToolCall) => {
        emit({
          type: 'action',
          id: crypto.randomUUID(),
          timestamp: Date.now(),
          summary: `Vibe: ${call.tool}`,
          detail: JSON.stringify(call.args).slice(0, 500),
          status: 'running',
        });
      },
      onToolEnd: (result: VibeToolResult) => {
        emit({
          type: result.success ? 'result' : 'error',
          id: crypto.randomUUID(),
          timestamp: Date.now(),
          summary: `${result.tool}: ${result.success ? 'OK' : 'failed'}`,
          detail: (result.error ?? result.output).slice(0, 1000),
          status: result.success ? 'completed' : 'failed',
        });
      },
      onIteration: (current, max) => {
        emit({
          type: 'status',
          id: crypto.randomUUID(),
          timestamp: Date.now(),
          summary: `Vibe code iteration ${current}/${max}`,
          status: 'running',
        });
      },
    });
    useVibeCodeStore.getState().setLastRunStats(vibeResult.toolsExecuted, vibeResult.iterations);
    inferenceContent = vibeResult.content;
    inferenceMeta = {
      providerId: vibeResult.providerId,
      model: vibeResult.model,
      source: vibeResult.source,
      toolsExecuted: vibeResult.toolsExecuted,
    };
  } else {
    const inference = await runAgentInference(message, context);
    inferenceContent = inference.content;
    inferenceMeta = { providerId: inference.providerId, model: inference.model, source: inference.source };
  }

  emit({
    type: 'thought',
    id: thoughtId,
    timestamp: Date.now(),
    summary: isSubAgent ? `${member?.memberName ?? 'Agent'} complete` : `Response ready (${inferenceMeta.source})`,
    detail: inferenceContent.slice(0, 800),
    duration: Date.now() - start,
    status: 'completed',
    metadata: {
      providerId: inferenceMeta.providerId,
      model: inferenceMeta.model,
      source: inferenceMeta.source,
      toolsExecuted: inferenceMeta.toolsExecuted,
    },
  });

  const actionId = crypto.randomUUID();
  emit({
    type: 'action',
    id: actionId,
    timestamp: Date.now(),
    summary: isSubAgent
      ? `${member?.memberName ?? 'Agent'}: ${inferenceMeta.model ?? inferenceMeta.providerId}`
      : useVibe ? `Vibe code (${inferenceMeta.toolsExecuted ?? 0} tools)` : `Inference via ${inferenceMeta.source}`,
    status: 'running',
    metadata: { phase, providerId: inferenceMeta.providerId },
  });

  emit({
    type: 'result',
    id: actionId,
    timestamp: Date.now(),
    summary: inferenceContent.slice(0, 120) + (inferenceContent.length > 120 ? '...' : ''),
    detail: inferenceContent,
    status: 'completed',
    metadata: { responseText: inferenceContent },
  });

  recordAgentResponse(inferenceContent, {
    providerId: inferenceMeta.providerId,
    source: inferenceMeta.source,
  });

  return inferenceContent;
}

export function pauseWebAgent() {
  queue.length = 0;
  processing = false;
  emit({
    type: 'status',
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    summary: 'Agent session paused',
    status: 'paused',
  });
}

export function getWebAgentStatus(): string {
  return processing ? 'running' : 'idle';
}
