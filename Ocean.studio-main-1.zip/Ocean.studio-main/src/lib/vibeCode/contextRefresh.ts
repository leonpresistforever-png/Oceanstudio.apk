import { useSkillsStore } from '../../skills/skillsStore';
import { useExtensionsStore } from '../../extensions/extensionsStore';
import { useModelStore } from '../../store/modelStore';
import { exportAgentMcpConfig } from '../../mcp/registry';
import { buildVibeCodeSystemAppendix } from './tools';
import { SELF_CONTROL_BOOTSTRAP } from './selfControl';
import type { VibeCodeConfig } from './types';

/** Rebuild agent context after self-modification so new skills/tools appear in the next iteration */
export function refreshVibeContext(
  baseContext: Record<string, unknown>,
  config: VibeCodeConfig,
  workspacePath: string
): Record<string, unknown> {
  const modelConfig = (baseContext.modelConfig ?? {}) as Record<string, unknown>;
  const customFunctions = useModelStore.getState().config.customFunctions;
  const skills = useSkillsStore.getState().installed
    .filter((s) => s.source === 'agent')
    .map((s) => ({ id: s.id, name: s.name, content: (s.content ?? '').slice(0, 2000) }));
  const extensions = useExtensionsStore.getState().installed
    .filter((e) => e.source === 'agent')
    .map((e) => ({ id: e.id, name: e.displayName, guide: (e.agentGuide ?? '').slice(0, 1500) }));
  const mcpExport = exportAgentMcpConfig();

  const appendix = buildVibeCodeSystemAppendix(config, workspacePath);
  const bootstrap = config.autoBootstrap ? `\n\n${SELF_CONTROL_BOOTSTRAP}` : '';

  return {
    ...baseContext,
    modelConfig: {
      ...modelConfig,
      customFunctions,
      customInstructions: `${String(modelConfig.customInstructions ?? '')}\n\n${appendix}${bootstrap}`,
    },
    vibeCode: {
      enabled: true,
      config,
      refreshedAt: Date.now(),
      agentSkills: skills,
      agentExtensions: extensions,
    },
    mcpServers: (mcpExport.mcpServers as Record<string, unknown>) ?? baseContext.mcpServers,
    mcpMeta: {
      ...(baseContext.mcpMeta as Record<string, unknown> ?? {}),
      connectedCount: (mcpExport.connectedCount as number) ?? 0,
      updatedAt: mcpExport.updatedAt,
    },
  };
}
