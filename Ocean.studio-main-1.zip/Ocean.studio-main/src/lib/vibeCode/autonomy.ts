/** Internet search, store fetch, and system inspection for autonomous agents */

export interface WebSearchResult {
  title: string;
  url: string;
  snippet: string;
  source: 'github' | 'npm' | 'web' | 'mcp';
}

export async function searchInternet(query: string, limit = 15): Promise<WebSearchResult[]> {
  const results: WebSearchResult[] = [];
  const q = query.trim();
  if (!q) return results;

  const [github, npm, web] = await Promise.all([
    searchGitHub(q, Math.ceil(limit / 3)),
    searchNpm(q, Math.ceil(limit / 3)),
    searchWebLite(q, Math.ceil(limit / 3)),
  ]);
  results.push(...github, ...npm, ...web);

  const seen = new Set<string>();
  return results.filter((r) => {
    if (seen.has(r.url)) return false;
    seen.add(r.url);
    return true;
  }).slice(0, limit);
}

async function searchGitHub(query: string, limit: number): Promise<WebSearchResult[]> {
  try {
    const res = await fetch(
      `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&per_page=${limit}`
    );
    if (!res.ok) return [];
    const data = await res.json() as { items: { full_name: string; html_url: string; description: string | null; stargazers_count: number }[] };
    return (data.items ?? []).map((r) => ({
      title: r.full_name,
      url: r.html_url,
      snippet: r.description ?? `${r.stargazers_count} stars`,
      source: 'github' as const,
    }));
  } catch {
    return [];
  }
}

async function searchNpm(query: string, limit: number): Promise<WebSearchResult[]> {
  try {
    const res = await fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}&size=${limit}`);
    if (!res.ok) return [];
    const data = await res.json() as { objects: { package: { name: string; description: string; links?: { npm?: string } } }[] };
    return (data.objects ?? []).map((o) => ({
      title: o.package.name,
      url: o.package.links?.npm ?? `https://www.npmjs.com/package/${o.package.name}`,
      snippet: o.package.description ?? 'npm package',
      source: 'npm' as const,
    }));
  } catch {
    return [];
  }
}

async function searchWebLite(query: string, limit: number): Promise<WebSearchResult[]> {
  try {
    const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_redirect=1`);
    if (!res.ok) return [];
    const data = await res.json() as {
      AbstractURL?: string;
      AbstractText?: string;
      Heading?: string;
      RelatedTopics?: { Text?: string; FirstURL?: string }[];
    };
    const out: WebSearchResult[] = [];
    if (data.AbstractURL) {
      out.push({ title: data.Heading ?? query, url: data.AbstractURL, snippet: data.AbstractText ?? '', source: 'web' });
    }
    for (const t of data.RelatedTopics ?? []) {
      if (t.FirstURL && t.Text) {
        out.push({ title: t.Text.slice(0, 80), url: t.FirstURL, snippet: t.Text, source: 'web' });
        if (out.length >= limit) break;
      }
    }
    return out;
  } catch {
    return [];
  }
}

export async function fetchUrlContent(url: string, maxChars = 50_000): Promise<{ ok: boolean; content: string; contentType?: string }> {
  try {
    const res = await fetch(url, { headers: { Accept: 'text/html,application/json,text/plain,*/*' } });
    const contentType = res.headers.get('content-type') ?? undefined;
    const text = await res.text();
    return { ok: res.ok, content: text.slice(0, maxChars), contentType };
  } catch (e) {
    return { ok: false, content: e instanceof Error ? e.message : 'Fetch failed' };
  }
}

export type StoreType = 'npm' | 'pip' | 'github' | 'mcp' | 'plugin';

export async function fetchStore(store: StoreType, query: string, limit = 20): Promise<WebSearchResult[]> {
  switch (store) {
    case 'npm':
    case 'mcp':
      return searchNpm(query.includes('mcp') ? query : `${query} mcp`, limit);
    case 'github':
      return searchGitHub(query, limit);
    case 'pip':
      return searchNpm(`pypi ${query}`, limit);
    case 'plugin':
      return searchNpm(`ocean plugin ${query}`, limit);
    default:
      return searchInternet(query, limit);
  }
}

export function installAppCommand(platform: string, appName: string, method?: string): string {
  const app = appName.trim();
  if (method === 'npm' || app.startsWith('@') || app.startsWith('npx ')) {
    return app.startsWith('npx') ? app : `npm install -g ${app}`;
  }
  if (method === 'pip' || app.includes('==')) return `pip install ${app}`;
  if (method === 'cargo') return `cargo install ${app}`;
  if (method === 'go') return `go install ${app}@latest`;
  if (method === 'snap') return `sudo snap install ${app}`;
  if (method === 'brew') return `brew install ${app}`;
  if (method === 'apt' || platform.includes('linux')) return `sudo apt-get update && sudo apt-get install -y ${app}`;
  if (platform.includes('win')) return `winget install ${app}`;
  if (platform.includes('darwin')) return `brew install ${app}`;
  return `sudo apt-get install -y ${app} || brew install ${app} || npm install -g ${app}`;
}

export const INSPECT_SYSTEM_COMMANDS: Record<string, string> = {
  os: 'uname -a 2>/dev/null || ver',
  disk: 'df -h 2>/dev/null || wmic logicaldisk get size,freespace,caption',
  memory: 'free -h 2>/dev/null || wmic OS get FreePhysicalMemory,TotalVisibleMemorySize',
  processes: 'ps aux 2>/dev/null | head -30 || tasklist',
  network: 'ip addr 2>/dev/null || ifconfig 2>/dev/null || ipconfig',
  docker: 'docker ps -a 2>/dev/null || echo "Docker not available"',
  node: 'node --version && npm --version',
  python: 'python3 --version 2>/dev/null || python --version',
  ollama: 'ollama list 2>/dev/null || echo "Ollama not installed"',
  gpu: 'nvidia-smi 2>/dev/null || echo "No NVIDIA GPU detected"',
};
