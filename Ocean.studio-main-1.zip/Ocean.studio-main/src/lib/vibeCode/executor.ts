import { getOceanAPI } from '../platform';
import { useSkillsStore } from '../../skills/skillsStore';
import { useExtensionsStore } from '../../extensions/extensionsStore';
import { useModelStore } from '../../store/modelStore';
import { getSandboxPreset } from '../../mcp/sandboxCatalog';
import { buildSandboxConnectPayload, connectorIdForSandbox, instanceFromPreset } from '../../mcp/sandboxRuntime';
import { upsertConnection, buildCustomConnection } from '../../mcp/registry';
import { searchOpenSourceMcp, searchLocalMcpPackages } from '../../mcp/researcher';
import { OFFICIAL_PLUGINS } from '../../plugins/marketplace/official';
import { installPlugin } from '../../plugins/registry';
import {
  searchInternet, fetchUrlContent, fetchStore, installAppCommand,
  INSPECT_SYSTEM_COMMANDS, type StoreType,
} from './autonomy';
import {
  defaultInjectPath, formatAppConfig, mergeFastFlags, registerInjection, setFastFlags,
} from '../contextInjection';
import type {
  VibeCodeConfig,
  VibeCodeRunOptions,
  VibePendingAction,
  VibeToolCall,
  VibeToolResult,
} from './types';
import { approveVibeAction } from './approval';

function resolvePath(workspacePath: string, relPath: string): string {
  const clean = relPath.replace(/\\/g, '/').replace(/^\.\//, '');
  const base = workspacePath.replace(/\\/g, '/').replace(/\/$/, '');
  if (!base) throw new Error('Workspace path required');

  let resolved: string;
  if (clean.startsWith('/')) {
    resolved = clean.replace(/\/+/g, '/');
  } else {
    resolved = `${base}/${clean}`.replace(/\/+/g, '/');
  }

  if (resolved.includes('/../') || resolved.endsWith('/..') || resolved.includes('/./')) {
    throw new Error('Invalid path');
  }
  if (resolved !== base && !resolved.startsWith(`${base}/`)) {
    throw new Error('Path outside workspace');
  }
  return resolved;
}

function isPathAllowed(relPath: string, roots: string[]): boolean {
  const norm = relPath.replace(/\\/g, '/').replace(/^\.\//, '');
  if (norm.includes('..')) return false;
  return roots.some((root) => {
    const r = root.replace(/^\.\//, '').replace(/\/$/, '');
    return norm === r || norm.startsWith(`${r}/`);
  });
}

function summarizeAction(call: VibeToolCall): string {
  const a = call.args;
  switch (call.tool) {
    case 'write_file': return `Write ${a.path}`;
    case 'run_terminal': return `Run: ${String(a.command ?? '').slice(0, 80)}`;
    case 'create_skill': return `Create skill: ${a.name}`;
    case 'create_extension': return `Create extension: ${a.name}`;
    case 'create_requirements': return `Write ${a.language} requirements`;
    case 'create_system_file': return `Write system file: ${a.path}`;
    case 'create_custom_function': return `Register function: ${a.name}`;
    case 'create_plugin_manifest': return `Create plugin: ${a.id}`;
    case 'install_dependency': return `Install ${a.language}: ${(a.packages as string[])?.join(', ')}`;
    case 'configure_terminal': return `Configure terminal: ${a.terminalType ?? a.type}`;
    case 'connect_sandbox_mcp': return `Connect sandbox MCP: ${a.presetId ?? a.name}`;
    case 'create_ui_asset': return `Create UI: ${a.path}`;
    case 'provision_capability': return `Provision: ${a.name}`;
    case 'create_system_feature': return `App feature: ${a.id ?? a.name}`;
    case 'web_search': return `Search: ${a.query}`;
    case 'fetch_url': return `Fetch: ${a.url}`;
    case 'discover_mcp': return `Discover MCP: ${a.query}`;
    case 'connect_mcp': return `Connect MCP: ${a.name ?? a.url}`;
    case 'install_plugin': return `Install plugin: ${a.pluginId ?? a.id}`;
    case 'create_plugin_compat': return `Plugin compat: ${a.pluginId}`;
    case 'install_app': return `Install app: ${a.name ?? a.app}`;
    case 'fetch_store': return `Store ${a.store}: ${a.query}`;
    case 'inspect_system': return `Inspect: ${a.target ?? 'os'}`;
    case 'download_file': return `Download: ${a.url}`;
    case 'inject_context_file': return `Inject file: ${a.path ?? a.label}`;
    case 'inject_fastflag': return `FastFlags: ${a.app}`;
    case 'inject_app_config': return `App config: ${a.app}`;
    default: return call.tool;
  }
}

function requirementsContent(language: string, packages: string[]): { path: string; content: string } {
  const lang = language.toLowerCase();
  if (lang === 'python') {
    return { path: 'requirements.txt', content: `${packages.join('\n')}\n` };
  }
  if (lang === 'node' || lang === 'javascript' || lang === 'typescript') {
    const deps = Object.fromEntries(packages.map((p) => [p, 'latest']));
    return {
      path: 'package.json',
      content: JSON.stringify({ name: 'agent-generated', version: '1.0.0', dependencies: deps }, null, 2),
    };
  }
  if (lang === 'rust') {
    const lines = packages.map((p) => `${p} = "*"`).join('\n');
    return { path: 'Cargo.toml', content: `[package]\nname = "agent-generated"\nversion = "0.1.0"\n\n[dependencies]\n${lines}\n` };
  }
  if (lang === 'go') {
    return { path: 'go.mod', content: `module agent-generated\n\ngo 1.22\n\nrequire (\n${packages.map((p) => `\t${p} latest`).join('\n')}\n)\n` };
  }
  return { path: `${lang}-requirements.txt`, content: packages.join('\n') };
}

function installCommand(language: string, packages: string[]): string {
  const lang = language.toLowerCase();
  const list = packages.join(' ');
  if (lang === 'python') return `pip install ${list}`;
  if (lang === 'node' || lang === 'javascript' || lang === 'typescript') return `npm install ${list}`;
  if (lang === 'rust') return `cargo add ${list}`;
  if (lang === 'go') return `go get ${packages.map((p) => `${p}@latest`).join(' ')}`;
  return `echo "Install manually: ${list}"`;
}

const TERMINAL_STATE = { id: 'ocean-vibe-code-terminal', type: 'shell' as 'shell' | 'cloud' | 'native', ready: false };

async function ensureTerminal(cwd: string, config: VibeCodeConfig, opts: VibeCodeRunOptions): Promise<void> {
  const termId = config.terminalId;
  const termType = opts.terminalType ?? config.terminalType;
  TERMINAL_STATE.id = termId;
  TERMINAL_STATE.type = termType;
  if (TERMINAL_STATE.ready) return;
  const api = getOceanAPI();
  try {
    await api.terminal.create({ id: termId, type: termType, cwd });
    TERMINAL_STATE.ready = true;
  } catch {
    TERMINAL_STATE.ready = true;
  }
}

async function runTerminalCommand(
  command: string,
  cwd: string,
  config: VibeCodeConfig,
  opts: VibeCodeRunOptions,
  timeoutMs = 30_000
): Promise<{ output: string; success: boolean }> {
  const api = getOceanAPI();
  const termId = config.terminalId;
  await ensureTerminal(cwd, config, opts);
  return new Promise((resolve) => {
    let output = '';
    const unsub = api.terminal.onData?.((id, data) => {
      if (id === termId) output += data;
    });
    api.terminal.write(termId, `${command}\n`);
    setTimeout(() => {
      unsub?.();
      const tail = output.slice(-8000) || `Executed: ${command}`;
      const failed = /\b(error|failed|not found|command not found|ENOENT)\b/i.test(tail) && !/\b0 error/i.test(tail);
      resolve({ output: tail, success: !failed });
    }, timeoutMs);
  });
}

export async function executeVibeTool(
  call: VibeToolCall,
  workspacePath: string,
  config: VibeCodeConfig,
  opts: VibeCodeRunOptions,
  pendingQueue: VibePendingAction[]
): Promise<VibeToolResult> {
  const api = getOceanAPI();
  const applyMode = opts.agentMode ?? config.applyMode;
  const needsApproval = (
    call.tool === 'write_file'
    || call.tool === 'run_terminal'
    || call.tool === 'install_dependency'
    || call.tool === 'configure_terminal'
    || call.tool === 'connect_sandbox_mcp'
    || call.tool === 'provision_capability'
    || call.tool === 'create_system_feature'
    || call.tool === 'connect_mcp'
    || call.tool === 'install_plugin'
    || call.tool === 'install_app'
    || call.tool === 'download_file'
  ) && applyMode === 'review';

  if (needsApproval) {
    const action: VibePendingAction = {
      id: crypto.randomUUID(),
      tool: call.tool,
      args: call.args,
      summary: summarizeAction(call),
      createdAt: Date.now(),
    };
    pendingQueue.push(action);
    opts.onPendingAction?.(action);
    const approve = opts.approveAction ?? (async () => approveVibeAction(action));
    const approved = await approve(action.id);
    if (!approved) {
      return { tool: call.tool, success: false, output: 'User rejected action', pendingApproval: true, approvalId: action.id };
    }
  }

  try {
    switch (call.tool) {
      case 'done':
        return { tool: call.tool, success: true, output: String(call.args.summary ?? 'Done') };

      case 'read_file': {
        const path = String(call.args.path ?? '');
        const content = await api.fs.readFile(resolvePath(workspacePath, path));
        return { tool: call.tool, success: true, output: content.slice(0, 50_000) };
      }

      case 'list_dir': {
        const path = String(call.args.path ?? '.');
        const entries = await api.fs.readDir(resolvePath(workspacePath, path));
        return { tool: call.tool, success: true, output: JSON.stringify(entries, null, 2) };
      }

      case 'write_file': {
        const rel = String(call.args.path ?? '');
        if (!isPathAllowed(rel, config.writePaths)) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${rel}` };
        }
        const content = String(call.args.content ?? '');
        await api.fs.writeFile(resolvePath(workspacePath, rel), content);
        return { tool: call.tool, success: true, output: `Wrote ${rel} (${content.length} bytes)` };
      }

      case 'run_terminal': {
        const command = String(call.args.command ?? '');
        const cwd = call.args.cwd ? resolvePath(workspacePath, String(call.args.cwd)) : workspacePath;
        const { output, success } = await runTerminalCommand(command, cwd, config, opts);
        return { tool: call.tool, success, output: success ? output : output, error: success ? undefined : 'Command may have failed — check output' };
      }

      case 'create_skill': {
        if (!config.allowSkillCreate) {
          return { tool: call.tool, success: false, output: '', error: 'Skill creation disabled' };
        }
        const name = String(call.args.name ?? 'Agent Skill');
        const content = String(call.args.content ?? '');
        const result = useSkillsStore.getState().addAgentSkill(name, content);
        if (!result.ok) {
          return { tool: call.tool, success: false, output: '', error: result.reason };
        }
        if (call.args.writeToDisk !== false && workspacePath) {
          const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
          const path = `agent/generated/${slug}.md`;
          await api.fs.writeFile(resolvePath(workspacePath, path), content);
        }
        return { tool: call.tool, success: true, output: `Skill "${name}" installed` };
      }

      case 'create_extension': {
        const name = String(call.args.name ?? 'Extension');
        const guide = String(call.args.guide ?? call.args.content ?? '');
        const result = useExtensionsStore.getState().addAgentExtension(name, guide);
        if (!result.ok) {
          return { tool: call.tool, success: false, output: '', error: result.reason };
        }
        return { tool: call.tool, success: true, output: `Extension "${name}" registered` };
      }

      case 'create_requirements': {
        const language = String(call.args.language ?? 'python');
        const packages = Array.isArray(call.args.packages) ? call.args.packages.map(String) : [];
        const { path, content } = requirementsContent(language, packages);
        const rel = String(call.args.path ?? path);
        if (!isPathAllowed(rel, config.writePaths)) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${rel}` };
        }
        await api.fs.writeFile(resolvePath(workspacePath, rel), content);
        return { tool: call.tool, success: true, output: `Wrote ${rel}` };
      }

      case 'create_system_file': {
        if (!config.allowSelfModify) {
          return { tool: call.tool, success: false, output: '', error: 'Self-modify disabled' };
        }
        const rel = String(call.args.path ?? '');
        if (!isPathAllowed(rel, [...config.systemPaths, ...config.writePaths])) {
          return { tool: call.tool, success: false, output: '', error: `System path not allowed: ${rel}` };
        }
        const content = String(call.args.content ?? '');
        await api.fs.writeFile(resolvePath(workspacePath, rel), content);
        return { tool: call.tool, success: true, output: `System file written: ${rel}` };
      }

      case 'create_custom_function': {
        const name = String(call.args.name ?? 'custom_fn');
        useModelStore.getState().addCustomFunction({
          id: `vibe.${crypto.randomUUID()}`,
          name,
          description: String(call.args.description ?? `Agent-created function: ${name}`),
          parameters: (call.args.parameters as Record<string, unknown>) ?? { type: 'object', properties: {} },
        });
        return { tool: call.tool, success: true, output: `Function "${name}" registered` };
      }

      case 'create_plugin_manifest': {
        if (!config.allowPluginCreate) {
          return { tool: call.tool, success: false, output: '', error: 'Plugin creation disabled' };
        }
        const id = String(call.args.id ?? 'agent-plugin');
        const name = String(call.args.name ?? id);
        const entry = String(call.args.entry ?? 'index.js');
        const description = String(call.args.description ?? `Agent-created plugin: ${name}`);
        const manifest = {
          id,
          name,
          version: '1.0.0',
          description,
          entry,
          tools: [{ name: `${id}_tool`, description }],
        };
        const rel = `.ocean/plugins/${id}/ocean.plugin.json`;
        await api.fs.writeFile(resolvePath(workspacePath, rel), JSON.stringify(manifest, null, 2));
        if (call.args.entryContent) {
          await api.fs.writeFile(resolvePath(workspacePath, `.ocean/plugins/${id}/${entry}`), String(call.args.entryContent));
        }
        return { tool: call.tool, success: true, output: `Plugin manifest at ${rel}` };
      }

      case 'install_dependency': {
        const language = String(call.args.language ?? 'python');
        const packages = Array.isArray(call.args.packages) ? call.args.packages.map(String) : [];
        const cmd = installCommand(language, packages);
        const { output, success } = await runTerminalCommand(cmd, workspacePath, config, opts, 90_000);
        return { tool: call.tool, success, output, error: success ? undefined : 'Install may have failed' };
      }

      case 'configure_terminal': {
        const termType = String(call.args.terminalType ?? call.args.type ?? 'shell') as 'shell' | 'cloud' | 'native';
        const termId = String(call.args.terminalId ?? config.terminalId);
        const setupCommands = Array.isArray(call.args.setupCommands)
          ? call.args.setupCommands.map(String)
          : call.args.command ? [String(call.args.command)] : [];

        config.terminalType = termType;
        config.terminalId = termId;
        TERMINAL_STATE.ready = false;
        TERMINAL_STATE.id = termId;
        TERMINAL_STATE.type = termType;

        const api = getOceanAPI();
        await api.terminal.create({ id: termId, type: termType, cwd: workspacePath });

        const outputs: string[] = [`Terminal configured: ${termId} (${termType})`];
        for (const cmd of setupCommands) {
          const { output, success } = await runTerminalCommand(cmd, workspacePath, config, opts, 120_000);
          outputs.push(`$ ${cmd}\n${output}`);
          if (!success) {
            return { tool: call.tool, success: false, output: outputs.join('\n\n'), error: `Setup command failed: ${cmd}` };
          }
        }
        return { tool: call.tool, success: true, output: outputs.join('\n\n') };
      }

      case 'connect_sandbox_mcp': {
        if (!config.allowMcpProvision) {
          return { tool: call.tool, success: false, output: '', error: 'MCP provisioning disabled' };
        }
        const presetId = String(call.args.presetId ?? 'sandbox.custom-stdio');
        const preset = getSandboxPreset(presetId);
        if (!preset) {
          return { tool: call.tool, success: false, output: '', error: `Unknown sandbox preset: ${presetId}` };
        }
        const instance = instanceFromPreset(preset, String(call.args.name ?? preset.name));
        if (call.args.command) instance.command = String(call.args.command);
        if (call.args.args) {
          instance.args = Array.isArray(call.args.args) ? call.args.args.map(String) : String(call.args.args).split(/\s+/);
        }
        if (call.args.env && typeof call.args.env === 'object') {
          instance.env = { ...instance.env, ...(call.args.env as Record<string, string>) };
        }
        const payload = buildSandboxConnectPayload(instance, preset);
        const api = getOceanAPI() as { mcp?: { connect: (cfg: unknown) => Promise<{ status?: string; error?: string }> } };
        if (!api.mcp?.connect) {
          return { tool: call.tool, success: false, output: '', error: 'MCP connect requires Electron desktop' };
        }
        const result = await api.mcp.connect(payload);
        const connId = connectorIdForSandbox(instance.id);
        upsertConnection({
          connectorId: connId,
          name: instance.name,
          transport: 'stdio',
          hosting: 'local',
          runtime: instance.runtime,
          config: {
            command: payload.command ?? '',
            args: JSON.stringify(payload.args ?? []),
            runtime: instance.runtime,
            ...payload.env,
          },
          status: (result.status as 'connected' | 'error' | 'connecting') ?? 'connected',
          error: result.error,
          sandbox: true,
          connectedAt: Date.now(),
        });
        return { tool: call.tool, success: result.status !== 'error', output: `Sandbox MCP connected: ${instance.name} (${connId})`, error: result.error };
      }

      case 'create_ui_asset': {
        const format = String(call.args.format ?? 'html').toLowerCase();
        const rel = String(call.args.path ?? `public/agent-ui.${format === 'markdown' ? 'md' : format}`);
        if (!isPathAllowed(rel, config.writePaths)) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${rel}` };
        }
        let content = String(call.args.content ?? '');
        if (!content && call.args.title) {
          const title = String(call.args.title);
          if (format === 'html') {
            content = `<!DOCTYPE html>\n<html><head><meta charset="utf-8"><title>${title}</title>\n<style>${String(call.args.css ?? 'body{font-family:system-ui;margin:2rem;}')}</style></head>\n<body>\n${String(call.args.body ?? `<h1>${title}</h1>`)}\n</body></html>`;
          } else if (format === 'md' || format === 'markdown') {
            content = `# ${title}\n\n${String(call.args.body ?? '')}\n`;
          } else if (format === 'css') {
            content = String(call.args.css ?? `/* ${title} */\n`);
          } else if (format === 'json') {
            content = JSON.stringify(call.args.data ?? { title }, null, 2);
          }
        }
        await api.fs.writeFile(resolvePath(workspacePath, rel), content);
        return { tool: call.tool, success: true, output: `UI asset written: ${rel} (${format})` };
      }

      case 'provision_capability': {
        const name = String(call.args.name ?? 'capability');
        const description = String(call.args.description ?? `Self-provisioned: ${name}`);
        const steps: string[] = [];

        if (call.args.skillContent || call.args.skill) {
          const skillContent = String(call.args.skillContent ?? call.args.skill);
          const skillResult = useSkillsStore.getState().addAgentSkill(name, skillContent);
          if (skillResult.ok) {
            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
            const skillPath = `agent/generated/${slug}.md`;
            await api.fs.writeFile(resolvePath(workspacePath, skillPath), skillContent);
            steps.push(`Skill created: ${name} → ${skillPath}`);
          }
        }

        if (call.args.systemFile && call.args.systemContent) {
          const sysPath = String(call.args.systemFile);
          if (isPathAllowed(sysPath, [...config.systemPaths, ...config.writePaths])) {
            await api.fs.writeFile(resolvePath(workspacePath, sysPath), String(call.args.systemContent));
            steps.push(`System file: ${sysPath}`);
          }
        }

        if (call.args.packages && call.args.language) {
          const language = String(call.args.language);
          const packages = Array.isArray(call.args.packages) ? call.args.packages.map(String) : [];
          const { path, content } = requirementsContent(language, packages);
          await api.fs.writeFile(resolvePath(workspacePath, path), content);
          steps.push(`Requirements: ${path}`);
          const cmd = installCommand(language, packages);
          const { output, success } = await runTerminalCommand(cmd, workspacePath, config, opts, 120_000);
          steps.push(`Install: ${cmd}\n${output.slice(0, 2000)}`);
          if (!success) {
            return { tool: call.tool, success: false, output: steps.join('\n'), error: 'Dependency install failed' };
          }
        }

        if (call.args.terminalSetup) {
          const setup = Array.isArray(call.args.terminalSetup)
            ? call.args.terminalSetup.map(String)
            : [String(call.args.terminalSetup)];
          for (const cmd of setup) {
            const { output } = await runTerminalCommand(cmd, workspacePath, config, opts, 120_000);
            steps.push(`Terminal: ${cmd}\n${output.slice(0, 1000)}`);
          }
        }

        if (call.args.mcpPresetId) {
          const inner = await executeVibeTool(
            { id: crypto.randomUUID(), tool: 'connect_sandbox_mcp', args: { presetId: call.args.mcpPresetId, name: `${name} MCP` } },
            workspacePath, config, opts, pendingQueue
          );
          steps.push(inner.output);
          if (!inner.success) {
            return { tool: call.tool, success: false, output: steps.join('\n'), error: inner.error };
          }
        }

        if (call.args.customFunction) {
          const fn = call.args.customFunction as Record<string, unknown>;
          useModelStore.getState().addCustomFunction({
            id: `vibe.${crypto.randomUUID()}`,
            name: String(fn.name ?? name),
            description: String(fn.description ?? description),
            parameters: (fn.parameters as Record<string, unknown>) ?? { type: 'object', properties: {} },
          });
          steps.push(`Custom function registered: ${fn.name ?? name}`);
        }

        return {
          tool: call.tool,
          success: steps.length > 0,
          output: steps.length ? steps.join('\n\n') : `Provisioned capability metadata: ${description}`,
          error: steps.length ? undefined : 'No provision steps executed — provide skill, packages, terminalSetup, or mcpPresetId',
        };
      }

      case 'create_system_feature': {
        if (!config.allowSelfModify) {
          return { tool: call.tool, success: false, output: '', error: 'System feature creation requires self-modify' };
        }
        const featureId = String(call.args.id ?? call.args.name ?? 'agent-feature').replace(/[^a-z0-9-]/gi, '-').toLowerCase();
        const featureName = String(call.args.name ?? featureId);
        const description = String(call.args.description ?? `Agent-created feature: ${featureName}`);
        const componentPath = String(call.args.componentPath ?? `src/features/${featureId}/${featureName.replace(/\s+/g, '')}Panel.tsx`);
        const componentContent = String(call.args.componentContent ?? call.args.content ?? `export default function ${featureName.replace(/\s+/g, '')}Panel() {\n  return <div><h2>${featureName}</h2><p>${description}</p></div>;\n}\n`);
        const manifest = {
          id: featureId,
          name: featureName,
          description,
          version: '1.0.0',
          createdBy: 'agent',
          createdAt: new Date().toISOString(),
          routes: [{ path: `/feature/${featureId}`, view: featureId, label: featureName }],
          componentPath,
          storePath: call.args.storePath ?? `src/store/${featureId}Store.ts`,
          enabled: true,
        };
        const manifestPath = `.ocean/features/${featureId}/feature.json`;
        await api.fs.writeFile(resolvePath(workspacePath, manifestPath), JSON.stringify(manifest, null, 2));
        if (isPathAllowed(componentPath, config.writePaths)) {
          await api.fs.writeFile(resolvePath(workspacePath, componentPath), componentContent);
        }
        if (call.args.skillContent) {
          const skillPath = `agent/generated/feature-${featureId}.md`;
          await api.fs.writeFile(resolvePath(workspacePath, skillPath), String(call.args.skillContent));
          useSkillsStore.getState().addAgentSkill(`${featureName} Feature`, String(call.args.skillContent));
        }
        return {
          tool: call.tool,
          success: true,
          output: `System feature created: ${featureName}\nManifest: ${manifestPath}\nComponent: ${componentPath}\nAdd to LeftSidebar/CenterPanel to surface in app UI.`,
        };
      }

      case 'web_search': {
        if (!config.allowInternet) {
          return { tool: call.tool, success: false, output: '', error: 'Internet access disabled in vibe config' };
        }
        const query = String(call.args.query ?? '');
        const limit = Number(call.args.limit ?? 15);
        const results = await searchInternet(query, limit);
        const summary = results.map((r, i) => `${i + 1}. [${r.source}] ${r.title}\n   ${r.url}\n   ${r.snippet}`).join('\n\n');
        if (call.args.writeSkill && results.length) {
          const skillContent = `# Web Research: ${query}\n\n${results.map((r) => `- [${r.title}](${r.url}): ${r.snippet}`).join('\n')}`;
          useSkillsStore.getState().addAgentSkill(`Research: ${query.slice(0, 40)}`, skillContent);
          await api.fs.writeFile(
            resolvePath(workspacePath, `agent/generated/research-${Date.now()}.md`),
            skillContent
          );
        }
        return { tool: call.tool, success: true, output: summary || 'No results found' };
      }

      case 'fetch_url': {
        if (!config.allowInternet) {
          return { tool: call.tool, success: false, output: '', error: 'Internet access disabled' };
        }
        const url = String(call.args.url ?? '');
        const maxChars = Number(call.args.maxChars ?? 50_000);
        const { ok, content, contentType } = await fetchUrlContent(url, maxChars);
        if (call.args.savePath && ok) {
          const savePath = String(call.args.savePath);
          if (isPathAllowed(savePath, config.writePaths)) {
            await api.fs.writeFile(resolvePath(workspacePath, savePath), content);
          }
        }
        return { tool: call.tool, success: ok, output: contentType ? `[${contentType}]\n${content}` : content };
      }

      case 'discover_mcp': {
        if (!config.allowMcpAutoConnect) {
          return { tool: call.tool, success: false, output: '', error: 'MCP auto-discovery disabled' };
        }
        const query = String(call.args.query ?? 'mcp server');
        const platform = (call.args.platform as 'electron' | 'web' | 'mobile') ?? 'electron';
        const [cloud, local] = await Promise.all([
          searchOpenSourceMcp(query, platform),
          platform === 'electron' ? searchLocalMcpPackages(query) : Promise.resolve([]),
        ]);
        const combined = [...cloud, ...local].slice(0, Number(call.args.limit ?? 20));
        const lines = combined.map((m) =>
          `- ${m.id} | ${m.name} | ${m.transport} | ${m.hosting}${m.url ? ` | ${m.url}` : ''}${m.command ? ` | ${m.command}` : ''}`
        );
        if (call.args.writeSystemFile !== false && lines.length) {
          const content = `# Discovered MCP Servers\nQuery: ${query}\n\n${lines.join('\n')}\n`;
          await api.fs.writeFile(resolvePath(workspacePath, `agent/generated/mcp-discovered-${Date.now()}.md`), content);
        }
        return { tool: call.tool, success: true, output: lines.join('\n') || 'No MCP servers found' };
      }

      case 'connect_mcp': {
        if (!config.allowMcpAutoConnect) {
          return { tool: call.tool, success: false, output: '', error: 'MCP auto-connect disabled' };
        }
        const apiMcp = getOceanAPI() as { mcp?: { connect: (cfg: unknown) => Promise<{ status?: string; error?: string }> } };
        if (!apiMcp.mcp?.connect) {
          return { tool: call.tool, success: false, output: '', error: 'MCP connect requires Electron' };
        }
        const transport = String(call.args.transport ?? 'sse') as 'stdio' | 'sse' | 'http';
        const name = String(call.args.name ?? call.args.id ?? 'Agent MCP');
        const connectorId = `agent.mcp.${Date.now()}`;
        const env = (call.args.env as Record<string, string>) ?? {};
        let payload: Record<string, unknown>;
        if (transport === 'stdio') {
          payload = {
            id: connectorId, name, transport: 'stdio', hosting: 'local',
            command: call.args.command ?? 'npx',
            args: Array.isArray(call.args.args) ? call.args.args : String(call.args.args ?? '-y @modelcontextprotocol/server-filesystem').split(/\s+/),
            env,
          };
        } else {
          payload = {
            id: connectorId, name, transport, hosting: 'cloud',
            url: call.args.url, env,
          };
        }
        const result = await apiMcp.mcp.connect(payload);
        const conn = buildCustomConnection(name, transport, {
          ...(transport === 'stdio'
            ? { command: String(call.args.command ?? 'npx'), args: JSON.stringify(payload.args) }
            : { url: String(call.args.url ?? '') }),
          ...env,
        });
        conn.connectorId = connectorId;
        conn.status = (result.status as typeof conn.status) ?? 'connected';
        conn.error = result.error;
        upsertConnection(conn);
        if (call.args.writeConfig !== false) {
          const cfgPath = `agent/generated/mcp-${connectorId.replace(/\./g, '-')}.json`;
          await api.fs.writeFile(resolvePath(workspacePath, cfgPath), JSON.stringify(payload, null, 2));
        }
        return { tool: call.tool, success: result.status !== 'error', output: `MCP connected: ${name} (${connectorId})`, error: result.error };
      }

      case 'install_plugin': {
        if (!config.allowPluginCreate) {
          return { tool: call.tool, success: false, output: '', error: 'Plugin install disabled' };
        }
        const pluginId = String(call.args.pluginId ?? call.args.id ?? '');
        const manifest = OFFICIAL_PLUGINS.find((p) => p.id === pluginId)
          ?? (call.args.manifest as typeof OFFICIAL_PLUGINS[0] | undefined);
        if (!manifest) {
          return { tool: call.tool, success: false, output: '', error: `Plugin not found: ${pluginId}. Use discover_mcp or create_plugin_manifest.` };
        }
        const pluginApi = getOceanAPI() as { plugins?: { install: (m: unknown) => Promise<void>; start: (id: string) => Promise<void> } };
        installPlugin(manifest, call.args.config as Record<string, unknown> ?? {});
        await pluginApi.plugins?.install?.(manifest);
        if (call.args.start !== false) await pluginApi.plugins?.start?.(manifest.id);
        return { tool: call.tool, success: true, output: `Plugin installed: ${manifest.name} (${manifest.id})` };
      }

      case 'create_plugin_compat': {
        const pluginId = String(call.args.pluginId ?? call.args.id ?? 'plugin');
        const pluginName = String(call.args.name ?? pluginId);
        const compat = {
          pluginId,
          name: pluginName,
          oceanVersion: '0.1.0',
          mcpTransport: call.args.transport ?? 'stdio',
          env: call.args.env ?? {},
          hooks: call.args.hooks ?? ['onConnect', 'onToolCall'],
          createdAt: new Date().toISOString(),
        };
        const compatPath = `.ocean/plugins/compat/${pluginId}.json`;
        const skillContent = String(call.args.skillContent ?? `---\nname: ${pluginName}-compat\ndescription: Agent compatibility layer for ${pluginName}\n---\n\n# ${pluginName} Compatibility\n\nUse this plugin via Ocean MCP/tools. Config: ${JSON.stringify(compat.env)}`);
        await api.fs.writeFile(resolvePath(workspacePath, compatPath), JSON.stringify(compat, null, 2));
        await api.fs.writeFile(resolvePath(workspacePath, `agent/generated/plugin-${pluginId}.md`), skillContent);
        useSkillsStore.getState().addAgentSkill(`${pluginName} Plugin`, skillContent);
        return { tool: call.tool, success: true, output: `Plugin compatibility: ${compatPath} + skill registered` };
      }

      case 'install_app': {
        if (!config.allowAppInstall) {
          return { tool: call.tool, success: false, output: '', error: 'App install disabled in config' };
        }
        const platform = await getOceanAPI().platform.get();
        const appName = String(call.args.name ?? call.args.app ?? '');
        const method = call.args.method ? String(call.args.method) : undefined;
        const cmd = String(call.args.command ?? installAppCommand(platform.platform ?? 'linux', appName, method));
        const { output, success } = await runTerminalCommand(cmd, workspacePath, config, opts, 180_000);
        return { tool: call.tool, success, output: `$ ${cmd}\n${output}`, error: success ? undefined : 'Install may have failed' };
      }

      case 'fetch_store': {
        if (!config.allowInternet) {
          return { tool: call.tool, success: false, output: '', error: 'Internet disabled' };
        }
        const store = String(call.args.store ?? 'npm') as StoreType;
        const query = String(call.args.query ?? '');
        const results = await fetchStore(store, query, Number(call.args.limit ?? 20));
        return {
          tool: call.tool,
          success: true,
          output: results.map((r) => `[${r.source}] ${r.title}\n  ${r.url}\n  ${r.snippet}`).join('\n\n') || 'No store results',
        };
      }

      case 'inspect_system': {
        const target = String(call.args.target ?? 'os');
        const cmd = call.args.command
          ? String(call.args.command)
          : INSPECT_SYSTEM_COMMANDS[target] ?? INSPECT_SYSTEM_COMMANDS.os;
        const { output, success } = await runTerminalCommand(cmd, workspacePath, config, opts, 15_000);
        if (call.args.savePath) {
          const p = String(call.args.savePath);
          if (isPathAllowed(p, config.writePaths)) {
            await api.fs.writeFile(resolvePath(workspacePath, p), output);
          }
        }
        return { tool: call.tool, success, output };
      }

      case 'download_file': {
        if (!config.allowInternet) {
          return { tool: call.tool, success: false, output: '', error: 'Internet disabled' };
        }
        const url = String(call.args.url ?? '');
        const dest = String(call.args.path ?? `downloads/${url.split('/').pop() ?? 'file'}`);
        if (!isPathAllowed(dest, [...config.writePaths, 'downloads'])) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${dest}` };
        }
        const { ok, content } = await fetchUrlContent(url, 5_000_000);
        if (!ok) return { tool: call.tool, success: false, output: '', error: 'Download failed' };
        await api.fs.writeFile(resolvePath(workspacePath, dest), content);
        const viaTerminal = call.args.viaTerminal && /\.(tar|gz|zip|deb|rpm)$/i.test(dest);
        if (viaTerminal) {
          const { output } = await runTerminalCommand(`ls -la "${dest}"`, workspacePath, config, opts);
          return { tool: call.tool, success: true, output: `Downloaded to ${dest}\n${output}` };
        }
        return { tool: call.tool, success: true, output: `Downloaded ${content.length} bytes to ${dest}` };
      }

      case 'inject_context_file': {
        const rel = String(call.args.path ?? '');
        const label = String(call.args.label ?? rel.split('/').pop() ?? 'context');
        const scope = String(call.args.scope ?? 'session') as 'session' | 'agent' | 'workspace' | 'playground';
        let content = call.args.content != null ? String(call.args.content) : '';
        if (!content && rel) {
          content = await api.fs.readFile(resolvePath(workspacePath, rel));
        }
        const dest = String(call.args.dest ?? defaultInjectPath('file', label));
        if (!isPathAllowed(dest, [...config.writePaths, '.ocean/injected'])) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${dest}` };
        }
        await api.fs.writeFile(resolvePath(workspacePath, dest), content);
        const entry = registerInjection({
          type: 'file',
          path: dest,
          label,
          scope,
          charCount: content.length,
        });
        if (call.args.addToSkills) {
          useSkillsStore.getState().addAgentSkill(label, `---\nname: ${label}\ninjected: true\n---\n\n${content}`);
        }
        return { tool: call.tool, success: true, output: `Injected "${label}" → ${dest} (id: ${entry.id}, ${content.length} chars)` };
      }

      case 'inject_fastflag': {
        const app = String(call.args.app ?? 'app');
        const flags = (call.args.flags && typeof call.args.flags === 'object')
          ? call.args.flags as Record<string, boolean | string | number>
          : {};
        const merge = call.args.merge !== false;
        const existing = merge ? mergeFastFlags(app, flags) : setFastFlags(app, flags);
        const dest = String(call.args.path ?? defaultInjectPath('fastflag', app, app));
        if (!isPathAllowed(dest, [...config.writePaths, '.ocean/injected'])) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${dest}` };
        }
        await api.fs.writeFile(resolvePath(workspacePath, dest), JSON.stringify(existing, null, 2));
        registerInjection({
          type: 'fastflag',
          path: dest,
          label: `${app} fastflags`,
          scope: 'session',
          charCount: JSON.stringify(existing.flags).length,
        });
        return { tool: call.tool, success: true, output: `FastFlags for ${app}: ${Object.keys(flags).length} keys → ${dest}` };
      }

      case 'inject_app_config': {
        const app = String(call.args.app ?? 'app');
        const format = String(call.args.format ?? 'json') as 'json' | 'yaml' | 'env' | 'toml';
        const raw = call.args.config ?? call.args.content ?? {};
        const body = formatAppConfig(format, typeof raw === 'string' ? raw : raw as Record<string, unknown>);
        const ext = format === 'env' ? 'env' : format === 'yaml' ? 'yaml' : format === 'toml' ? 'toml' : 'json';
        const dest = String(call.args.path ?? `.ocean/injected/apps/${app}/config.${ext}`);
        if (!isPathAllowed(dest, [...config.writePaths, '.ocean/injected'])) {
          return { tool: call.tool, success: false, output: '', error: `Path not allowed: ${dest}` };
        }
        await api.fs.writeFile(resolvePath(workspacePath, dest), body);
        if (call.args.injectToContext !== false) {
          registerInjection({
            type: 'app_config',
            path: dest,
            label: `${app} config`,
            scope: 'session',
            charCount: body.length,
          });
          if (call.args.addToSkills) {
            useSkillsStore.getState().addAgentSkill(`${app} Config`, `---\nname: ${app}-config\n---\n\n\`\`\`${ext}\n${body}\n\`\`\``);
          }
        }
        return { tool: call.tool, success: true, output: `App config for ${app} (${format}) → ${dest}` };
      }

      default:
        return { tool: call.tool, success: false, output: '', error: `Unknown tool: ${call.tool}` };
    }
  } catch (err) {
    return {
      tool: call.tool,
      success: false,
      output: '',
      error: err instanceof Error ? err.message : 'Tool execution failed',
    };
  }
}

export function formatToolResults(results: VibeToolResult[]): string {
  return results.map((r) => {
    const status = r.success ? 'OK' : 'ERROR';
    const body = r.error ? r.error : r.output;
    return `[${r.tool}] ${status}:\n${body}`;
  }).join('\n\n');
}
