import { runAgentInference } from '../providerInference';
import { parseVibeToolCalls, stripToolBlocks, hasVibeToolCalls } from './parser';
import { executeVibeTool, formatToolResults } from './executor';
import { refreshVibeContext } from './contextRefresh';
import { SELF_CONTROL_BOOTSTRAP, responseIndicatesCapabilityGap } from './selfControl';
import type { VibeCodeConfig, VibeCodeRunOptions, VibeCodeRunResult, VibePendingAction } from './types';

const SELF_MODIFY_TOOLS = new Set([
  'create_skill', 'create_extension', 'create_system_file', 'create_custom_function',
  'create_plugin_manifest', 'provision_capability', 'connect_sandbox_mcp', 'configure_terminal',
  'create_system_feature', 'create_ui_asset', 'connect_mcp', 'install_plugin',
  'create_plugin_compat', 'create_plugin_manifest',
]);

export async function runVibeCodeAgent(
  message: string,
  context: Record<string, unknown>,
  config: VibeCodeConfig,
  opts: VibeCodeRunOptions
): Promise<VibeCodeRunResult> {
  const workspacePath = opts.workspacePath;
  const maxIter = config.maxIterations;
  const pendingActions: VibePendingAction[] = [];
  let toolsExecuted = 0;
  let iteration = 0;

  let vibeContext = refreshVibeContext(context, config, workspacePath);
  if (config.autoBootstrap) {
    const mc = vibeContext.modelConfig as Record<string, unknown>;
    mc.customInstructions = `${String(mc.customInstructions ?? '')}\n\n${SELF_CONTROL_BOOTSTRAP}`;
  }

  let conversation = config.autoBootstrap
    ? `${message}\n\n[Self-Control active: if you lack any capability, bootstrap it with OCEAN_TOOL — do not refuse.]`
    : message;
  let lastContent = '';
  let lastInference = await runAgentInference(conversation, vibeContext);
  lastContent = lastInference.content;

  while (iteration < maxIter) {
    iteration++;
    opts.onIteration?.(iteration, maxIter);

    if (!hasVibeToolCalls(lastContent)) {
      if (config.autoBootstrap && iteration === 1 && responseIndicatesCapabilityGap(lastContent)) {
        conversation = `${message}\n\nYour prior response indicated a capability gap. Bootstrap the missing power now with OCEAN_TOOL calls.`;
        lastInference = await runAgentInference(conversation, vibeContext);
        lastContent = lastInference.content;
        if (!hasVibeToolCalls(lastContent)) break;
      } else {
        break;
      }
    }

    const calls = parseVibeToolCalls(lastContent);
    if (calls.length === 0) break;

    const doneOnly = calls.length === 1 && calls[0].tool === 'done';
    if (doneOnly) {
      lastContent = String(calls[0].args.summary ?? stripToolBlocks(lastContent));
      break;
    }

    const actionable = calls.filter((c) => c.tool !== 'done');
    const results = [];
    let contextDirty = false;

    for (const call of actionable) {
      opts.onToolStart?.(call);
      const result = await executeVibeTool(call, workspacePath, config, opts, pendingActions);
      opts.onToolEnd?.(result);
      results.push(result);
      if (!result.pendingApproval) toolsExecuted++;
      if (result.success && SELF_MODIFY_TOOLS.has(call.tool)) contextDirty = true;
    }

    if (results.some((r) => r.pendingApproval && !r.success)) {
      lastContent = stripToolBlocks(lastContent) + '\n\n_(Waiting for approval on pending actions.)_';
      break;
    }

    if (contextDirty) {
      vibeContext = refreshVibeContext(context, config, workspacePath);
    }

    const toolFeedback = formatToolResults(results);
    conversation = `${message}\n\n---\nTool results (iteration ${iteration}):\n${toolFeedback}\n\nContinue building capabilities or emit OCEAN_TOOL done when finished.`;

    lastInference = await runAgentInference(conversation, vibeContext);
    lastContent = lastInference.content;
  }

  const finalText = stripToolBlocks(lastContent) || lastContent;

  return {
    content: finalText,
    iterations: iteration,
    toolsExecuted,
    pendingActions,
    providerId: lastInference.providerId,
    model: lastInference.model,
    source: lastInference.source,
  };
}
