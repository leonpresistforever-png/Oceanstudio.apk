import type { VibeToolCall, VibeToolName } from './types';
import { VIBE_TOOL_NAME_SET } from './toolNames';

function normalizeTool(name: string): VibeToolName | null {
  const key = name.trim().toLowerCase().replace(/-/g, '_');
  return VIBE_TOOL_NAME_SET.has(key) ? (key as VibeToolName) : null;
}

function parseJsonObject(raw: string): Record<string, unknown> | null {
  try {
    const obj = JSON.parse(raw) as unknown;
    return obj && typeof obj === 'object' && !Array.isArray(obj)
      ? obj as Record<string, unknown>
      : null;
  } catch {
    return null;
  }
}

function extractBalancedJson(text: string, startIdx: number): string | null {
  if (text[startIdx] !== '{') return null;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = startIdx; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escape) escape = false;
      else if (ch === '\\') escape = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return text.slice(startIdx, i + 1);
    }
  }
  return null;
}

function extractBalancedArray(text: string, startIdx: number): string | null {
  if (text[startIdx] !== '[') return null;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = startIdx; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escape) escape = false;
      else if (ch === '\\') escape = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === '[') depth++;
    else if (ch === ']') {
      depth--;
      if (depth === 0) return text.slice(startIdx, i + 1);
    }
  }
  return null;
}

function callFromObject(obj: Record<string, unknown>): VibeToolCall | null {
  const tool = normalizeTool(String(obj.tool ?? obj.name ?? ''));
  if (!tool) return null;
  const args = (obj.args ?? obj.arguments ?? obj.params ?? {}) as Record<string, unknown>;
  return { id: crypto.randomUUID(), tool, args };
}

function extractOceanToolJsonBlocks(content: string): string[] {
  const blocks: string[] = [];
  const marker = /OCEAN_TOOL:\s*/gi;
  let match;
  while ((match = marker.exec(content)) !== null) {
    const start = match.index + match[0].length;
    const json = extractBalancedJson(content, start);
    if (json) blocks.push(json);
  }
  return blocks;
}

function extractOceanToolsArray(content: string): string | null {
  const marker = /OCEAN_TOOLS:\s*/i;
  const match = marker.exec(content);
  if (!match) return null;
  const start = match.index + match[0].length;
  return extractBalancedArray(content, start);
}

/** Extract OCEAN_TOOL / fenced JSON tool calls from model output */
export function parseVibeToolCalls(content: string): VibeToolCall[] {
  const calls: VibeToolCall[] = [];
  const seen = new Set<string>();

  function addCall(call: VibeToolCall | null) {
    if (!call) return;
    const key = `${call.tool}:${JSON.stringify(call.args)}`;
    if (seen.has(key)) return;
    seen.add(key);
    calls.push(call);
  }

  for (const json of extractOceanToolJsonBlocks(content)) {
    addCall(callFromObject(parseJsonObject(json) ?? {}));
  }

  const arrayRaw = extractOceanToolsArray(content);
  if (arrayRaw) {
    try {
      const arr = JSON.parse(arrayRaw) as unknown[];
      for (const item of arr) {
        if (!item || typeof item !== 'object') continue;
        addCall(callFromObject(item as Record<string, unknown>));
      }
    } catch { /* ignore */ }
  }

  const fencePatterns = [
    /```(?:ocean_tool|tool)\s*([\s\S]*?)```/gi,
    /```json\s*([\s\S]*?)```/gi,
  ];
  for (const pattern of fencePatterns) {
    let match;
    while ((match = pattern.exec(content)) !== null) {
      const trimmed = match[1].trim();
      const objStart = trimmed.indexOf('{');
      const json = objStart >= 0 ? extractBalancedJson(trimmed, objStart) : null;
      if (json) addCall(callFromObject(parseJsonObject(json) ?? {}));
    }
  }

  return calls.filter((c) => c.tool !== null);
}

export function hasVibeToolCalls(content: string): boolean {
  return parseVibeToolCalls(content).length > 0
    || /\bOCEAN_TOOL:/i.test(content)
    || /\bOCEAN_TOOLS:/i.test(content);
}

export function stripToolBlocks(content: string): string {
  let out = content;
  out = out.replace(/OCEAN_TOOL:\s*\{[\s\S]*?\}/gi, '');
  // Balanced strip for OCEAN_TOOL
  const marker = /OCEAN_TOOL:\s*/gi;
  let m;
  while ((m = marker.exec(content)) !== null) {
    const start = m.index;
    const jsonStart = m.index + m[0].length;
    const json = extractBalancedJson(content, jsonStart);
    if (json) out = out.replace(content.slice(start, jsonStart + json.length), '');
  }
  const arr = extractOceanToolsArray(content);
  if (arr) out = out.replace(/OCEAN_TOOLS:\s*[\s\S]*/i, '');
  return out
    .replace(/```(?:ocean_tool|tool)\s*[\s\S]*?```/gi, '')
    .trim();
}
