export type VibeCodeMode = 'review' | 'auto' | 'bypass';
export type VibeCodeApplyMode = 'review' | 'auto' | 'bypass';

export type VibeToolName =
  | 'read_file'
  | 'write_file'
  | 'list_dir'
  | 'run_terminal'
  | 'create_skill'
  | 'create_extension'
  | 'create_requirements'
  | 'create_system_file'
  | 'create_custom_function'
  | 'create_plugin_manifest'
  | 'install_dependency'
  | 'configure_terminal'
  | 'connect_sandbox_mcp'
  | 'create_ui_asset'
  | 'provision_capability'
  | 'create_system_feature'
  | 'web_search'
  | 'fetch_url'
  | 'discover_mcp'
  | 'connect_mcp'
  | 'install_plugin'
  | 'create_plugin_compat'
  | 'install_app'
  | 'fetch_store'
  | 'inspect_system'
  | 'download_file'
  | 'inject_context_file'
  | 'inject_fastflag'
  | 'inject_app_config'
  | 'done';

export interface VibeToolCall {
  id: string;
  tool: VibeToolName;
  args: Record<string, unknown>;
}

export interface VibeToolResult {
  tool: VibeToolName;
  success: boolean;
  output: string;
  error?: string;
  pendingApproval?: boolean;
  approvalId?: string;
}

export interface VibePendingAction {
  id: string;
  tool: VibeToolName;
  args: Record<string, unknown>;
  summary: string;
  createdAt: number;
}

export interface VibeCodeConfig {
  enabled: boolean;
  /** When true, agents auto-bootstrap missing capabilities even if Vibe toggle is off */
  autoBootstrap: boolean;
  applyMode: VibeCodeApplyMode;
  maxIterations: number;
  languages: string[];
  allowSelfModify: boolean;
  allowPluginCreate: boolean;
  allowSkillCreate: boolean;
  allowMcpProvision: boolean;
  allowInternet: boolean;
  allowAppInstall: boolean;
  allowMcpAutoConnect: boolean;
  writePaths: string[];
  systemPaths: string[];
  terminalId: string;
  terminalType: 'shell' | 'cloud' | 'native';
}

export const DEFAULT_VIBE_CODE_CONFIG: VibeCodeConfig = {
  enabled: false,
  autoBootstrap: true,
  applyMode: 'review',
  maxIterations: 16,
  languages: ['typescript', 'javascript', 'python', 'rust', 'go', 'bash', 'shell'],
  allowSelfModify: true,
  allowPluginCreate: true,
  allowSkillCreate: true,
  allowMcpProvision: true,
  allowInternet: true,
  allowAppInstall: true,
  allowMcpAutoConnect: true,
  writePaths: ['.', 'src', 'agent', '.ocean', 'plugins', 'scripts', 'public', 'assets', 'downloads'],
  systemPaths: ['agent', '.ocean/agent', 'agent/generated'],
  terminalId: 'ocean-vibe-code-terminal',
  terminalType: 'shell',
};

export interface VibeCodeRunOptions {
  workspacePath: string;
  agentMode?: 'review' | 'auto' | 'bypass';
  terminalType?: 'shell' | 'cloud' | 'native';
  onToolStart?: (call: VibeToolCall) => void;
  onToolEnd?: (result: VibeToolResult) => void;
  onPendingAction?: (action: VibePendingAction) => void;
  onIteration?: (iteration: number, max: number) => void;
  approveAction?: (id: string) => Promise<boolean>;
}

export interface VibeCodeRunResult {
  content: string;
  iterations: number;
  toolsExecuted: number;
  pendingActions: VibePendingAction[];
  providerId: string;
  model?: string;
  source: 'provider' | 'fallback' | 'local';
}
