import type { VibePendingAction } from './types';

/** Prompt user to approve a vibe code action in review mode */
export async function requestVibeApproval(action: VibePendingAction): Promise<boolean> {
  if (typeof window === 'undefined') return true;
  const detail = JSON.stringify(action.args, null, 2).slice(0, 600);
  return window.confirm(`Approve vibe code action?\n\n${action.summary}\n\n${detail}`);
}

export function createVibeApproveAction(
  onPending?: (action: VibePendingAction) => void
): (id: string) => Promise<boolean> {
  const pending = new Map<string, VibePendingAction>();
  return async (id: string) => {
    const action = pending.get(id);
    if (!action) return false;
    const approved = await requestVibeApproval(action);
    pending.delete(id);
    return approved;
  };
}

/** Approve by action object directly (executor inline) */
export async function approveVibeAction(action: VibePendingAction): Promise<boolean> {
  return requestVibeApproval(action);
}
