import type { VibeToolName } from './types';

export const ALL_VIBE_TOOL_NAMES: VibeToolName[] = [
  'read_file', 'write_file', 'list_dir', 'run_terminal',
  'create_skill', 'create_extension', 'create_requirements',
  'create_system_file', 'create_custom_function', 'create_plugin_manifest',
  'install_dependency', 'configure_terminal', 'connect_sandbox_mcp',
  'create_ui_asset', 'provision_capability', 'create_system_feature',
  'web_search', 'fetch_url', 'discover_mcp', 'connect_mcp',
  'install_plugin', 'create_plugin_compat', 'install_app',
  'fetch_store', 'inspect_system', 'download_file',
  'inject_context_file', 'inject_fastflag', 'inject_app_config',
  'done',
];

export const VIBE_TOOL_NAME_SET = new Set<string>(ALL_VIBE_TOOL_NAMES);
