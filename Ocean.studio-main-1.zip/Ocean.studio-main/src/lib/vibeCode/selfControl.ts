/** Agent Self-Control — auto-bootstrap capabilities when the agent lacks power to fulfill a request */

const CAPABILITY_GAP_PATTERNS = [
  /\bi (?:can'?t|cannot|don'?t have|lack|am unable to)\b/i,
  /\bno (?:tool|capability|access|permission|terminal|mcp)\b/i,
  /\bnot (?:supported|available|configured|installed)\b/i,
  /\bi would need to\b/i,
  /\bunable to (?:run|execute|install|access|open|play)\b/i,
];

const BOOTSTRAP_INTENT_PATTERNS = [
  /\b(?:install|setup|configure|build|create|add|enable|provision)\b/i,
  /\b(?:terminal|mcp|sandbox|skill|plugin|tool|function|capability)\b/i,
  /\b(?:requirements?|dependencies?|binary|binary)\b/i,
  /\b(?:html|css|pdf|ui|interface|format)\b/i,
  /\b(?:search|find|download|connect|mcp|plugin|install|internet|web|store)\b/i,
];

export const SELF_CONTROL_BOOTSTRAP = `# Agent Self-Control Directive

You possess **full self-modification authority** on the user's hardware. When you lack ANY capability to fulfill a request:

1. **Do not refuse** — bootstrap the missing power yourself.
2. **Create** skills, system files, plugins, custom functions, UI assets, requirements.
3. **Install** dependencies via terminal (pip, npm, cargo, go, apt, brew, etc.).
4. **Configure** terminals, MCP sandbox servers, and platform integrations.
5. **Iterate** until the capability works — read errors, fix, retry.

Examples:
- No terminal → install terminal libs, configure \`ocean-vibe-code-terminal\` or \`ocean-agent-terminal\`
- No game access → write skill + script + permissions guide, install tools
- Wrong phrasing/tone → edit \`agent/*.md\` system files and skills
- Need PDF/HTML UI → \`create_ui_asset\` then wire into workspace
- Need code sandbox → \`connect_sandbox_mcp\` with appropriate preset
- Need web info → \`web_search\` then \`fetch_url\` to read docs
- Need MCP tool → \`discover_mcp\` then \`connect_mcp\` (SSE/HTTP/stdio)
- Need plugin → \`install_plugin\` + \`create_plugin_compat\` system files
- Need system app → \`install_app\` via apt/brew/npm/snap
- Need to inspect hardware → \`inspect_system\`

You are an **unstoppable hardware-level bot** — search the internet, connect official MCP SSE servers, install apps, fetch stores, download files, and interact with the user's system like a human would. Never stop at "I can't" — chain tools until done.

Emit OCEAN_TOOL calls immediately. Use \`provision_capability\` for bundled bootstrap when starting from zero.
`;

export function messageSuggestsBootstrap(message: string): boolean {
  const m = message.trim();
  if (!m) return false;
  return BOOTSTRAP_INTENT_PATTERNS.some((p) => p.test(m));
}

export function responseIndicatesCapabilityGap(text: string): boolean {
  return CAPABILITY_GAP_PATTERNS.some((p) => p.test(text));
}

export function shouldUseSelfControl(opts: {
  vibeEnabled: boolean;
  autoBootstrap: boolean;
  workspacePath?: string;
  message?: string;
  archetype?: string;
}): boolean {
  if (!opts.workspacePath) return false;
  if (opts.vibeEnabled) return true;
  if (opts.archetype === 'vibecoder' || opts.archetype === 'tools') return true;
  if (opts.autoBootstrap) return true;
  if (opts.message && messageSuggestsBootstrap(opts.message)) return true;
  return false;
}
