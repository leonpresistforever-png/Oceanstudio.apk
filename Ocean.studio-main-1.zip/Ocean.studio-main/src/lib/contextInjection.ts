/**
 * Agent context injection — files, fastflags, and in-app config overlays.
 * Used by OCEAN_TOOL inject_* tools and serialized into system prompts.
 */

export type ContextInjectScope = 'session' | 'agent' | 'workspace' | 'playground';

export interface InjectedContextEntry {
  id: string;
  type: 'file' | 'fastflag' | 'app_config';
  path: string;
  label: string;
  scope: ContextInjectScope;
  createdAt: number;
  charCount: number;
}

export interface FastFlagSet {
  app: string;
  flags: Record<string, boolean | string | number>;
  updatedAt: string;
}

const SESSION_ENTRIES: InjectedContextEntry[] = [];
const FASTFLAGS: Record<string, FastFlagSet> = {};

export function listInjectedContext(): InjectedContextEntry[] {
  return [...SESSION_ENTRIES];
}

export function getFastFlags(app?: string): FastFlagSet[] {
  if (app) {
    const set = FASTFLAGS[app];
    return set ? [set] : [];
  }
  return Object.values(FASTFLAGS);
}

export function serializeInjectedContext(maxChars = 24_000): string {
  const parts: string[] = ['## Injected Context (session)'];
  let used = parts[0].length;

  for (const entry of SESSION_ENTRIES) {
    const line = `- [${entry.type}] ${entry.label} → \`${entry.path}\` (${entry.scope}, ${entry.charCount} chars)`;
    if (used + line.length > maxChars) break;
    parts.push(line);
    used += line.length;
  }

  const flags = Object.values(FASTFLAGS);
  if (flags.length) {
    parts.push('\n## FastFlags / App Config');
    for (const f of flags) {
      const block = `### ${f.app}\n\`\`\`json\n${JSON.stringify(f.flags, null, 2)}\n\`\`\``;
      if (used + block.length > maxChars) break;
      parts.push(block);
      used += block.length;
    }
  }

  return parts.join('\n');
}

function slugify(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'item';
}

export function defaultInjectPath(type: 'file' | 'fastflag' | 'app_config', label: string, app?: string): string {
  const slug = slugify(label || app || 'context');
  if (type === 'fastflag') return `.ocean/injected/fastflags/${slugify(app ?? 'app')}.json`;
  if (type === 'app_config') return `.ocean/injected/apps/${slugify(app ?? 'app')}/config.json`;
  return `.ocean/injected/files/${slug}`;
}

export function mergeFastFlags(app: string, flags: Record<string, boolean | string | number>): FastFlagSet {
  const existing = FASTFLAGS[app]?.flags ?? {};
  const merged: FastFlagSet = {
    app,
    flags: { ...existing, ...flags },
    updatedAt: new Date().toISOString(),
  };
  FASTFLAGS[app] = merged;
  return merged;
}

export function setFastFlags(app: string, flags: Record<string, boolean | string | number>): FastFlagSet {
  const set: FastFlagSet = { app, flags: { ...flags }, updatedAt: new Date().toISOString() };
  FASTFLAGS[app] = set;
  return set;
}

export function registerInjection(entry: Omit<InjectedContextEntry, 'id' | 'createdAt'>): InjectedContextEntry {
  const full: InjectedContextEntry = {
    ...entry,
    id: crypto.randomUUID(),
    createdAt: Date.now(),
  };
  SESSION_ENTRIES.unshift(full);
  if (SESSION_ENTRIES.length > 100) SESSION_ENTRIES.pop();
  return full;
}

export function formatAppConfig(
  format: 'json' | 'yaml' | 'env' | 'toml',
  content: string | Record<string, unknown>,
): string {
  if (typeof content === 'string') return content;
  if (format === 'json') return JSON.stringify(content, null, 2);
  if (format === 'env') {
    return Object.entries(content)
      .map(([k, v]) => `${k}=${JSON.stringify(v)}`)
      .join('\n');
  }
  if (format === 'yaml') {
    return Object.entries(content)
      .map(([k, v]) => `${k}: ${typeof v === 'string' ? v : JSON.stringify(v)}`)
      .join('\n');
  }
  if (format === 'toml') {
    return Object.entries(content)
      .map(([k, v]) => {
        if (typeof v === 'boolean') return `${k} = ${v}`;
        if (typeof v === 'number') return `${k} = ${v}`;
        return `${k} = "${v}"`;
      })
      .join('\n');
  }
  return JSON.stringify(content, null, 2);
}
