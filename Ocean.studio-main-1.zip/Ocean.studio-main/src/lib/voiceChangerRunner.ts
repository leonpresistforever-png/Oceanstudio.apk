/**
 * Voice changer — Web Audio pitch/formant FX + optional agent task for cloud morph.
 */
import type { VoiceChangerConfig } from '../playground/voiceChangerTypes';

let audioContext: AudioContext | null = null;
let mediaStream: MediaStream | null = null;
let sourceNode: MediaStreamAudioSourceNode | AudioBufferSourceNode | null = null;
let gainNode: GainNode | null = null;

function getCtx(): AudioContext {
  if (!audioContext) audioContext = new AudioContext();
  return audioContext;
}

function semitoneToRate(semitones: number): number {
  return Math.pow(2, semitones / 12);
}

export function stopVoiceChanger(): void {
  sourceNode?.disconnect();
  gainNode?.disconnect();
  mediaStream?.getTracks().forEach((t) => t.stop());
  sourceNode = null;
  gainNode = null;
  mediaStream = null;
}

export async function startMicVoiceChanger(
  config: VoiceChangerConfig,
  onError?: (msg: string) => void,
): Promise<void> {
  stopVoiceChanger();
  try {
    const ctx = getCtx();
    mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    sourceNode = ctx.createMediaStreamSource(mediaStream);
    gainNode = ctx.createGain();
    gainNode.gain.value = config.outputVolume;

    const chain = buildFxChain(ctx, sourceNode, gainNode, config);
    chain.connect(ctx.destination);
    if (ctx.state === 'suspended') await ctx.resume();
  } catch (err) {
    onError?.(err instanceof Error ? err.message : 'Microphone access failed');
    throw err;
  }
}

function buildFxChain(
  ctx: AudioContext,
  input: AudioNode,
  output: GainNode,
  config: VoiceChangerConfig,
): AudioNode {
  let node: AudioNode = input;

  if (config.formant !== 1) {
    const filter = ctx.createBiquadFilter();
    filter.type = 'peaking';
    filter.frequency.value = 800 * config.formant;
    filter.Q.value = 1.2;
    filter.gain.value = (config.formant - 1) * 12;
    node.connect(filter);
    node = filter;
  }

  if (config.distortion > 0) {
    const shaper = ctx.createWaveShaper();
    shaper.curve = makeDistortionCurve(config.distortion * 400);
    node.connect(shaper);
    node = shaper;
  }

  if (config.reverb > 0) {
    const convolver = ctx.createConvolver();
    convolver.buffer = makeReverbImpulse(ctx, config.reverb);
    const dry = ctx.createGain();
    const wet = ctx.createGain();
    dry.gain.value = 1 - config.reverb * 0.5;
    wet.gain.value = config.reverb;
    node.connect(dry);
    node.connect(convolver);
    convolver.connect(wet);
    dry.connect(output);
    wet.connect(output);
    return output;
  }

  const final = ctx.createGain();
  final.gain.value = 1;
  node.connect(final);
  final.connect(output);
  return output;
}

function makeDistortionCurve(amount: number): Float32Array<ArrayBuffer> {
  const n = 44100;
  const curve = new Float32Array(n);
  const deg = Math.PI / 180;
  for (let i = 0; i < n; i++) {
    const x = (i * 2) / n - 1;
    curve[i] = ((3 + amount) * x * 20 * deg) / (Math.PI + amount * Math.abs(x));
  }
  return curve;
}

function makeReverbImpulse(ctx: AudioContext, amount: number): AudioBuffer {
  const len = ctx.sampleRate * (0.5 + amount);
  const impulse = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let c = 0; c < 2; c++) {
    const ch = impulse.getChannelData(c);
    for (let i = 0; i < len; i++) {
      ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2) * amount;
    }
  }
  return impulse;
}

export async function processAudioFile(
  file: File,
  config: VoiceChangerConfig,
): Promise<{ blob: Blob; duration: number }> {
  const ctx = getCtx();
  const arrayBuf = await file.arrayBuffer();
  const audioBuf = await ctx.decodeAudioData(arrayBuf.slice(0));

  const offline = new OfflineAudioContext(
    audioBuf.numberOfChannels,
    Math.ceil(audioBuf.length / config.speed),
    audioBuf.sampleRate,
  );

  const src = offline.createBufferSource();
  src.buffer = audioBuf;
  src.playbackRate.value = semitoneToRate(config.pitch) * config.speed;
  const gain = offline.createGain();
  gain.gain.value = config.outputVolume;
  src.connect(gain);
  gain.connect(offline.destination);
  src.start();

  const rendered = await offline.startRendering();
  const wav = audioBufferToWav(rendered);
  return { blob: new Blob([wav], { type: 'audio/wav' }), duration: rendered.duration };
}

function audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
  const numCh = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1;
  const bitDepth = 16;
  const samples = buffer.length;
  const blockAlign = (numCh * bitDepth) / 8;
  const byteRate = sampleRate * blockAlign;
  const dataSize = samples * blockAlign;
  const buf = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buf);

  const writeStr = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numCh, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeStr(36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < samples; i++) {
    for (let ch = 0; ch < numCh; ch++) {
      const s = Math.max(-1, Math.min(1, buffer.getChannelData(ch)[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }
  }
  return buf;
}

export function buildVoiceTransformPrompt(config: VoiceChangerConfig, instruction: string): string {
  return [
    'Transform voice audio with these settings:',
    `preset=${config.preset}, pitch=${config.pitch} semitones, formant=${config.formant},`,
    `speed=${config.speed}, reverb=${config.reverb}, distortion=${config.distortion}.`,
    instruction,
  ].join(' ');
}
