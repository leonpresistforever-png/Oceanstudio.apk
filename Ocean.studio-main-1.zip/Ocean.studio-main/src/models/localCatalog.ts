/** 100+ local model definitions — Ollama, LM Studio, llama.cpp compatible. Free forever on your hardware. */

export type LocalModelPurpose =
  | 'coder'
  | 'chat'
  | 'reasoning'
  | 'vision'
  | 'embedding'
  | 'fast'
  | 'multilingual'
  | 'creative'
  | 'math'
  | 'agent';

export type LocalModelRuntime = 'ollama' | 'lmstudio' | 'llamacpp' | 'gguf' | 'any';

export interface LocalModelDefinition {
  id: string;
  name: string;
  tag: string;
  purpose: LocalModelPurpose;
  runtime: LocalModelRuntime[];
  sizeGb?: number;
  contextWindow?: number;
  quantization?: string;
  description: string;
  optimized?: boolean;
  pullCommand: string;
  recommendedParams?: { temperature?: number; topP?: number; numCtx?: number };
}

function ollama(tag: string, overrides: Omit<LocalModelDefinition, 'tag' | 'pullCommand' | 'runtime'> & { pull?: string }): LocalModelDefinition {
  const { pull, ...rest } = overrides;
  return {
    ...rest,
    tag,
    runtime: ['ollama', 'any'],
    pullCommand: pull ?? `ollama pull ${tag}`,
  };
}

/** Curated + generated catalog — 100+ models */
export const LOCAL_MODEL_CATALOG: LocalModelDefinition[] = [
  // ── Coders (20) ─────────────────────────────────────────────────────
  ollama('deepseek-coder-v2:16b', { id: 'local.deepseek-coder-v2-16b', name: 'DeepSeek Coder V2 16B', purpose: 'coder', sizeGb: 9, contextWindow: 128000, description: 'Strong code generation and completion', optimized: true, recommendedParams: { temperature: 0.2, numCtx: 32768 } }),
  ollama('deepseek-coder:6.7b', { id: 'local.deepseek-coder-6.7b', name: 'DeepSeek Coder 6.7B', purpose: 'coder', sizeGb: 4, contextWindow: 16384, description: 'Fast coding assistant', optimized: true }),
  ollama('qwen2.5-coder:32b', { id: 'local.qwen25-coder-32b', name: 'Qwen 2.5 Coder 32B', purpose: 'coder', sizeGb: 19, contextWindow: 131072, description: 'Top-tier open coder', optimized: true }),
  ollama('qwen2.5-coder:14b', { id: 'local.qwen25-coder-14b', name: 'Qwen 2.5 Coder 14B', purpose: 'coder', sizeGb: 9, contextWindow: 131072, description: 'Balanced code model', optimized: true }),
  ollama('qwen2.5-coder:7b', { id: 'local.qwen25-coder-7b', name: 'Qwen 2.5 Coder 7B', purpose: 'coder', sizeGb: 4.7, contextWindow: 131072, description: 'Lightweight coder', optimized: true }),
  ollama('codellama:13b', { id: 'local.codellama-13b', name: 'Code Llama 13B', purpose: 'coder', sizeGb: 7.4, contextWindow: 16384, description: 'Meta code foundation model' }),
  ollama('codellama:34b', { id: 'local.codellama-34b', name: 'Code Llama 34B', purpose: 'coder', sizeGb: 19, contextWindow: 16384, description: 'Large Code Llama' }),
  ollama('starcoder2:15b', { id: 'local.starcoder2-15b', name: 'StarCoder2 15B', purpose: 'coder', sizeGb: 9, contextWindow: 16384, description: 'BigCode StarCoder2' }),
  ollama('starcoder2:7b', { id: 'local.starcoder2-7b', name: 'StarCoder2 7B', purpose: 'coder', sizeGb: 4, contextWindow: 16384, description: 'Efficient StarCoder2' }),
  ollama('wizardcoder:33b', { id: 'local.wizardcoder-33b', name: 'WizardCoder 33B', purpose: 'coder', sizeGb: 19, contextWindow: 8192, description: 'Instruction-tuned coder' }),
  ollama('phind-codellama:34b', { id: 'local.phind-codellama-34b', name: 'Phind CodeLlama 34B', purpose: 'coder', sizeGb: 19, contextWindow: 16384, description: 'Phind-tuned CodeLlama' }),
  ollama('codegemma:7b', { id: 'local.codegemma-7b', name: 'CodeGemma 7B', purpose: 'coder', sizeGb: 5, contextWindow: 8192, description: 'Google CodeGemma' }),
  ollama('granite-code:8b', { id: 'local.granite-code-8b', name: 'Granite Code 8B', purpose: 'coder', sizeGb: 4.6, contextWindow: 128000, description: 'IBM Granite code model', optimized: true }),
  ollama('granite-code:20b', { id: 'local.granite-code-20b', name: 'Granite Code 20B', purpose: 'coder', sizeGb: 11, contextWindow: 128000, description: 'IBM Granite large', optimized: true }),
  ollama('stable-code:3b', { id: 'local.stable-code-3b', name: 'Stable Code 3B', purpose: 'coder', sizeGb: 1.6, contextWindow: 16384, description: 'Tiny code model' }),
  ollama('yi-coder:9b', { id: 'local.yi-coder-9b', name: 'Yi Coder 9B', purpose: 'coder', sizeGb: 5.5, contextWindow: 128000, description: '01.AI Yi Coder' }),
  ollama('dolphincoder:15b', { id: 'local.dolphincoder-15b', name: 'DolphinCoder 15B', purpose: 'coder', sizeGb: 9, contextWindow: 16384, description: 'Uncensored coder variant' }),
  ollama('magicoder:7b', { id: 'local.magicoder-7b', name: 'Magicoder 7B', purpose: 'coder', sizeGb: 4, contextWindow: 16384, description: 'OSS-Instruct coder' }),
  ollama('sqlcoder:15b', { id: 'local.sqlcoder-15b', name: 'SQLCoder 15B', purpose: 'coder', sizeGb: 9, contextWindow: 8192, description: 'SQL-specialized model' }),
  ollama('deepseek-coder-v2-lite', { id: 'local.deepseek-coder-v2-lite', name: 'DeepSeek Coder V2 Lite', purpose: 'coder', sizeGb: 2.5, contextWindow: 128000, description: 'MoE lite coder — fast', optimized: true }),

  // ── Reasoning (12) ──────────────────────────────────────────────────
  ollama('deepseek-r1:32b', { id: 'local.deepseek-r1-32b', name: 'DeepSeek R1 32B', purpose: 'reasoning', sizeGb: 19, contextWindow: 128000, description: 'Chain-of-thought reasoning', optimized: true }),
  ollama('deepseek-r1:14b', { id: 'local.deepseek-r1-14b', name: 'DeepSeek R1 14B', purpose: 'reasoning', sizeGb: 9, contextWindow: 128000, description: 'Mid-size reasoner', optimized: true }),
  ollama('deepseek-r1:7b', { id: 'local.deepseek-r1-7b', name: 'DeepSeek R1 7B', purpose: 'reasoning', sizeGb: 4.7, contextWindow: 128000, description: 'Compact reasoner', optimized: true }),
  ollama('deepseek-r1:1.5b', { id: 'local.deepseek-r1-1.5b', name: 'DeepSeek R1 1.5B', purpose: 'reasoning', sizeGb: 1.1, contextWindow: 128000, description: 'Tiny reasoning model', optimized: true }),
  ollama('qwq:32b', { id: 'local.qwq-32b', name: 'QwQ 32B', purpose: 'reasoning', sizeGb: 19, contextWindow: 131072, description: 'Qwen reasoning model' }),
  ollama('marco-o1:7b', { id: 'local.marco-o1-7b', name: 'Marco-o1 7B', purpose: 'reasoning', sizeGb: 4.7, contextWindow: 32768, description: 'Open o1-style model' }),
  ollama('phi4-reasoning:14b', { id: 'local.phi4-reasoning-14b', name: 'Phi-4 Reasoning 14B', purpose: 'reasoning', sizeGb: 8, contextWindow: 16384, description: 'Microsoft Phi-4 reasoning' }),
  ollama('exaone-deep:7.8b', { id: 'local.exaone-deep-7.8b', name: 'EXAONE Deep 7.8B', purpose: 'reasoning', sizeGb: 5, contextWindow: 32768, description: 'LG EXAONE deep thinking' }),
  ollama('openthinker:7b', { id: 'local.openthinker-7b', name: 'OpenThinker 7B', purpose: 'reasoning', sizeGb: 4.7, contextWindow: 32768, description: 'Open thinking model' }),
  ollama('solar-pro:22b', { id: 'local.solar-pro-22b', name: 'Solar Pro 22B', purpose: 'reasoning', sizeGb: 13, contextWindow: 32768, description: 'Upstage Solar Pro' }),
  ollama('nemotron-mini:4b', { id: 'local.nemotron-mini-4b', name: 'Nemotron Mini 4B', purpose: 'reasoning', sizeGb: 2.5, contextWindow: 4096, description: 'NVIDIA Nemotron mini' }),
  ollama('reflection:70b', { id: 'local.reflection-70b', name: 'Reflection 70B', purpose: 'reasoning', sizeGb: 40, contextWindow: 131072, description: 'Self-correction reasoning' }),

  // ── Chat / general (25) ─────────────────────────────────────────────
  ollama('llama3.3:70b', { id: 'local.llama33-70b', name: 'Llama 3.3 70B', purpose: 'chat', sizeGb: 40, contextWindow: 131072, description: 'Meta flagship chat', optimized: true }),
  ollama('llama3.3:70b-instruct-q4_K_M', { id: 'local.llama33-70b-q4', name: 'Llama 3.3 70B Q4', purpose: 'chat', sizeGb: 43, quantization: 'Q4_K_M', contextWindow: 131072, description: 'Quantized Llama 3.3', optimized: true }),
  ollama('llama3.2:3b', { id: 'local.llama32-3b', name: 'Llama 3.2 3B', purpose: 'fast', sizeGb: 2, contextWindow: 131072, description: 'Tiny Llama 3.2', optimized: true }),
  ollama('llama3.2:1b', { id: 'local.llama32-1b', name: 'Llama 3.2 1B', purpose: 'fast', sizeGb: 1.3, contextWindow: 131072, description: 'Ultra-light Llama', optimized: true }),
  ollama('llama3.1:8b', { id: 'local.llama31-8b', name: 'Llama 3.1 8B', purpose: 'chat', sizeGb: 4.7, contextWindow: 131072, description: 'Popular 8B chat', optimized: true }),
  ollama('llama3.1:70b', { id: 'local.llama31-70b', name: 'Llama 3.1 70B', purpose: 'chat', sizeGb: 40, contextWindow: 131072, description: 'Llama 3.1 large' }),
  ollama('mistral:7b', { id: 'local.mistral-7b', name: 'Mistral 7B', purpose: 'chat', sizeGb: 4.1, contextWindow: 32768, description: 'Mistral AI 7B', optimized: true }),
  ollama('mistral-nemo:12b', { id: 'local.mistral-nemo-12b', name: 'Mistral Nemo 12B', purpose: 'chat', sizeGb: 7, contextWindow: 128000, description: 'Mistral Nemo 128k', optimized: true }),
  ollama('mixtral:8x7b', { id: 'local.mixtral-8x7b', name: 'Mixtral 8x7B', purpose: 'chat', sizeGb: 26, contextWindow: 32768, description: 'MoE mixture of experts' }),
  ollama('mixtral:8x22b', { id: 'local.mixtral-8x22b', name: 'Mixtral 8x22B', purpose: 'chat', sizeGb: 80, contextWindow: 65536, description: 'Large MoE' }),
  ollama('gemma2:9b', { id: 'local.gemma2-9b', name: 'Gemma 2 9B', purpose: 'chat', sizeGb: 5.4, contextWindow: 8192, description: 'Google Gemma 2', optimized: true }),
  ollama('gemma2:27b', { id: 'local.gemma2-27b', name: 'Gemma 2 27B', purpose: 'chat', sizeGb: 16, contextWindow: 8192, description: 'Gemma 2 large' }),
  ollama('gemma3:12b', { id: 'local.gemma3-12b', name: 'Gemma 3 12B', purpose: 'chat', sizeGb: 7.5, contextWindow: 131072, description: 'Gemma 3 multimodal', optimized: true }),
  ollama('phi4:14b', { id: 'local.phi4-14b', name: 'Phi-4 14B', purpose: 'chat', sizeGb: 8, contextWindow: 16384, description: 'Microsoft Phi-4' }),
  ollama('phi3:mini', { id: 'local.phi3-mini', name: 'Phi-3 Mini', purpose: 'fast', sizeGb: 2.3, contextWindow: 128000, description: 'Tiny but capable', optimized: true }),
  ollama('qwen2.5:72b', { id: 'local.qwen25-72b', name: 'Qwen 2.5 72B', purpose: 'chat', sizeGb: 41, contextWindow: 131072, description: 'Alibaba flagship', optimized: true }),
  ollama('qwen2.5:32b', { id: 'local.qwen25-32b', name: 'Qwen 2.5 32B', purpose: 'chat', sizeGb: 19, contextWindow: 131072, description: 'Qwen 2.5 mid', optimized: true }),
  ollama('qwen2.5:14b', { id: 'local.qwen25-14b', name: 'Qwen 2.5 14B', purpose: 'chat', sizeGb: 9, contextWindow: 131072, description: 'Qwen 2.5 balanced', optimized: true }),
  ollama('qwen2.5:7b', { id: 'local.qwen25-7b', name: 'Qwen 2.5 7B', purpose: 'chat', sizeGb: 4.7, contextWindow: 131072, description: 'Qwen 2.5 efficient', optimized: true }),
  ollama('qwen2.5:3b', { id: 'local.qwen25-3b', name: 'Qwen 2.5 3B', purpose: 'fast', sizeGb: 2, contextWindow: 131072, description: 'Qwen 2.5 tiny', optimized: true }),
  ollama('command-r:35b', { id: 'local.command-r-35b', name: 'Command R 35B', purpose: 'chat', sizeGb: 20, contextWindow: 128000, description: 'Cohere Command R' }),
  ollama('command-r-plus:104b', { id: 'local.command-r-plus', name: 'Command R+ 104B', purpose: 'chat', sizeGb: 60, contextWindow: 128000, description: 'Cohere Command R+' }),
  ollama('aya:35b', { id: 'local.aya-35b', name: 'Aya 35B', purpose: 'multilingual', sizeGb: 20, contextWindow: 8192, description: '23 languages' }),
  ollama('openchat:7b', { id: 'local.openchat-7b', name: 'OpenChat 7B', purpose: 'chat', sizeGb: 4.1, contextWindow: 8192, description: 'Strong chat tuning' }),
  ollama('neural-chat:7b', { id: 'local.neural-chat-7b', name: 'Neural Chat 7B', purpose: 'chat', sizeGb: 4.1, contextWindow: 8192, description: 'Intel Neural Chat' }),

  // ── Vision (10) ─────────────────────────────────────────────────────
  ollama('llava:13b', { id: 'local.llava-13b', name: 'LLaVA 13B', purpose: 'vision', sizeGb: 8, contextWindow: 4096, description: 'Vision-language model' }),
  ollama('llava:34b', { id: 'local.llava-34b', name: 'LLaVA 34B', purpose: 'vision', sizeGb: 20, contextWindow: 4096, description: 'Large LLaVA' }),
  ollama('llava-llama3:8b', { id: 'local.llava-llama3-8b', name: 'LLaVA Llama3 8B', purpose: 'vision', sizeGb: 5, contextWindow: 8192, description: 'LLaVA on Llama 3' }),
  ollama('bakllava:7b', { id: 'local.bakllava-7b', name: 'BakLLaVA 7B', purpose: 'vision', sizeGb: 4.7, contextWindow: 4096, description: 'Mistral vision' }),
  ollama('moondream:1.8b', { id: 'local.moondream-1.8b', name: 'Moondream 1.8B', purpose: 'vision', sizeGb: 1.7, contextWindow: 2048, description: 'Tiny vision model', optimized: true }),
  ollama('minicpm-v:8b', { id: 'local.minicpm-v-8b', name: 'MiniCPM-V 8B', purpose: 'vision', sizeGb: 5, contextWindow: 8192, description: 'Efficient vision', optimized: true }),
  ollama('llama3.2-vision:11b', { id: 'local.llama32-vision-11b', name: 'Llama 3.2 Vision 11B', purpose: 'vision', sizeGb: 7.8, contextWindow: 131072, description: 'Meta vision model', optimized: true }),
  ollama('llama3.2-vision:90b', { id: 'local.llama32-vision-90b', name: 'Llama 3.2 Vision 90B', purpose: 'vision', sizeGb: 55, contextWindow: 131072, description: 'Large vision' }),
  ollama('granite3.2-vision:2b', { id: 'local.granite-vision-2b', name: 'Granite 3.2 Vision 2B', purpose: 'vision', sizeGb: 1.5, contextWindow: 128000, description: 'IBM tiny vision', optimized: true }),
  ollama('qwen2-vl:7b', { id: 'local.qwen2-vl-7b', name: 'Qwen2-VL 7B', purpose: 'vision', sizeGb: 5, contextWindow: 32768, description: 'Qwen vision-language' }),

  // ── Embeddings (8) ─────────────────────────────────────────────────
  ollama('nomic-embed-text', { id: 'local.nomic-embed', name: 'Nomic Embed Text', purpose: 'embedding', sizeGb: 0.3, contextWindow: 8192, description: 'General embeddings', optimized: true }),
  ollama('mxbai-embed-large', { id: 'local.mxbai-embed', name: 'MXBAI Embed Large', purpose: 'embedding', sizeGb: 0.7, contextWindow: 512, description: 'High-quality embeddings' }),
  ollama('snowflake-arctic-embed:335m', { id: 'local.snowflake-embed', name: 'Snowflake Arctic Embed', purpose: 'embedding', sizeGb: 0.4, contextWindow: 512, description: 'Retrieval embeddings' }),
  ollama('bge-large', { id: 'local.bge-large', name: 'BGE Large', purpose: 'embedding', sizeGb: 0.7, contextWindow: 512, description: 'BAAI embeddings' }),
  ollama('all-minilm', { id: 'local.all-minilm', name: 'All-MiniLM', purpose: 'embedding', sizeGb: 0.05, contextWindow: 256, description: 'Tiny embeddings', optimized: true }),
  ollama('paraphrase-multilingual', { id: 'local.paraphrase-multilingual', name: 'Paraphrase Multilingual', purpose: 'embedding', sizeGb: 0.5, contextWindow: 512, description: '50+ language embeddings' }),
  ollama('granite-embedding:278m', { id: 'local.granite-embed', name: 'Granite Embedding', purpose: 'embedding', sizeGb: 0.3, contextWindow: 512, description: 'IBM embeddings' }),
  ollama('qwen3-embedding:4b', { id: 'local.qwen3-embed', name: 'Qwen3 Embedding 4B', purpose: 'embedding', sizeGb: 2.5, contextWindow: 8192, description: 'Qwen embeddings' }),

  // ── Agent / tool-use (8) ───────────────────────────────────────────
  ollama('llama3.1:8b-instruct-q4_0', { id: 'local.llama31-agent-8b', name: 'Llama 3.1 8B Agent', purpose: 'agent', sizeGb: 4.7, contextWindow: 131072, description: 'Tool-use tuned', optimized: true }),
  ollama('mistral-small:24b', { id: 'local.mistral-small-24b', name: 'Mistral Small 24B', purpose: 'agent', sizeGb: 14, contextWindow: 32768, description: 'Agentic workflows' }),
  ollama('firefunction-v2:70b', { id: 'local.firefunction-v2', name: 'FireFunction V2 70B', purpose: 'agent', sizeGb: 40, contextWindow: 8192, description: 'Function calling specialist' }),
  ollama('hermes3:8b', { id: 'local.hermes3-8b', name: 'Hermes 3 8B', purpose: 'agent', sizeGb: 4.7, contextWindow: 131072, description: 'Nous agent model', optimized: true }),
  ollama('hermes3:70b', { id: 'local.hermes3-70b', name: 'Hermes 3 70B', purpose: 'agent', sizeGb: 40, contextWindow: 131072, description: 'Large agent model' }),
  ollama('athene-v2:72b', { id: 'local.athene-v2', name: 'Athene V2 72B', purpose: 'agent', sizeGb: 41, contextWindow: 32768, description: 'Agent + chat hybrid' }),
  ollama('nemotron:70b', { id: 'local.nemotron-70b', name: 'Nemotron 70B', purpose: 'agent', sizeGb: 40, contextWindow: 32768, description: 'NVIDIA agent model' }),
  ollama('granite3-dense:8b', { id: 'local.granite3-agent-8b', name: 'Granite 3 Dense 8B', purpose: 'agent', sizeGb: 4.9, contextWindow: 128000, description: 'IBM agent model', optimized: true }),

  // ── Creative / roleplay (6) ─────────────────────────────────────────
  ollama('dolphin-mixtral:8x7b', { id: 'local.dolphin-mixtral', name: 'Dolphin Mixtral 8x7B', purpose: 'creative', sizeGb: 26, contextWindow: 32768, description: 'Creative uncensored MoE' }),
  ollama('dolphin-llama3:8b', { id: 'local.dolphin-llama3-8b', name: 'Dolphin Llama3 8B', purpose: 'creative', sizeGb: 4.7, contextWindow: 8192, description: 'Creative chat' }),
  ollama('nous-hermes2:10.7b', { id: 'local.nous-hermes2', name: 'Nous Hermes 2 10.7B', purpose: 'creative', sizeGb: 6.5, contextWindow: 4096, description: 'Roleplay model' }),
  ollama('solar:10.7b', { id: 'local.solar-10.7b', name: 'Solar 10.7B', purpose: 'creative', sizeGb: 6.5, contextWindow: 4096, description: 'Upstage Solar' }),
  ollama('wizard-vicuna-uncensored:13b', { id: 'local.wizard-vicuna-13b', name: 'Wizard Vicuna 13B', purpose: 'creative', sizeGb: 7.4, contextWindow: 2048, description: 'Uncensored creative' }),
  ollama('openhermes:7b', { id: 'local.openhermes-7b', name: 'OpenHermes 7B', purpose: 'creative', sizeGb: 4.1, contextWindow: 8192, description: 'Teknium OpenHermes' }),

  // ── Math (5) ────────────────────────────────────────────────────────
  ollama('mathstral:7b', { id: 'local.mathstral-7b', name: 'Mathstral 7B', purpose: 'math', sizeGb: 4.1, contextWindow: 32768, description: 'Mistral math specialist' }),
  ollama('deepseek-math:7b', { id: 'local.deepseek-math-7b', name: 'DeepSeek Math 7B', purpose: 'math', sizeGb: 4, contextWindow: 4096, description: 'Math reasoning' }),
  ollama('wizard-math:7b', { id: 'local.wizard-math-7b', name: 'WizardMath 7B', purpose: 'math', sizeGb: 4.1, contextWindow: 4096, description: 'Math instruction tuned' }),
  ollama('abel:7b', { id: 'local.abel-7b', name: 'Abel 7B', purpose: 'math', sizeGb: 4.1, contextWindow: 4096, description: 'Math problem solving' }),
  ollama('qwen2-math:7b', { id: 'local.qwen2-math-7b', name: 'Qwen2 Math 7B', purpose: 'math', sizeGb: 4.7, contextWindow: 4096, description: 'Qwen math model' }),

  // ── Multilingual (6) ────────────────────────────────────────────────
  ollama('glm4:9b', { id: 'local.glm4-9b', name: 'GLM-4 9B', purpose: 'multilingual', sizeGb: 5.5, contextWindow: 128000, description: 'Chinese + English', optimized: true }),
  ollama('yi:34b', { id: 'local.yi-34b', name: 'Yi 34B', purpose: 'multilingual', sizeGb: 19, contextWindow: 4096, description: '01.AI bilingual' }),
  ollama('internlm2:20b', { id: 'local.internlm2-20b', name: 'InternLM2 20B', purpose: 'multilingual', sizeGb: 11, contextWindow: 32768, description: 'Shanghai AI Lab' }),
  ollama('falcon:40b', { id: 'local.falcon-40b', name: 'Falcon 40B', purpose: 'multilingual', sizeGb: 24, contextWindow: 2048, description: 'TII Falcon' }),
  ollama('jais:13b', { id: 'local.jais-13b', name: 'Jais 13B', purpose: 'multilingual', sizeGb: 7.4, contextWindow: 4096, description: 'Arabic + English' }),
  ollama('sailor2:8b', { id: 'local.sailor2-8b', name: 'Sailor2 8B', purpose: 'multilingual', sizeGb: 4.7, contextWindow: 32768, description: 'SEA languages' }),
];

export const LOCAL_MODEL_COUNT = LOCAL_MODEL_CATALOG.length;

export const LOCAL_MODEL_PURPOSES: { id: LocalModelPurpose; label: string; icon: string }[] = [
  { id: 'coder', label: 'Code', icon: '💻' },
  { id: 'chat', label: 'Chat', icon: '💬' },
  { id: 'reasoning', label: 'Reasoning', icon: '🧠' },
  { id: 'vision', label: 'Vision', icon: '👁️' },
  { id: 'embedding', label: 'Embedding', icon: '📊' },
  { id: 'fast', label: 'Fast / Tiny', icon: '⚡' },
  { id: 'agent', label: 'Agent / Tools', icon: '🤖' },
  { id: 'creative', label: 'Creative', icon: '🎨' },
  { id: 'math', label: 'Math', icon: '🔢' },
  { id: 'multilingual', label: 'Multilingual', icon: '🌍' },
];

export function getLocalModel(id: string): LocalModelDefinition | undefined {
  return LOCAL_MODEL_CATALOG.find((m) => m.id === id);
}

export function getLocalModelsByPurpose(purpose: LocalModelPurpose): LocalModelDefinition[] {
  return LOCAL_MODEL_CATALOG.filter((m) => m.purpose === purpose);
}
