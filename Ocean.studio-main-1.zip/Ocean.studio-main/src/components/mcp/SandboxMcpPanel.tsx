import { useCallback, useEffect, useState } from 'react';
import {
  Box, Container, Cpu, HardDrive, Play, Plus, Settings2,
  Trash2, Plug, AlertTriangle, ExternalLink, RefreshCw,
} from 'lucide-react';
import { getOceanAPI } from '../../lib/platform';
import {
  SANDBOX_COMPATIBILITY_LAYERS,
  SANDBOX_MCP_PRESETS,
  getSandboxPreset,
} from '../../mcp/sandboxCatalog';
import {
  buildSandboxConnectPayload,
  connectorIdForSandbox,
  formatArgsString,
  instanceFromPreset,
  parseArgsString,
  runtimeNeedsDocker,
} from '../../mcp/sandboxRuntime';
import type { SandboxMcpInstance, SandboxMcpPreset } from '../../mcp/sandboxTypes';
import { upsertConnection, removeConnection, getConnections } from '../../mcp/registry';
import type { McpConnection } from '../../mcp/types';
import { useSandboxMcpStore } from '../../store/sandboxMcpStore';
import type { AgentLogEntry } from '../../store/appStore';
import './SandboxMcpPanel.css';

interface SandboxMcpPanelProps {
  platform: 'electron' | 'web' | 'mobile';
  onConnectionsChange: () => void;
  addAgentLog: (entry: AgentLogEntry) => void;
}

export default function SandboxMcpPanel({ platform, onConnectionsChange, addAgentLog }: SandboxMcpPanelProps) {
  const instances = useSandboxMcpStore((s) => s.instances);
  const addInstance = useSandboxMcpStore((s) => s.addInstance);
  const updateInstance = useSandboxMcpStore((s) => s.updateInstance);
  const removeInstance = useSandboxMcpStore((s) => s.removeInstance);

  const [dockerStatus, setDockerStatus] = useState<{ ok: boolean; message: string; version?: string } | null>(null);
  const [checkingDocker, setCheckingDocker] = useState(false);
  const [editing, setEditing] = useState<SandboxMcpInstance | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [connectingId, setConnectingId] = useState<string | null>(null);

  const refreshDocker = useCallback(async () => {
    if (platform !== 'electron') {
      setDockerStatus({ ok: false, message: 'Sandbox MCP stdio requires the Electron desktop app' });
      return;
    }
    const api = getOceanAPI() as { mcp?: { checkDocker?: () => Promise<{ ok: boolean; message: string; version?: string }> } };
    if (!api.mcp?.checkDocker) {
      setDockerStatus({ ok: false, message: 'Docker check unavailable' });
      return;
    }
    setCheckingDocker(true);
    try {
      setDockerStatus(await api.mcp.checkDocker());
    } finally {
      setCheckingDocker(false);
    }
  }, [platform]);

  useEffect(() => { void refreshDocker(); }, [refreshDocker]);

  async function connectInstance(instance: SandboxMcpInstance) {
    if (platform !== 'electron') {
      addAgentLog({ id: crypto.randomUUID(), type: 'error', timestamp: Date.now(), summary: 'Sandbox MCP requires Electron desktop', status: 'failed' });
      return;
    }

    const preset = instance.presetId ? getSandboxPreset(instance.presetId) : undefined;
    if (runtimeNeedsDocker(instance.runtime) && dockerStatus && !dockerStatus.ok) {
      addAgentLog({ id: crypto.randomUUID(), type: 'error', timestamp: Date.now(), summary: dockerStatus.message, status: 'failed' });
      return;
    }

    const payload = buildSandboxConnectPayload(instance, preset);
    const api = getOceanAPI() as {
      mcp?: { connect: (cfg: unknown) => Promise<McpConnection> };
    };

    const connId = connectorIdForSandbox(instance.id);
    const conn: McpConnection = {
      connectorId: connId,
      name: instance.name,
      transport: 'stdio',
      hosting: 'local',
      runtime: instance.runtime,
      config: {
        command: payload.command ?? '',
        args: JSON.stringify(payload.args ?? []),
        runtime: instance.runtime,
        docker: payload.docker ? JSON.stringify(payload.docker) : '',
        ...payload.env,
      },
      status: 'connecting',
      sandbox: true,
    };
    upsertConnection(conn);
    onConnectionsChange();
    setConnectingId(instance.id);

    try {
      const result = await api.mcp?.connect?.(payload);
      updateInstance(instance.id, { connectorId: connId });
      upsertConnection({
        ...conn,
        status: result?.status ?? 'connected',
        error: result?.error,
        connectedAt: Date.now(),
      });
      addAgentLog({ id: crypto.randomUUID(), type: 'result', timestamp: Date.now(), summary: `Sandbox MCP connected: ${instance.name}`, status: 'completed' });
    } catch (e) {
      upsertConnection({ ...conn, status: 'error', error: e instanceof Error ? e.message : 'Connect failed' });
      addAgentLog({ id: crypto.randomUUID(), type: 'error', timestamp: Date.now(), summary: e instanceof Error ? e.message : 'Sandbox connect failed', status: 'failed' });
    } finally {
      setConnectingId(null);
      onConnectionsChange();
    }
  }

  async function disconnectInstance(instance: SandboxMcpInstance) {
    const connId = instance.connectorId ?? connectorIdForSandbox(instance.id);
    const api = getOceanAPI() as { mcp?: { disconnect: (id: string) => Promise<void> } };
    await api.mcp?.disconnect?.(connId);
    removeConnection(connId);
    updateInstance(instance.id, { connectorId: undefined });
    onConnectionsChange();
  }

  function startFromPreset(preset: SandboxMcpPreset) {
    const inst = instanceFromPreset(preset);
    addInstance(inst);
    setEditing(inst);
    setShowAdvanced(false);
  }

  function saveEdit() {
    if (!editing) return;
    const exists = instances.some((i) => i.id === editing.id);
    if (exists) updateInstance(editing.id, editing);
    else addInstance(editing);
    setEditing(null);
  }

  const connectedIds = new Set(
    getConnections().filter((c) => c.status === 'connected' && c.sandbox).map((c) => c.connectorId)
  );

  if (platform !== 'electron') {
    return (
      <div className="sandbox-mcp-panel">
        <p className="sandbox-mcp-section-desc">
          Sandbox MCP runs stdio servers on your hardware via Docker and local binaries. Use the Electron desktop app for full control.
        </p>
      </div>
    );
  }

  return (
    <div className="sandbox-mcp-panel">
      <div className="sandbox-mcp-status-bar">
        <span className={`sandbox-mcp-status-dot ${dockerStatus?.ok ? 'ok' : dockerStatus ? 'err' : 'warn'}`} />
        <Container size={16} />
        <span>{dockerStatus?.ok ? `Docker ${dockerStatus.version ?? 'ready'}` : dockerStatus?.message ?? 'Checking Docker…'}</span>
        <button className="plugins-back" onClick={() => void refreshDocker()} disabled={checkingDocker}>
          <RefreshCw size={12} className={checkingDocker ? 'spin' : ''} /> Refresh
        </button>
      </div>

      <p className="sandbox-mcp-section-desc">
        Run sandbox MCP servers directly on your machine — Docker containers, npx, uvx, or custom stdio. Full control over images, mounts, CPU/memory, and init commands.
      </p>

      <div className="sandbox-mcp-compat">
        {SANDBOX_COMPATIBILITY_LAYERS.map((l) => (
          <span key={l.id} className="sandbox-mcp-compat-pill" title={l.description}>{l.label}</span>
        ))}
      </div>

      <h2 className="sandbox-mcp-section-title">Curated presets</h2>
      <div className="plugins-grid">
        {SANDBOX_MCP_PRESETS.map((preset) => (
          <div key={preset.id} className="sandbox-mcp-card">
            <div className="sandbox-mcp-card-header">
              <div>
                <h3>{preset.name}</h3>
                <div className="sandbox-mcp-card-tags">
                  <span className={`sandbox-mcp-runtime-badge ${preset.runtime.includes('docker') ? 'docker' : ''}`}>{preset.runtime}</span>
                  {preset.archived && <span className="sandbox-mcp-tag archived">Archived</span>}
                  {preset.tags?.slice(0, 3).map((t) => <span key={t} className="sandbox-mcp-tag">{t}</span>)}
                </div>
              </div>
              {preset.docsUrl && (
                <a href={preset.docsUrl} target="_blank" rel="noreferrer" className="plugin-link"><ExternalLink size={14} /></a>
              )}
            </div>
            <p className="sandbox-mcp-card-desc">{preset.description}</p>
            {preset.recommendedAlternative && (
              <p className="sandbox-mcp-reqs"><AlertTriangle size={12} style={{ display: 'inline', marginRight: 4 }} />
                Try: {getSandboxPreset(preset.recommendedAlternative)?.name ?? preset.recommendedAlternative}
              </p>
            )}
            {preset.requirements && (
              <p className="sandbox-mcp-reqs">Requires: {preset.requirements.join(' · ')}</p>
            )}
            <div className="sandbox-mcp-actions">
              <button className="plugin-install-btn" onClick={() => startFromPreset(preset)}>
                <Plus size={14} /> Configure
              </button>
              <button
                className="plugin-install-btn"
                onClick={() => {
                  const inst = instanceFromPreset(preset);
                  addInstance(inst);
                  void connectInstance(inst);
                }}
                disabled={connectingId !== null || (runtimeNeedsDocker(preset.runtime) && !dockerStatus?.ok)}
              >
                <Plug size={14} /> Quick connect
              </button>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <div className="sandbox-mcp-form">
          <h3 className="sandbox-mcp-section-title" style={{ margin: 0 }}>Configure: {editing.name}</h3>
          <label className="sandbox-mcp-field">
            <span>Name</span>
            <input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
          </label>
          <label className="sandbox-mcp-field">
            <span>Runtime</span>
            <select
              value={editing.runtime}
              onChange={(e) => setEditing({ ...editing, runtime: e.target.value as SandboxMcpInstance['runtime'] })}
            >
              <option value="host">Host stdio</option>
              <option value="docker">Docker container</option>
              <option value="docker-socket">Docker + socket (nested containers)</option>
            </select>
          </label>

          {editing.runtime === 'host' ? (
            <>
              <label className="sandbox-mcp-field">
                <span>Command</span>
                <input value={editing.command ?? ''} onChange={(e) => setEditing({ ...editing, command: e.target.value })} placeholder="npx, uvx, sandbox-mcp, python…" />
              </label>
              <label className="sandbox-mcp-field">
                <span>Args (space-separated or JSON array)</span>
                <input
                  value={formatArgsString(editing.args)}
                  onChange={(e) => setEditing({ ...editing, args: parseArgsString(e.target.value) })}
                />
              </label>
            </>
          ) : (
            <div className="sandbox-mcp-row">
              <label className="sandbox-mcp-field">
                <span>Docker image</span>
                <input
                  value={editing.docker?.image ?? ''}
                  onChange={(e) => setEditing({ ...editing, docker: { ...editing.docker!, image: e.target.value } })}
                />
              </label>
              <label className="sandbox-mcp-field">
                <span>Container command args</span>
                <input
                  value={formatArgsString(editing.docker?.cmd ?? editing.args)}
                  onChange={(e) => setEditing({
                    ...editing,
                    docker: { ...editing.docker!, cmd: parseArgsString(e.target.value) },
                  })}
                />
              </label>
            </div>
          )}

          <label className="sandbox-mcp-field">
            <span>Workspace mount (host path)</span>
            <input
              value={editing.workspaceMount ?? ''}
              onChange={(e) => setEditing({ ...editing, workspaceMount: e.target.value })}
              placeholder="~/sandbox-workspace"
            />
          </label>

          <label className="sandbox-mcp-checkbox">
            <input
              type="checkbox"
              checked={editing.initOnConnect}
              onChange={(e) => setEditing({ ...editing, initOnConnect: e.target.checked })}
            />
            Run init commands on connect (pull/build images)
          </label>

          <button type="button" className="sandbox-mcp-advanced-toggle" onClick={() => setShowAdvanced((v) => !v)}>
            <Settings2 size={14} style={{ display: 'inline', marginRight: 4 }} />
            {showAdvanced ? 'Hide' : 'Show'} advanced Docker &amp; resource limits
          </button>

          {showAdvanced && (
            <div className="sandbox-mcp-advanced">
              <div className="sandbox-mcp-row">
                <label className="sandbox-mcp-field">
                  <span><Cpu size={12} /> Memory limit</span>
                  <input
                    value={editing.docker?.memory ?? editing.env.SANDBOX_MEMORY_LIMIT ?? ''}
                    onChange={(e) => setEditing({
                      ...editing,
                      env: { ...editing.env, SANDBOX_MEMORY_LIMIT: e.target.value },
                      docker: editing.docker ? { ...editing.docker, memory: e.target.value } : undefined,
                    })}
                    placeholder="512m"
                  />
                </label>
                <label className="sandbox-mcp-field">
                  <span><Container size={12} /> CPU limit</span>
                  <input
                    value={editing.docker?.cpus ?? editing.env.SANDBOX_CPU_LIMIT ?? ''}
                    onChange={(e) => setEditing({
                      ...editing,
                      env: { ...editing.env, SANDBOX_CPU_LIMIT: e.target.value },
                      docker: editing.docker ? { ...editing.docker, cpus: e.target.value } : undefined,
                    })}
                    placeholder="1.0"
                  />
                </label>
              </div>
              <label className="sandbox-mcp-field">
                <span>Network mode</span>
                <select
                  value={editing.docker?.network ?? 'bridge'}
                  onChange={(e) => setEditing({
                    ...editing,
                    docker: { ...editing.docker!, network: e.target.value as NonNullable<typeof editing.docker>['network'] },
                  })}
                >
                  <option value="bridge">bridge</option>
                  <option value="host">host</option>
                  <option value="none">none (isolated)</option>
                  <option value="isolated">isolated</option>
                </select>
              </label>
              <label className="sandbox-mcp-field">
                <span>Extra docker run args (space-separated)</span>
                <input
                  value={(editing.docker?.extraRunArgs ?? []).join(' ')}
                  onChange={(e) => setEditing({
                    ...editing,
                    docker: { ...editing.docker!, extraRunArgs: parseArgsString(e.target.value) },
                  })}
                  placeholder="--cap-drop ALL --security-opt no-new-privileges"
                />
              </label>
              <label className="sandbox-mcp-field">
                <span>Environment variables (KEY=value per line)</span>
                <textarea
                  value={Object.entries(editing.env).map(([k, v]) => `${k}=${v}`).join('\n')}
                  onChange={(e) => {
                    const env: Record<string, string> = {};
                    for (const line of e.target.value.split('\n')) {
                      const idx = line.indexOf('=');
                      if (idx > 0) env[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
                    }
                    setEditing({ ...editing, env });
                  }}
                />
              </label>
            </div>
          )}

          <div className="sandbox-mcp-actions">
            <button className="plugin-install-btn" onClick={saveEdit}><HardDrive size={14} /> Save</button>
            <button
              className="plugin-install-btn"
              onClick={() => { saveEdit(); void connectInstance(editing); }}
              disabled={connectingId === editing.id}
            >
              <Play size={14} /> Save &amp; Connect
            </button>
            <button className="plugins-back" onClick={() => setEditing(null)}>Cancel</button>
          </div>
        </div>
      )}

      {instances.length > 0 && (
        <>
          <h2 className="sandbox-mcp-section-title">Your sandbox servers</h2>
          <div className="sandbox-mcp-instances">
            {instances.map((inst) => {
              const connId = connectorIdForSandbox(inst.id);
              const connected = connectedIds.has(connId) || connectedIds.has(inst.connectorId ?? '');
              return (
                <div key={inst.id} className="sandbox-mcp-instance-row">
                  <div className="sandbox-mcp-instance-info">
                    <strong>{inst.name}</strong>
                    <span>{inst.runtime} · {inst.presetId ?? 'custom'}{connected ? ' · connected' : ''}</span>
                  </div>
                  <div className="sandbox-mcp-actions">
                    <button className="plugins-back" onClick={() => setEditing(inst)}>Edit</button>
                    {connected ? (
                      <button className="plugin-install-btn installed" onClick={() => void disconnectInstance(inst)}>
                        <Trash2 size={14} /> Disconnect
                      </button>
                    ) : (
                      <button className="plugin-install-btn" onClick={() => void connectInstance(inst)} disabled={connectingId === inst.id}>
                        <Plug size={14} /> Connect
                      </button>
                    )}
                    <button className="plugins-back" onClick={() => { removeInstance(inst.id); if (connected) void disconnectInstance(inst); }}>
                      Remove
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
