import { useRef, useState } from 'react';
import { Mic, MicOff, Upload, Play, Square, Loader2 } from 'lucide-react';
import { useVoiceChangerStore } from '../../store/voiceChangerStore';
import {
  VOICE_CHANGER_PRESET_LABELS,
  type VoiceChangerPreset,
} from '../../playground/voiceChangerTypes';
import {
  startMicVoiceChanger,
  stopVoiceChanger,
  processAudioFile,
} from '../../lib/voiceChangerRunner';
import './VoiceChangerPanel.css';

interface VoiceChangerPanelProps {
  onAgentTask?: (prompt: string) => void;
}

export default function VoiceChangerPanel({ onAgentTask }: VoiceChangerPanelProps) {
  const config = useVoiceChangerStore((s) => s.config);
  const status = useVoiceChangerStore((s) => s.status);
  const lastOutput = useVoiceChangerStore((s) => s.lastOutput);
  const inputFileName = useVoiceChangerStore((s) => s.inputFileName);
  const setConfig = useVoiceChangerStore((s) => s.setConfig);
  const applyPreset = useVoiceChangerStore((s) => s.applyPreset);
  const setStatus = useVoiceChangerStore((s) => s.setStatus);
  const setLastOutput = useVoiceChangerStore((s) => s.setLastOutput);
  const setInputFileName = useVoiceChangerStore((s) => s.setInputFileName);

  const fileRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [micOn, setMicOn] = useState(false);

  async function toggleMic() {
    if (micOn) {
      stopVoiceChanger();
      setMicOn(false);
      setStatus('idle');
      return;
    }
    setStatus('listening');
    try {
      await startMicVoiceChanger(config, (msg) => setLastOutput(msg));
      setMicOn(true);
      setLastOutput(`Live monitor: ${config.preset} preset, pitch ${config.pitch}`);
    } catch (err) {
      setStatus('error');
      setLastOutput(err instanceof Error ? err.message : 'Mic failed');
    }
  }

  async function handleFile(file: File) {
    setInputFileName(file.name);
    setStatus('processing');
    try {
      const { blob } = await processAudioFile(file, config);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      setLastOutput(`Processed ${file.name} → WAV (${config.preset})`);
      setStatus('playing');
    } catch (err) {
      setStatus('error');
      setLastOutput(err instanceof Error ? err.message : 'Processing failed');
    }
  }

  function runCloudMorph() {
    const prompt = [
      `Voice changer — preset: ${config.preset}, pitch: ${config.pitch} semitones,`,
      `formant: ${config.formant}, speed: ${config.speed}, reverb: ${config.reverb}.`,
      inputFileName ? `Input file: ${inputFileName}.` : 'Use ElevenLabs or vocoder plugin for cloud voice morph.',
      'Apply voice transformation and return audio URL or instructions.',
    ].join(' ');
    onAgentTask?.(prompt);
  }

  return (
    <section className="voice-changer-panel">
      <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', margin: 0 }}>
        Real-time mic FX via Web Audio, file pitch-shift export, or cloud morph via ElevenLabs / vocoder plugins.
      </p>

      <div className="voice-changer-presets">
        {(Object.keys(VOICE_CHANGER_PRESET_LABELS) as VoiceChangerPreset[]).map((p) => (
          <button
            key={p}
            type="button"
            className={config.preset === p ? 'active' : ''}
            onClick={() => applyPreset(p)}
          >
            {VOICE_CHANGER_PRESET_LABELS[p]}
          </button>
        ))}
      </div>

      <div className="voice-changer-sliders">
        <label>
          Pitch (semitones): {config.pitch}
          <input
            type="range"
            min={-12}
            max={12}
            value={config.pitch}
            onChange={(e) => setConfig({ pitch: Number(e.target.value), preset: 'custom' })}
          />
        </label>
        <label>
          Formant: {config.formant.toFixed(2)}
          <input
            type="range"
            min={50}
            max={200}
            value={config.formant * 100}
            onChange={(e) => setConfig({ formant: Number(e.target.value) / 100, preset: 'custom' })}
          />
        </label>
        <label>
          Speed: {config.speed.toFixed(2)}×
          <input
            type="range"
            min={50}
            max={150}
            value={config.speed * 100}
            onChange={(e) => setConfig({ speed: Number(e.target.value) / 100, preset: 'custom' })}
          />
        </label>
        <label>
          Reverb: {Math.round(config.reverb * 100)}%
          <input
            type="range"
            min={0}
            max={100}
            value={config.reverb * 100}
            onChange={(e) => setConfig({ reverb: Number(e.target.value) / 100, preset: 'custom' })}
          />
        </label>
        <label>
          Distortion: {Math.round(config.distortion * 100)}%
          <input
            type="range"
            min={0}
            max={100}
            value={config.distortion * 100}
            onChange={(e) => setConfig({ distortion: Number(e.target.value) / 100, preset: 'custom' })}
          />
        </label>
        <label>
          Volume: {Math.round(config.outputVolume * 100)}%
          <input
            type="range"
            min={0}
            max={100}
            value={config.outputVolume * 100}
            onChange={(e) => setConfig({ outputVolume: Number(e.target.value) / 100 })}
          />
        </label>
      </div>

      <div className="voice-changer-actions">
        <button type="button" onClick={() => void toggleMic()}>
          {micOn ? <MicOff size={16} /> : <Mic size={16} />}
          {micOn ? 'Stop Mic FX' : 'Start Mic FX'}
        </button>
        <button type="button" className="secondary" onClick={() => fileRef.current?.click()}>
          <Upload size={16} />
          Upload Audio
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="audio/*"
          hidden
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void handleFile(f);
          }}
        />
        {previewUrl && (
          <button type="button" className="secondary" onClick={() => new Audio(previewUrl).play()}>
            <Play size={16} />
            Play Output
          </button>
        )}
        <button type="button" className="secondary" onClick={runCloudMorph}>
          Cloud Morph (Agent)
        </button>
        {status === 'processing' && <Loader2 size={16} className="pg-spin" />}
        {micOn && (
          <button type="button" className="secondary" onClick={() => { stopVoiceChanger(); setMicOn(false); setStatus('idle'); }}>
            <Square size={14} />
          </button>
        )}
      </div>

      <div className="voice-changer-status">Status: {status}{inputFileName ? ` · ${inputFileName}` : ''}</div>
      {lastOutput && <div className="voice-changer-output">{lastOutput}</div>}
    </section>
  );
}
