import { useState, useEffect, useRef, useCallback } from 'react';
import Editor, { type OnMount } from '@monaco-editor/react';
import { getOceanAPI } from '../../lib/platform';
import { useAppStore } from '../../store/appStore';
import { useAssistiveAgentStore } from '../../store/assistiveAgentStore';
import { runAssistiveAgent, detectQuickIssues } from '../../lib/assistiveAgentRunner';
import { resolvePreferredTerminal } from '../../lib/terminalRouter';
import './WorkspaceMenu.css';

function getLanguageFromPath(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript',
    py: 'python', json: 'json', md: 'markdown', css: 'css', html: 'html',
    rs: 'rust', go: 'go', java: 'java', cpp: 'cpp', c: 'c', sql: 'sql',
    yaml: 'yaml', yml: 'yaml', sh: 'shell', bash: 'shell',
  };
  return map[ext] || 'plaintext';
}

export default function CodeEditor() {
  const activeFile = useAppStore((s) => s.activeFile);
  const workspacePath = useAppStore((s) => s.workspacePath);
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [hint, setHint] = useState('');
  const loadGen = useRef(0);
  const editorRef = useRef<Parameters<OnMount>[0] | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const assistConfig = useAssistiveAgentStore((s) => s.config);
  const setLastSuggestion = useAssistiveAgentStore((s) => s.setLastSuggestion);
  const setLastFix = useAssistiveAgentStore((s) => s.setLastFix);
  const setRunning = useAssistiveAgentStore((s) => s.setRunning);
  const isRunning = useAssistiveAgentStore((s) => s.isRunning);

  useEffect(() => {
    if (!activeFile) {
      setContent('');
      return;
    }
    const filePath = activeFile;
    const gen = ++loadGen.current;
    async function load() {
      setLoading(true);
      try {
        const api = getOceanAPI();
        const text = await api.fs.readFile(filePath);
        if (gen !== loadGen.current) return;
        setContent(text);
      } catch {
        if (gen !== loadGen.current) return;
        setContent('// Unable to load file');
      } finally {
        if (gen === loadGen.current) setLoading(false);
      }
    }
    void load();
  }, [activeFile]);

  const scheduleAssist = useCallback((value: string) => {
    if (!assistConfig.enabled || !activeFile || !workspacePath) return;
    if (assistConfig.assistLevel < 20) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      const lang = getLanguageFromPath(activeFile);
      const issues = detectQuickIssues(value, lang);
      if (issues.length && assistConfig.inlineHints) {
        setHint(issues.join(' · '));
      }
      if (assistConfig.autoFixOnSave && issues.length && assistConfig.assistLevel >= 50) {
        void runAssist('suggest', value, issues.join('; '));
      }
    }, assistConfig.debounceMs);
  }, [assistConfig, activeFile, workspacePath]);

  async function runAssist(action: 'suggest' | 'fix' | 'complete' | 'explain', code?: string, errorHint?: string) {
    if (!activeFile || !workspacePath || isRunning) return;
    setRunning(true);
    setHint('');
    try {
      const api = getOceanAPI();
      const platform = await api.platform.get();
      const terminalType = platform.preferredTerminal ?? resolvePreferredTerminal(platform);
      const ed = editorRef.current;
      const sel = ed?.getSelection();
      const selection = sel && ed?.getModel() ? ed.getModel()!.getValueInRange(sel) : '';
      const result = await runAssistiveAgent(
        {
          action,
          filePath: activeFile,
          content: code ?? content,
          selection,
          cursorLine: ed?.getPosition()?.lineNumber,
          errorHint,
        },
        assistConfig,
        workspacePath,
        activeFile,
        terminalType,
      );
      if (action === 'fix') {
        setLastFix(result);
        setHint('Fix suggestion ready — review in Assistive panel');
      } else {
        setLastSuggestion(result);
        if (assistConfig.inlineHints) setHint(result.slice(0, 200));
      }
    } catch (e) {
      setHint(e instanceof Error ? e.message : 'Assist failed');
    } finally {
      setRunning(false);
    }
  }

  async function handleSave(value: string | undefined) {
    if (!activeFile || value === undefined) return;
    setContent(value);
    const api = getOceanAPI();
    await api.fs.writeFile(activeFile, value);
    scheduleAssist(value);
  }

  const handleMount: OnMount = (editor, monaco) => {
    editorRef.current = editor;
    editor.addAction({
      id: 'ocean-assist-fix',
      label: 'Assistive: Fix selection',
      keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF],
      run: () => { void runAssist('fix'); },
    });
    editor.addAction({
      id: 'ocean-assist-complete',
      label: 'Assistive: Complete',
      keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.Space],
      run: () => { void runAssist('complete'); },
    });
  };

  if (!activeFile) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        height: '100%', color: 'var(--text-tertiary)', fontSize: '0.875rem',
      }}>
        Select a file from the explorer to start editing
      </div>
    );
  }

  const fileName = activeFile.split('/').pop() || activeFile;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{
        padding: '6px 16px', fontSize: '0.8125rem', color: 'var(--text-secondary)',
        borderBottom: '1px solid var(--border-subtle)', background: 'var(--bg-tertiary)',
      }}>
        {fileName}
      </div>

      <div className="assistive-bar">
        <label className="assistive-bar-toggle">
          <input
            type="checkbox"
            checked={assistConfig.enabled}
            onChange={(e) => useAssistiveAgentStore.getState().setConfig({ enabled: e.target.checked })}
          />
          Assistive
        </label>
        <button type="button" className="assistive-bar-btn" disabled={isRunning} onClick={() => void runAssist('fix')}>
          Fix errors
        </button>
        <button type="button" className="assistive-bar-btn" disabled={isRunning} onClick={() => void runAssist('complete')}>
          Complete
        </button>
        <button type="button" className="assistive-bar-btn" disabled={isRunning} onClick={() => void runAssist('explain')}>
          Explain
        </button>
        <div className="assistive-bar-slider">
          <span>Speed {assistConfig.assistLevel}%</span>
          <input
            type="range"
            min={0}
            max={100}
            value={assistConfig.assistLevel}
            onChange={(e) => useAssistiveAgentStore.getState().setConfig({ assistLevel: Number(e.target.value) })}
          />
        </div>
      </div>

      {hint && assistConfig.inlineHints && (
        <div className="assistive-hint">{hint}</div>
      )}

      <div style={{ flex: 1 }}>
        {loading ? (
          <div style={{ padding: 20, color: 'var(--text-tertiary)' }}>Loading...</div>
        ) : (
          <Editor
            height="100%"
            language={getLanguageFromPath(activeFile)}
            value={content}
            onChange={handleSave}
            onMount={handleMount}
            theme="vs"
            options={{
              fontSize: 13,
              fontFamily: 'JetBrains Mono, monospace',
              minimap: { enabled: true },
              scrollBeyondLastLine: false,
              padding: { top: 12 },
              lineNumbers: 'on',
              renderWhitespace: 'selection',
              automaticLayout: true,
              quickSuggestions: assistConfig.enabled,
              suggestOnTriggerCharacters: assistConfig.enabled,
            }}
          />
        )}
      </div>
    </div>
  );
}
