import { useAssistiveAgentStore } from '../../store/assistiveAgentStore';
import { PROVIDER_CATALOG } from '../../providers/catalog';
import { OFFICIAL_PLUGINS } from '../../plugins/marketplace/official';
import { MCP_CATALOG } from '../../mcp/catalog';
import './WorkspaceMenu.css';

const PROVIDER_OPTIONS = PROVIDER_CATALOG.filter((p) => p.category === 'llm' || p.category === 'gateway').slice(0, 20);
const ASSISTIVE_PLUGINS = OFFICIAL_PLUGINS.filter((p) =>
  (p.tags ?? []).includes('assistive') || p.id === 'ocean.assistive-code' || p.id === 'ocean.eslint-plugin',
);
const ASSISTIVE_MCPS = MCP_CATALOG.filter((m) =>
  m.id.includes('assistive') || m.category === 'Dev' && m.name.toLowerCase().includes('assist'),
).slice(0, 15);

export default function AssistiveAgentPanel() {
  const config = useAssistiveAgentStore((s) => s.config);
  const setConfig = useAssistiveAgentStore((s) => s.setConfig);
  const lastSuggestion = useAssistiveAgentStore((s) => s.lastSuggestion);
  const lastFix = useAssistiveAgentStore((s) => s.lastFix);

  return (
    <div className="assistive-panel">
      <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', margin: 0 }}>
        Assign an agent to speed up manual coding — fix errors, suggest completions, and assist while you type.
      </p>

      <label>
        <span>Enabled</span>
        <input
          type="checkbox"
          checked={config.enabled}
          onChange={(e) => setConfig({ enabled: e.target.checked })}
        />
      </label>

      <label>
        Agent source
        <select
          value={config.source}
          onChange={(e) => setConfig({ source: e.target.value as typeof config.source })}
        >
          <option value="provider">Provider (connected)</option>
          <option value="byok">BYOK / API key</option>
          <option value="mcp">MCP connector</option>
          <option value="plugin">Plugin</option>
          <option value="local">Local model (Ollama)</option>
        </select>
      </label>

      {(config.source === 'provider' || config.source === 'byok') && (
        <label>
          Provider
          <select
            value={config.source === 'byok' ? config.byokProviderId : config.providerId}
            onChange={(e) =>
              setConfig(
                config.source === 'byok'
                  ? { byokProviderId: e.target.value, providerId: e.target.value }
                  : { providerId: e.target.value },
              )
            }
          >
            {PROVIDER_OPTIONS.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </label>
      )}

      {config.source === 'plugin' && (
        <label>
          Plugin
          <select value={config.pluginId} onChange={(e) => setConfig({ pluginId: e.target.value })}>
            <option value="">Select plugin</option>
            {ASSISTIVE_PLUGINS.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
            {OFFICIAL_PLUGINS.filter((p) => !ASSISTIVE_PLUGINS.includes(p)).slice(0, 20).map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </label>
      )}

      {config.source === 'mcp' && (
        <label>
          MCP connector
          <select value={config.mcpConnectorId} onChange={(e) => setConfig({ mcpConnectorId: e.target.value })}>
            <option value="">Select MCP</option>
            {ASSISTIVE_MCPS.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
            {MCP_CATALOG.filter((m) => !ASSISTIVE_MCPS.includes(m)).slice(0, 15).map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </label>
      )}

      {config.source === 'local' && (
        <label>
          Model ID
          <input
            type="text"
            value={config.modelId}
            onChange={(e) => setConfig({ modelId: e.target.value, providerId: 'ollama' })}
            placeholder="llama3.2, qwen2.5-coder, etc."
          />
        </label>
      )}

      <label>
        Model
        <input
          type="text"
          value={config.modelId}
          onChange={(e) => setConfig({ modelId: e.target.value })}
          placeholder="gpt-4o-mini, claude-sonnet-4-6, etc."
        />
      </label>

      <label>
        Assist level: {config.assistLevel}%
        <input
          type="range"
          min={0}
          max={100}
          value={config.assistLevel}
          onChange={(e) => setConfig({ assistLevel: Number(e.target.value) })}
        />
      </label>

      <label>
        <input
          type="checkbox"
          checked={config.autoFixOnSave}
          onChange={(e) => setConfig({ autoFixOnSave: e.target.checked })}
        />
        Auto-check on pause typing
      </label>

      <label>
        <input
          type="checkbox"
          checked={config.inlineHints}
          onChange={(e) => setConfig({ inlineHints: e.target.checked })}
        />
        Show inline hints
      </label>

      {lastSuggestion && (
        <div>
          <div className="workspace-menu-label">Last suggestion</div>
          <div className="assistive-panel-output">{lastSuggestion.slice(0, 1500)}</div>
        </div>
      )}

      {lastFix && (
        <div>
          <div className="workspace-menu-label">Last fix</div>
          <div className="assistive-panel-output">{lastFix.slice(0, 1500)}</div>
        </div>
      )}
    </div>
  );
}
