import { useState } from 'react';
import AgentPanel from './AgentPanel';
import AssistiveAgentPanel from './AssistiveAgentPanel';
import './WorkspaceMenu.css';

export default function RightSidebar() {
  const [tab, setTab] = useState<'agent' | 'assistive'>('agent');

  return (
    <aside className="workspace-right">
      <div className="right-sidebar-tabs">
        <button
          type="button"
          className={`right-sidebar-tab ${tab === 'agent' ? 'active' : ''}`}
          onClick={() => setTab('agent')}
        >
          Workspace Agent
        </button>
        <button
          type="button"
          className={`right-sidebar-tab ${tab === 'assistive' ? 'active' : ''}`}
          onClick={() => setTab('assistive')}
        >
          Assistive
        </button>
      </div>
      {tab === 'agent' ? <AgentPanel /> : <AssistiveAgentPanel />}
    </aside>
  );
}
