import { useState } from 'react';
import { Wand2, ChevronDown, ChevronUp } from 'lucide-react';
import { useVibeCodeStore } from '../../store/vibeCodeStore';
import type { VibeCodeApplyMode } from '../../lib/vibeCode/types';
import './VibeCodePanel.css';

const LANGUAGES = ['typescript', 'javascript', 'python', 'rust', 'go', 'bash', 'shell', 'java', 'kotlin', 'cpp'];

export default function VibeCodePanel() {
  const config = useVibeCodeStore((s) => s.config);
  const lastRunTools = useVibeCodeStore((s) => s.lastRunTools);
  const setConfig = useVibeCodeStore((s) => s.setConfig);
  const setEnabled = useVibeCodeStore((s) => s.setEnabled);
  const [expanded, setExpanded] = useState(false);

  function toggleLanguage(lang: string) {
    const langs = config.languages.includes(lang)
      ? config.languages.filter((l) => l !== lang)
      : [...config.languages, lang];
    setConfig({ languages: langs });
  }

  return (
    <div className={`vcp-panel ${config.enabled ? 'vcp-panel--on' : ''}`}>
      <button
        type="button"
        className="vcp-toggle"
        onClick={() => setEnabled(!config.enabled)}
        title="Self-Control — agents bootstrap skills, tools, terminals, MCP on demand"
      >
        <Wand2 size={14} />
        <span>Self-Control</span>
        <span className={`vcp-badge ${config.enabled || config.autoBootstrap ? 'on' : ''}`}>
          {config.enabled ? 'VIBE' : config.autoBootstrap ? 'AUTO' : 'OFF'}
        </span>
      </button>

      {config.enabled && lastRunTools > 0 && (
        <span className="vcp-stat">{lastRunTools} tools last run</span>
      )}

      <button type="button" className="vcp-expand" onClick={() => setExpanded(!expanded)}>
        {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
      </button>

      {expanded && (
        <div className="vcp-settings">
          <label>
            <span>Apply mode</span>
            <select
              value={config.applyMode}
              onChange={(e) => setConfig({ applyMode: e.target.value as VibeCodeApplyMode })}
            >
              <option value="review">Review — approve writes & commands</option>
              <option value="auto">Auto — apply immediately</option>
              <option value="bypass">Bypass — unrestricted</option>
            </select>
          </label>
          <label>
            <span>Max iterations</span>
            <input
              type="number"
              min={1}
              max={30}
              value={config.maxIterations}
              onChange={(e) => setConfig({ maxIterations: Number(e.target.value) })}
            />
          </label>
          <div className="vcp-checks">
            <label>
              <input type="checkbox" checked={config.autoBootstrap} onChange={(e) => setConfig({ autoBootstrap: e.target.checked })} />
              Auto-bootstrap (self-control when lacking capability)
            </label>
            <label>
              <input type="checkbox" checked={config.enabled} onChange={(e) => setEnabled(e.target.checked)} />
              Force Vibe Code loop every message
            </label>
            <label>
              <input type="checkbox" checked={config.allowSelfModify} onChange={(e) => setConfig({ allowSelfModify: e.target.checked })} />
              Self-modify system files
            </label>
            <label>
              <input type="checkbox" checked={config.allowSkillCreate} onChange={(e) => setConfig({ allowSkillCreate: e.target.checked })} />
              Create skills
            </label>
            <label>
              <input type="checkbox" checked={config.allowPluginCreate} onChange={(e) => setConfig({ allowPluginCreate: e.target.checked })} />
              Create plugins
            </label>
            <label>
              <input type="checkbox" checked={config.allowMcpProvision} onChange={(e) => setConfig({ allowMcpProvision: e.target.checked })} />
              Provision sandbox MCP
            </label>
            <label>
              <input type="checkbox" checked={config.allowInternet} onChange={(e) => setConfig({ allowInternet: e.target.checked })} />
              Internet search &amp; fetch
            </label>
            <label>
              <input type="checkbox" checked={config.allowMcpAutoConnect} onChange={(e) => setConfig({ allowMcpAutoConnect: e.target.checked })} />
              Auto-discover &amp; connect MCP
            </label>
            <label>
              <input type="checkbox" checked={config.allowAppInstall} onChange={(e) => setConfig({ allowAppInstall: e.target.checked })} />
              Install apps on user system
            </label>
          </div>
          <div className="vcp-langs">
            <span>Languages</span>
            <div className="vcp-lang-grid">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang}
                  type="button"
                  className={config.languages.includes(lang) ? 'active' : ''}
                  onClick={() => toggleLanguage(lang)}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>
          <p className="vcp-hint">
            Unstoppable hardware bot: search the internet, connect MCP SSE servers, install plugins/apps, inspect the system, download files — all via OCEAN_TOOL on your machine.
          </p>
        </div>
      )}
    </div>
  );
}
