import { useState, useRef, useEffect } from 'react';
import { MoreVertical, Download, Upload, FolderUp, FileUp, Archive } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { getOceanAPI } from '../../lib/platform';
import './WorkspaceMenu.css';

type ExportFormat = 'zip' | 'tar.gz' | 'json';

export default function WorkspaceMenu() {
  const workspacePath = useAppStore((s) => s.workspacePath);
  const refreshFileTree = useAppStore((s) => s.bumpFileTree);
  const [open, setOpen] = useState(false);
  const [compression, setCompression] = useState(6);
  const [exportFormat, setExportFormat] = useState<ExportFormat>('zip');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  async function handleExport() {
    if (!workspacePath) return;
    setBusy(true);
    setStatus('Exporting…');
    try {
      const api = getOceanAPI();
      if (!api.workspace?.export) {
        setStatus('Export requires Electron desktop');
        return;
      }
      const result = await api.workspace.export(workspacePath, exportFormat, compression);
      if (result.ok) {
        setStatus(`Exported ${result.fileCount ?? ''} files → ${result.path ?? exportFormat}`);
      } else {
        setStatus(result.error ?? 'Export failed');
      }
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Export failed');
    } finally {
      setBusy(false);
    }
  }

  async function handleUploadFiles() {
    if (!workspacePath) return;
    setBusy(true);
    setStatus('Uploading files…');
    try {
      const api = getOceanAPI();
      const files = await api.upload.selectFiles();
      if (!files.length) { setStatus('Cancelled'); return; }
      if (api.workspace?.uploadFiles) {
        const n = await api.workspace.uploadFiles(workspacePath, files);
        setStatus(`Uploaded ${n} file(s)`);
        refreshFileTree();
      } else {
        for (const f of files) {
          const dest = `${workspacePath}/${f.name}`;
          const binary = atob(f.content);
          await api.fs.writeFile(dest, binary);
        }
        setStatus(`Uploaded ${files.length} file(s)`);
        refreshFileTree();
      }
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Upload failed');
    } finally {
      setBusy(false);
    }
  }

  async function handleUploadFolder() {
    if (!workspacePath) return;
    setBusy(true);
    setStatus('Uploading folder…');
    try {
      const api = getOceanAPI();
      if (api.workspace?.uploadFolder) {
        const n = await api.workspace.uploadFolder(workspacePath);
        setStatus(n > 0 ? `Copied ${n} files from folder` : 'Cancelled');
        refreshFileTree();
      } else {
        setStatus('Folder upload requires Electron desktop');
      }
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Upload failed');
    } finally {
      setBusy(false);
    }
  }

  async function handleImportZip() {
    if (!workspacePath) return;
    setBusy(true);
    setStatus('Importing zip…');
    try {
      const api = getOceanAPI();
      if (api.workspace?.importZip) {
        const result = await api.workspace.importZip(workspacePath);
        setStatus(result.ok ? 'Zip imported' : (result.error ?? 'Import failed'));
        refreshFileTree();
      } else {
        setStatus('Zip import requires Electron desktop');
      }
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'Import failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="workspace-menu" ref={ref}>
      <button
        type="button"
        className="workspace-menu-trigger"
        onClick={() => setOpen((v) => !v)}
        title="Workspace actions"
        aria-label="Workspace menu"
      >
        <MoreVertical size={16} />
      </button>

      {open && (
        <div className="workspace-menu-dropdown">
          <div className="workspace-menu-section">
            <div className="workspace-menu-label">
              <Download size={14} /> Export codebase
            </div>
            <select
              className="workspace-menu-select"
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as ExportFormat)}
            >
              <option value="zip">ZIP archive</option>
              <option value="tar.gz">TAR.GZ archive</option>
              <option value="json">JSON manifest</option>
            </select>
            {exportFormat !== 'json' && (
              <label className="workspace-menu-slider">
                <span>Compression: {compression}</span>
                <input
                  type="range"
                  min={0}
                  max={9}
                  value={compression}
                  onChange={(e) => setCompression(Number(e.target.value))}
                />
              </label>
            )}
            <button type="button" className="workspace-menu-action" disabled={busy || !workspacePath} onClick={handleExport}>
              <Archive size={14} /> Download {exportFormat.toUpperCase()}
            </button>
          </div>

          <div className="workspace-menu-divider" />

          <div className="workspace-menu-section">
            <div className="workspace-menu-label">
              <Upload size={14} /> Import / Upload
            </div>
            <button type="button" className="workspace-menu-action" disabled={busy || !workspacePath} onClick={handleUploadFiles}>
              <FileUp size={14} /> Upload file(s)
            </button>
            <button type="button" className="workspace-menu-action" disabled={busy || !workspacePath} onClick={handleUploadFolder}>
              <FolderUp size={14} /> Upload folder
            </button>
            <button type="button" className="workspace-menu-action" disabled={busy || !workspacePath} onClick={handleImportZip}>
              <Archive size={14} /> Import ZIP
            </button>
          </div>

          {status && <p className="workspace-menu-status">{status}</p>}
        </div>
      )}
    </div>
  );
}
