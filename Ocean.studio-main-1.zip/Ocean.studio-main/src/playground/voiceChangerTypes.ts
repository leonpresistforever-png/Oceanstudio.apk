export type VoiceChangerPreset = 'custom' | 'robot' | 'deep' | 'chipmunk' | 'radio' | 'demon' | 'whisper';

export type VoiceChangerInputSource = 'mic' | 'file';

export interface VoiceChangerConfig {
  inputSource: VoiceChangerInputSource;
  preset: VoiceChangerPreset;
  pitch: number;
  formant: number;
  speed: number;
  reverb: number;
  distortion: number;
  outputVolume: number;
  monitor: boolean;
}

export const VOICE_CHANGER_PRESETS: Record<VoiceChangerPreset, Partial<VoiceChangerConfig>> = {
  custom: {},
  robot: { pitch: -2, formant: 1.4, distortion: 0.35, reverb: 0.1 },
  deep: { pitch: -8, formant: 0.7, speed: 0.92, reverb: 0.15 },
  chipmunk: { pitch: 10, formant: 1.6, speed: 1.15 },
  radio: { pitch: 0, formant: 1.1, distortion: 0.25, reverb: 0.05 },
  demon: { pitch: -12, formant: 0.55, distortion: 0.5, reverb: 0.3 },
  whisper: { pitch: 2, formant: 0.85, speed: 0.88, reverb: 0.2 },
};

export const DEFAULT_VOICE_CHANGER_CONFIG: VoiceChangerConfig = {
  inputSource: 'mic',
  preset: 'custom',
  pitch: 0,
  formant: 1,
  speed: 1,
  reverb: 0,
  distortion: 0,
  outputVolume: 0.85,
  monitor: true,
};

export const VOICE_CHANGER_PRESET_LABELS: Record<VoiceChangerPreset, string> = {
  custom: 'Custom',
  robot: 'Robot',
  deep: 'Deep Voice',
  chipmunk: 'Chipmunk',
  radio: 'AM Radio',
  demon: 'Demon',
  whisper: 'Whisper',
};
