/**
 * Smoke test for vibe code — run: node scripts/vibe-code-check.mjs
 */
import { readFileSync } from 'fs';

const sample = `
OCEAN_TOOL: {"tool":"write_file","args":{"path":"src/foo.ts","content":"export const x = { nested: true }"}}
OCEAN_TOOLS: [{"tool":"done","args":{"summary":"ok"}}]
`;

function extractBalancedJson(text, startIdx) {
  if (text[startIdx] !== '{') return null;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = startIdx; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escape) escape = false;
      else if (ch === '\\') escape = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return text.slice(startIdx, i + 1);
    }
  }
  return null;
}

let passed = 0;
let failed = 0;

function assert(cond, msg) {
  if (cond) { passed++; console.log(`  ✓ ${msg}`); }
  else { failed++; console.error(`  ✗ ${msg}`); }
}

const marker = /OCEAN_TOOL:\s*/i.exec(sample);
const json = extractBalancedJson(sample, marker.index + marker[0].length);
assert(json !== null, 'extracts balanced JSON with nested braces');
const parsed = JSON.parse(json);
assert(parsed.tool === 'write_file', 'tool name correct');
assert(parsed.args.content.includes('nested'), 'nested content preserved');

const files = [
  'src/lib/vibeCode/parser.ts',
  'src/lib/vibeCode/executor.ts',
  'src/lib/vibeCode/runner.ts',
  'src/lib/vibeCode/approval.ts',
  'agent/vibe-code-skill.md',
];
for (const f of files) {
  try {
    readFileSync(f, 'utf8');
    assert(true, `file exists: ${f}`);
  } catch {
    assert(false, `file exists: ${f}`);
  }
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
