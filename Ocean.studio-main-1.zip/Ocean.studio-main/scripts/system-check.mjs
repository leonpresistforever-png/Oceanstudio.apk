#!/usr/bin/env node
/**
 * Ocean.studio system health check — run: npm run check:all
 * Validates extensions store, skills, plugins, vibe code, agent docs, catalogs.
 */
import { readFileSync, existsSync, statSync } from 'fs';
import { execSync } from 'child_process';

let passed = 0;
let failed = 0;
const warnings = [];

function assert(cond, msg) {
  if (cond) { passed++; console.log(`  ✓ ${msg}`); }
  else { failed++; console.error(`  ✗ ${msg}`); }
}

function warn(msg) {
  warnings.push(msg);
  console.warn(`  ⚠ ${msg}`);
}

function fileExists(path, label = path) {
  const ok = existsSync(path);
  assert(ok, `file exists: ${label}`);
  return ok;
}

function readJson(path) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

function readCountExport(filePath, exportName) {
  const src = readFileSync(filePath, 'utf8');
  const m = src.match(new RegExp(`export const ${exportName}\\s*=\\s*(\\d+)`));
  return m ? parseInt(m[1], 10) : -1;
}

console.log('\n=== Ocean.studio System Check ===\n');

// ── Extensions store ──
console.log('Extensions Store');
fileExists('src/extensions/extensionsStore.ts');
fileExists('src/extensions/types.ts');
fileExists('src/extensions/builtinCatalog.ts');
fileExists('src/extensions/researcher.ts');
fileExists('src/extensions/marketplaceSeed.ts');
fileExists('src/components/extensions/ExtensionsStorePanel.tsx');
fileExists('src/pages/ExtensionsPage.tsx');
fileExists('src/lib/extensionHealth.ts');
fileExists('agent/extensions-skill.md');

const extStore = readFileSync('src/extensions/extensionsStore.ts', 'utf8');
assert(extStore.includes('ocean-extensions-store'), 'extensions persist key configured');
assert(extStore.includes('MAX_INSTALLED_EXTENSIONS'), 'extension cap defined');
assert(extStore.includes('getEnabled'), 'getEnabled() exported');
assert(extStore.includes('addAgentExtension'), 'agent extension creation supported');

const builtinExtCount = readCountExport('src/extensions/builtinCatalog.ts', 'BUILTIN_EXTENSION_COUNT');
assert(builtinExtCount >= 50, `builtin extensions catalog (${builtinExtCount} entries)`);

const extTypes = readFileSync('src/extensions/types.ts', 'utf8');
assert(extTypes.includes('serializeExtensionsForAgent'), 'agent serialization helper');
assert(extTypes.includes('parseExtensionManifest'), 'manifest parser present');

const agentCtx = readFileSync('src/lib/agentContext.ts', 'utf8');
assert(agentCtx.includes('useExtensionsStore'), 'extensions wired into agentContext');
assert(agentCtx.includes('checkExtensionHealth'), 'extension health in agent context');

// ── Skills store ──
console.log('\nSkills Store');
fileExists('src/skills/skillsStore.ts');
fileExists('src/skills/builtinCatalog.ts');
fileExists('src/skills/researcher.ts');
const skillCount = readCountExport('src/skills/builtinCatalog.ts', 'BUILTIN_SKILL_COUNT');
assert(skillCount >= 40, `builtin skills catalog (${skillCount} entries)`);

// ── Plugins ──
console.log('\nPlugins');
fileExists('src/plugins/marketplace/official.ts');
fileExists('src/plugins/registry.ts');
const pluginSrc = readFileSync('src/plugins/marketplace/official.ts', 'utf8');
const pluginMatches = pluginSrc.match(/id:\s*'ocean\./g);
assert((pluginMatches?.length ?? 0) >= 30, `official plugins (${pluginMatches?.length ?? 0} entries)`);

// ── Vibe code / self-control ──
console.log('\nVibe Code / Self-Control');
fileExists('src/lib/vibeCode/runner.ts');
fileExists('src/lib/vibeCode/executor.ts');
fileExists('src/lib/vibeCode/autonomy.ts');
fileExists('src/lib/vibeCode/toolNames.ts');
fileExists('agent/vibe-code-skill.md');

const toolNames = readFileSync('src/lib/vibeCode/toolNames.ts', 'utf8');
const toolCount = (toolNames.match(/'/g) ?? []).length / 2;
assert(toolCount >= 25, `vibe tool names registered (${Math.floor(toolCount)} tools)`);

// ── Open source tools ──
console.log('\nOpen Source Tools');
fileExists('src/tools/openSourceCatalog.ts');
fileExists('src/store/openSourceToolsStore.ts');
fileExists('agent/open-source-tools-skill.md');

const ossSrc = readFileSync('src/tools/openSourceCatalog.ts', 'utf8');
assert(ossSrc.includes('claw-code'), 'Claw Code in open source catalog');
assert(ossSrc.includes('aider'), 'Aider in open source catalog');

// ── MCP / Sandbox ──
console.log('\nMCP / Sandbox');
fileExists('src/mcp/sandboxCatalog.ts');
fileExists('src/mcp/sandboxRuntime.ts');
fileExists('agent/mcp-skill.md');
fileExists('agent/sandbox-mcp-skill.md');
fileExists('agent/mcp-config.json');

// ── Agent skill docs ──
console.log('\nAgent Skill Docs');
const agentDocs = [
  'agent/agent.md',
  'agent/skill.md',
  'agent/main-agent-skill.md',
  'agent/tools-skill.md',
  'agent/provider-skill.md',
  'agent/multi-agent-skill.md',
  'agent/extensions-skill.md',
  'agent/open-source-tools-skill.md',
  'agent/vibe-code-skill.md',
  'agent/mcp-skill.md',
  'agent/sandbox-mcp-skill.md',
  'agent/assistive-agent-skill.md',
  'agent/universal-agent-context-skill.md',
  'agent/context-injection-skill.md',
];
for (const doc of agentDocs) {
  fileExists(doc);
}

const providerCtx = readFileSync('src/providers/context.ts', 'utf8');
assert(providerCtx.includes('open-source-tools-skill.md'), 'open source tools skill injected in provider context');
assert(providerCtx.includes('extensions-skill.md'), 'extensions skill injected');

// ── Local models / BYOK ──
console.log('\nLocal Models / BYOK');
fileExists('src/models/localCatalog.ts');
fileExists('src/pages/LocalModelsPage.tsx');
fileExists('src/store/byokStore.ts');
const modelSrc = readFileSync('src/models/localCatalog.ts', 'utf8');
const modelMatches = modelSrc.match(/ollama\(/g);
const modelCount = modelMatches?.length ?? 0;
assert(modelCount >= 80, `local model catalog (${modelCount} models)`);

assert(providerCtx.includes('assistive-agent-skill.md'), 'assistive agent skill injected');

assert(providerCtx.includes('context-injection-skill.md'), 'context injection skill injected');

const assembleSrc = readFileSync('src/lib/assembleAgentSystemPrompt.ts', 'utf8');
assert(assembleSrc.includes('Installed Skills'), 'installed skills serialized in system prompt');

console.log('\nContext Injection');
fileExists('src/lib/contextInjection.ts');
const toolNamesSrc = readFileSync('src/lib/vibeCode/toolNames.ts', 'utf8');
assert(toolNamesSrc.includes('inject_context_file'), 'inject_context_file tool registered');
assert(toolNamesSrc.includes('inject_fastflag'), 'inject_fastflag tool registered');

console.log('\nVoice Changer Playground');
fileExists('src/playground/voiceChangerTypes.ts');
fileExists('src/store/voiceChangerStore.ts');
fileExists('src/components/playground/VoiceChangerPanel.tsx');
fileExists('src/lib/voiceChangerRunner.ts');

const officialPlugins = readFileSync('src/plugins/marketplace/official.ts', 'utf8');
assert(officialPlugins.includes('ocean.assistive-code'), 'assistive code plugin in marketplace');
const mcpCatalog = readFileSync('src/mcp/catalog.ts', 'utf8');
assert(mcpCatalog.includes('mcp.ocean-assistive'), 'assistive MCP in catalog');

console.log('\nAssistive Agent & Workspace Export');
fileExists('src/store/assistiveAgentStore.ts');
fileExists('src/lib/assistiveAgentRunner.ts');
fileExists('src/components/workspace/WorkspaceMenu.tsx');
fileExists('electron/services/workspace-archive.ts');

console.log('\nUniversal Agent Context');
fileExists('src/lib/assembleAgentSystemPrompt.ts');
const inferenceSrc = readFileSync('src/lib/providerInference.ts', 'utf8');
assert(inferenceSrc.includes('assembleAgentSystemPrompt'), 'providerInference uses universal system prompt');

// ── Vibe smoke test ──
console.log('\nVibe Code Smoke');
try {
  execSync('node scripts/vibe-code-check.mjs', { stdio: 'pipe' });
  assert(true, 'vibe-code-check.mjs passes');
} catch {
  assert(false, 'vibe-code-check.mjs passes');
}

// ── TypeScript compile (quick) ──
console.log('\nTypeScript');
try {
  execSync('npx tsc -b --pretty false 2>&1', { stdio: 'pipe', timeout: 120000 });
  assert(true, 'tsc -b compiles');
} catch (e) {
  const out = e.stdout?.toString() ?? e.message;
  assert(false, `tsc -b compiles — ${out.slice(0, 200)}`);
}

// ── Extension health logic sanity ──
console.log('\nExtension Health Logic');
const healthSrc = readFileSync('src/lib/extensionHealth.ts', 'utf8');
assert(healthSrc.includes('agentGuide'), 'health checks agentGuide');
assert(!healthSrc.includes('enabled.length - issues.length') || healthSrc.includes('issueExtIds'),
  'healthy count uses unique extension IDs');

// ── Summary ──
console.log(`\n=== Results: ${passed} passed, ${failed} failed, ${warnings.length} warnings ===`);
if (warnings.length) {
  console.log('\nWarnings:');
  for (const w of warnings) console.log(`  ⚠ ${w}`);
}
console.log('');
process.exit(failed > 0 ? 1 : 0);
