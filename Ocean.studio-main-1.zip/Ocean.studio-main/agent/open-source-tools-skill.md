---
name: ocean-open-source-tools
description: Curated open-source coding agents and CLIs — Claw Code, Aider, Continue, Firecrawl, OpenCode, Goose, and more.
---

# Ocean.studio Open Source Tools

Agents can **install, configure, and use** curated open-source tools on the user's hardware — like a power user running Claw Code, Aider, or Firecrawl CLI alongside Ocean.

## Access

- **Catalog:** `src/tools/openSourceCatalog.ts` — `${OPEN_SOURCE_TOOL_COUNT}` curated tools
- **Store:** `useOpenSourceToolsStore` — persisted in `ocean-open-source-tools` localStorage
- **Agent context:** `openSourceToolsGuide` in `buildAgentContext()` modelConfig
- **Self-Control:** `OCEAN_TOOL install_app`, `run_terminal`, `web_search`, `fetch_store`

## Pre-configured (default ON)

| Tool | ID | Install |
|------|-----|---------|
| **Claw Code** | `oss.claw-code` | `git clone` + `pip install -r requirements.txt` |
| **Claw Code Agent** | `oss.claw-code-agent` | `git clone` (stdlib Python, Ollama/vLLM) |
| **Aider** | `oss.aider` | `pip install aider-chat` |
| **Firecrawl CLI** | `oss.firecrawl-cli` | `npm install -g firecrawl-cli` |
| **Continue** | `oss.continue` | `npm install -g @continuedev/cli` |
| **OpenCode** | `oss.opencode` | `npm install -g opencode-ai@latest` |

## Claw Code Ecosystem

Claw Code is an open-source AI coding agent framework (clean-room Claude Code architecture):

| Project | Repo | Stack | Use when |
|---------|------|-------|----------|
| **Claw Code** | instructkr/claw-code | Python + Rust | Full agent harness, tool system, memory |
| **Claw Code Agent** | HarnessLab/claw-code-agent | Pure Python | Local models (Ollama, vLLM), zero deps |
| **UltraWorkers Claw** | ultraworkers/claw-code | Rust `claw` CLI | Build-from-source Rust harness |
| **Gajae Code** | Yeachan-Heo/gajae-code | Harness | Companion to claw/oh-my-* |
| **Oh My Claude Code** | Yeachan-Heo/oh-my-claudecode | Plugins | Enhanced workflows |

**Important:** Do NOT run `cargo install claw-code` — crates.io stub is deprecated. Build ultraworkers from source.

### Claw Code quick start (agent)

```
OCEAN_TOOL: {"tool":"run_terminal","args":{"command":"git clone https://github.com/instructkr/claw-code.git tools/claw-code && cd tools/claw-code && pip install -r requirements.txt"}}
OCEAN_TOOL: {"tool":"run_terminal","args":{"command":"cd tools/claw-code && python src/main.py","cwd":"."}}
```

For local models:
```
git clone https://github.com/HarnessLab/claw-code-agent.git tools/claw-code-agent
export OPENAI_BASE_URL=http://localhost:11434/v1
python tools/claw-code-agent/main.py
```

## Other Tools

| Tool | Category | Verify |
|------|----------|--------|
| Aider | CLI pair programmer | `aider --version` |
| Continue | IDE autopilot | `cn --version` |
| OpenCode | Terminal agent | `opencode --version` |
| Open Interpreter | Local code exec | `interpreter --version` |
| Firecrawl CLI | Web scrape/search | `firecrawl search "query" --json` |
| Cline | VS Code extension | Install via Extensions marketplace |
| Goose | Block agent CLI | `goose --version` |

## Agent Workflow

1. Check `openSourceToolsGuide` in context for enabled tools
2. If tool missing → `OCEAN_TOOL install_app` or `run_terminal` with install commands from catalog
3. Verify with catalog `verifyCommand`
4. Run tool in `ocean-agent-terminal` or dedicated terminal via `configure_terminal`
5. Pair with Ocean plugins: Firecrawl → `ocean.scrape-firecrawl`, filesystem → `ocean.filesystem-mcp`

## Store API

```typescript
import { useOpenSourceToolsStore } from '@/store/openSourceToolsStore';
import { OPEN_SOURCE_TOOLS, serializeOpenSourceToolsForAgent } from '@/tools/openSourceCatalog';

const enabled = useOpenSourceToolsStore.getState().getEnabledDefinitions();
const guide = serializeOpenSourceToolsForAgent(enabled);
useOpenSourceToolsStore.getState().installTool('oss.claw-code', 'tools/claw-code');
```

## vs Extensions vs Plugins

| Type | Example | Purpose |
|------|---------|---------|
| **Open source tool** | Claw Code, Aider | CLI/agent on user hardware |
| **Extension** | Prettier, Cline | IDE metadata + agentGuide |
| **Plugin** | Filesystem MCP | Runtime MCP/tool bundle |

## Self-Control Integration

When user asks for Claw Code or any OSS tool:
1. `web_search` / `fetch_store` to find latest repo
2. `download_file` or `run_terminal` to clone/install
3. `create_skill` documenting project-specific usage
4. `create_system_file` under `agent/generated/claw-code.md`
5. `install_plugin` if Ocean has matching MCP (e.g. Firecrawl)

Never refuse — bootstrap the tool, then continue the task.
