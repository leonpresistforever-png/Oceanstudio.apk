---
name: ocean-mcp
description: MCP (Model Context Protocol) connectors — complete reference for agents. Separate from Plugins and Extensions.
format: reference
---

# Ocean.studio MCP Skill — Complete Reference

> **MCP ≠ Plugins ≠ Extensions**
> - **MCP Connectors** — protocol servers (stdio/SSE/HTTP) in Tools → MCP Connectors
> - **Plugins** — Ocean runtime bundles in Tools → Plugins
> - **Extensions** — IDE formatters/linters in Tools → Extensions

Read `agent/mcp-config.json` for routing defaults.

---

## 1. What Is MCP?

Model Context Protocol — standard for AI agents to call external tools:
- Filesystem, GitHub, Postgres, Figma, Firebase, browser automation
- Cloud APIs via SSE (Firecrawl, Supabase, Linear, Brave Search)
- Local CLI via stdio (`npx @modelcontextprotocol/server-*`)

Ocean injects connected MCP servers into every `buildAgentContext()` as `mcpServers`.

---

## 2. Platform Transport Matrix

| Platform | stdio (npx) | SSE | HTTP | OAuth |
|----------|-------------|-----|------|-------|
| Electron desktop | ✓ child process | ✓ | ✓ | ✓ localhost:8766 |
| Web browser | ✗ | ✓ | ✓ | ✗ (needs Electron) |
| Android APK | ✗ (use pkg) | ✓ | ✓ | limited |

**Web/APK agents:** Never spawn stdio MCP — guide user to cloud SSE connectors or Electron desktop.

---

## 3. API Surface

```typescript
// List configured connectors
const list = await window.ocean.mcp.list();

// Connect (after config + auth)
await window.ocean.mcp.connect({
  id: 'github',
  transport: 'stdio' | 'sse' | 'http',
  command: 'npx',
  args: ['-y', '@modelcontextprotocol/server-github'],
  env: { GITHUB_PERSONAL_ACCESS_TOKEN: '...' },
  url: 'https://mcp.example.com/sse',  // for sse/http
});

// OAuth flow (Electron)
await window.ocean.mcp.authenticate(config, clientId, clientSecret);
// Callback: http://127.0.0.1:8766/oauth/callback
// Token: userData/mcp-tokens.json

// Disconnect
await window.ocean.mcp.disconnect('github');

// Agent export — CRITICAL before every agent session
const mcpConfig = await window.ocean.mcp.getAgentConfig();
// Returns: { mcpServers: { [id]: config }, connectedCount, updatedAt }
```

### Web fallback (no Electron IPC)
```typescript
import { exportAgentMcpConfig } from '@/mcp/registry';
const mcpRaw = exportAgentMcpConfig();
```

---

## 4. Agent Injection

```typescript
const ctx = await buildAgentContext({ workspacePath, activeFile, terminalType });
// ctx.mcpServers — all connected server configs
// ctx.mcpMeta.connectedCount — health indicator
```

Agent must **only use tools from connected servers** — never invent MCP tool names.

If `connectedCount === 0`:
1. Suggest Tools → MCP Connectors
2. Recommend Instant Connect servers (no API key): Cloudflare Docs, DeepWiki
3. For local needs: guide to Electron desktop

---

## 5. Auth Tags (UI Cards)

| Badge | Behavior |
|-------|----------|
| **Instant Connect** | One click — no modal (public SSE endpoints) |
| **API Key** | Config modal — user enters key before connect |
| **OAuth** | Browser redirect flow |
| **OAuth Client** | Client ID + Secret + redirect |
| **Local npx** | Desktop stdio spawn — may need env vars |

---

## 6. MCP Store (Playground)

Access: Playground → MCP Store (130+ entries)

Features:
- Feature-tagged (image, 3D, research, agents, etc.)
- Custom MCP add with `MCP_ENV_TEMPLATE`
- `playgroundStore.addCustomMarketplaceTool`
- Filter by `MARKETPLACE_FEATURE_FILTERS`

### Extra MCP by feature (`marketplaceCatalog.ts`)
- media-3d: Meshy, Tripo, Luma, Replicate 3D, Fal, HF, Spline, Rodin, CSM, Stability
- media-image: Leonardo, Ideogram, BFL, GetImg, Prodia
- media-video: MiniMax, Haiper, Luma Dream
- audio-tts: PlayHT, Murf, Resemble
- audio-music: Udio, Soundraw, AIVA
- research: Tavily, Exa, Brave Search, Jina Reader
- agents: Computer Use, Shell, Git
- recording: OBS WebSocket, FFmpeg Record

---

## 7. MCP Connectors Page (Full UI)

Access: Sidebar → Tools → MCP Connectors

Tabs:
- Ready to Use — curated instant + API key
- Open Source Cloud — SSE servers from GitHub
- Local — stdio npx (desktop only)
- Connected — active sessions

Per-connector: connect, disconnect, test, env config, OAuth.

---

## 8. Multi-Agent MCP Scoping

`memberContext.ts` — per sub-agent MCP filter:
- `access.mcp: true/false`
- `assignedMcpIds[]` — only these servers for worker
- MCP archetype member → all assigned MCP tools

Head agent typically gets full MCP set; workers get scoped subset.

---

## 9. Common MCP Servers

| Server | Transport | Env |
|--------|-----------|-----|
| filesystem | stdio | paths arg |
| github | stdio | GITHUB_PERSONAL_ACCESS_TOKEN |
| postgres | stdio | DATABASE_URL |
| firebase | stdio | service account |
| figma | stdio | FIGMA_ACCESS_TOKEN |
| browser | stdio | — |
| firecrawl | sse | FIRECRAWL_API_KEY |
| brave-search | sse | BRAVE_API_KEY |
| supabase | sse | SUPABASE_URL, KEY |

---

## 10. Playground vs Workspace MCP Usage

| Context | When MCP is used |
|---------|------------------|
| Main agent | All connected MCPs in context; agent calls via provider tool loop |
| Playground research | Firecrawl, Tavily, Jina via MCP for web tasks |
| Playground 3D | Meshy/Tripo MCP as 3D providers |
| Playground MCP Store | Browse/install only — not execution |

---

## 11. Error Handling

| Error | Agent response |
|-------|----------------|
| stdio on web | "Local MCP requires Electron desktop app" |
| OAuth on web | "OAuth MCP requires Electron — start Ocean proxy for LAN callback on mobile" |
| Missing API key | Open connector config, enter key, retry |
| Connection timeout | Check URL, network, API key validity |
| Tool not found | Server not connected — list `mcp.list()` |

---

## 12. mcp-config.json Structure

```json
{
  "mcpServers": {
    "filesystem": { "command": "npx", "args": ["-y", "@modelcontextprotocol/server-filesystem", "/workspace"] },
    "github": { "command": "npx", "args": ["-y", "@modelcontextprotocol/server-github"], "env": {} }
  },
  "routing": {
    "defaultTransport": "stdio",
    "preferCloudOnMobile": true
  }
}
```

Agents read this file path reference from `agent/tools-skill.md`.

---

## 13. Electron MCP Manager

`electron/services/mcp-manager.ts`:
- Spawns stdio child processes
- Manages SSE/HTTP persistent connections
- Token storage in userData
- `getAgentConfig()` for IPC → renderer

---

## 14. Registry (Web)

`src/mcp/registry.ts`:
- localStorage connector registry
- `exportAgentMcpConfig()` for web agent context
- Sync with backend when Electron available

---

## 15. MCP Workflow Checklist

```
□ Call mcp.getAgentConfig() or use buildAgentContext()
□ Check mcpMeta.connectedCount > 0
□ Match user task to available server (github for PRs, filesystem for files)
□ If tool missing → suggest connect specific MCP from catalog
□ Never hallucinate tool names — use provider's tool list only
□ On mobile → prefer SSE cloud MCPs over stdio
```

---

## 16. Related Files

| File | Purpose |
|------|---------|
| `agent/mcp-config.json` | Default routing |
| `agent/tools-skill.md` | MCP + Plugin combined API |
| `src/mcp/registry.ts` | Web registry |
| `src/mcp/catalog.ts` | Connector catalog |
| `electron/services/mcp-manager.ts` | Desktop process manager |
| `src/pages/McpConnectorsPage.tsx` | Full UI |
