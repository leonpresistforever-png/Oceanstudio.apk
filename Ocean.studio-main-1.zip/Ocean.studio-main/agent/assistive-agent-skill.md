---
name: ocean-assistive-agent
description: Inline codebase assistive agent — speeds up manual coding, fixes errors, completions while user types.
---

# Assistive Agent

Dedicated **codebase assistive bot** for when the user writes code manually — separate from the main Workspace Agent chat.

## Purpose

- Speed up typing with suggestions and completions
- Fix errors the user makes (syntax, logic)
- Explain selection
- Advanced control via assist level slider (0–100%)

## Configuration

**Right sidebar → Assistive tab**

| Setting | Description |
|---------|-------------|
| Agent source | Provider, BYOK/API key, MCP, Plugin, Local (Ollama) |
| Provider / Plugin | Assign which backend powers assist |
| Model | Fast model recommended (gpt-4o-mini, gemini-flash) |
| Assist level | Slider — higher = more aggressive auto-check |
| Auto-check on pause | Debounced analysis after typing stops |
| Inline hints | Show hints bar under editor toolbar |

Persisted: `ocean-assistive-agent` localStorage.

## Editor toolbar

When editing a file:

- **Assistive** toggle
- **Fix errors** — Ctrl+Shift+F
- **Complete** — Ctrl+Shift+Space
- **Explain** — selection
- **Speed** slider (synced with Assistive panel)

Uses `runAssistiveAgent()` → `buildAgentContext()` + `assembleAgentSystemPrompt()` + `runAgentInference()`.

## Workspace menu (⋮)

Center panel tabs → **⋮** menu:

- **Export:** ZIP, TAR.GZ, JSON manifest + compression slider
- **Upload file(s)**
- **Upload folder** (Electron)
- **Import ZIP**

Electron IPC: `workspace:export`, `workspace:importZip`, `workspace:uploadFiles`, `workspace:uploadFolder`.

## vs Workspace Agent

| | Workspace Agent | Assistive Agent |
|--|-----------------|-----------------|
| UI | Right panel chat | Editor toolbar + Assistive tab |
| Scope | Full tasks, terminal, MCP | Active file / selection |
| Latency | Full agent loop | Fast inference, low tokens |
| Self-Control | OCEAN_TOOL bootstrap | No — stays lightweight |
