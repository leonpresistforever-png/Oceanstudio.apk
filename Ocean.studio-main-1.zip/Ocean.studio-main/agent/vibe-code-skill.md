---
name: ocean-vibe-code
description: Self-modifying agent protocol — vibe code skills, tools, plugins, system files, requirements in any language. Main agent + Vibe Coder sub-agents.
---

# Vibe Code — Complete Self-Modification Protocol

Agents can **vibe code themselves**: when lacking a tool, function, skill, plugin, or system file — **create it** using the OCEAN_TOOL protocol, then continue the task.

**Applies to:** Main workspace agent (Vibe Code toggle ON) + Multi-agent `vibecoder` and `tools` archetypes.

---

## 1. When to Activate

| Trigger | Action |
|---------|--------|
| User says "vibe code", "create a skill", "self-modify" | Enable OCEAN_TOOL loop |
| Agent lacks capability for task | `create_skill` or `create_plugin_manifest` |
| Missing requirements file | `create_requirements` + `install_dependency` |
| Missing agent doc | `create_system_file` under `agent/` |
| User enables Vibe Code toggle | All main agent sends use `runVibeCodeAgent` |

Toggle: Agent Panel → **Vibe Code** ON/OFF (`vibeCodeStore`, persisted).

---

## 2. Architecture

```
User message
  → runVibeCodeAgent (max iterations, default 12)
  → runAgentInference with vibe system appendix
  → parseVibeToolCalls (balanced-brace JSON parser)
  → executeVibeTool for each call
  → formatToolResults → next inference iteration
  → until done tool or no more tools or max iterations
```

Source files:
- `src/lib/vibeCode/runner.ts` — iteration loop
- `src/lib/vibeCode/executor.ts` — tool implementations
- `src/lib/vibeCode/parser.ts` — OCEAN_TOOL extraction
- `src/lib/vibeCode/approval.ts` — review mode confirm dialog
- `src/store/vibeCodeStore.ts` — config persistence

---

## 3. OCEAN_TOOL Protocol

### Single tool
```
OCEAN_TOOL: {"tool":"write_file","args":{"path":"src/utils.ts","content":"export function add(a,b){return a+b}"}}
```

### Batch tools
```
OCEAN_TOOLS: [
  {"tool":"create_requirements","args":{"language":"python","packages":["requests","beautifulsoup4"]}},
  {"tool":"install_dependency","args":{"language":"python","packages":["requests","beautifulsoup4"]}},
  {"tool":"create_skill","args":{"name":"web-scraper","content":"---\nname: web-scraper\n..."}}
]
```

### Completion
```
OCEAN_TOOL: {"tool":"done","args":{"summary":"Created scraper skill and installed deps"}}
```

### Fenced alternative
````markdown
```ocean_tool
{"tool":"read_file","args":{"path":"package.json"}}
```
````

**Parser supports nested JSON** in string values (balanced-brace extraction).

---

## 4. All Tools — Complete Reference

### read_file
```json
{"tool":"read_file","args":{"path":"src/App.tsx"}}
```
Reads workspace file (max 50k chars returned).

### write_file
```json
{"tool":"write_file","args":{"path":"src/newFeature.ts","content":"..."}}
```
Writes file. Path must be under allowed write roots. Review mode → confirm dialog.

### list_dir
```json
{"tool":"list_dir","args":{"path":"src/components"}}
```

### run_terminal
```json
{"tool":"run_terminal","args":{"command":"npm test","cwd":"."}}
```
Runs in `ocean-vibe-code-terminal` session. Supports any shell command.

### create_skill
```json
{"tool":"create_skill","args":{"name":"PDF Parser","content":"---\nname: pdf-parser\n...","writeToDisk":true}}
```
- Calls `skillsStore.addAgentSkill`
- Optionally writes `agent/generated/pdf-parser.md`
- Scope: `both` (main + playground)

### create_extension
```json
{"tool":"create_extension","args":{"name":"My Workflow","guide":"## Steps\n1. ..."}}
```
Registers in `extensionsStore.addAgentExtension`.

### create_requirements
```json
{"tool":"create_requirements","args":{"language":"python","packages":["pandas","numpy"],"path":"requirements.txt"}}
```
Generates:
| language | file |
|----------|------|
| python | requirements.txt |
| node/typescript/javascript | package.json |
| rust | Cargo.toml |
| go | go.mod |

### create_system_file
```json
{"tool":"create_system_file","args":{"path":"agent/generated/my-workflow.md","content":"# Workflow\n..."}}
```
Allowed roots: `agent/`, `.ocean/agent/`, `.ocean/`, plus write paths.
Requires `allowSelfModify: true`.

### create_custom_function
```json
{"tool":"create_custom_function","args":{"name":"parse_csv","description":"Parse CSV files","parameters":{"type":"object","properties":{"path":{"type":"string"}}}}}
```
Registers in `modelStore.addCustomFunction` → available in next inference as tool.

### create_plugin_manifest
```json
{"tool":"create_plugin_manifest","args":{"id":"csv-tool","name":"CSV Tool","entry":"index.js","description":"CSV parser plugin","entryContent":"module.exports = { tools: [...] }"}}
```
Writes `.ocean/plugins/csv-tool/ocean.plugin.json` + optional entry file.

### install_dependency
```json
{"tool":"install_dependency","args":{"language":"python","packages":["pypdf"]}}
```
Runs: `pip install`, `npm install`, `cargo add`, or `go get`.

### done
```json
{"tool":"done","args":{"summary":"All tools created and verified"}}
```

### configure_terminal
```json
{"tool":"configure_terminal","args":{"terminalType":"shell","terminalId":"ocean-agent-terminal","setupCommands":["npm install -g some-cli","which some-cli"]}}
```
Creates/configures a terminal session on the user's hardware. Use when the agent lacks shell access.

### connect_sandbox_mcp
```json
{"tool":"connect_sandbox_mcp","args":{"presetId":"sandbox.pottekkat","name":"Docker Sandbox"}}
```
Connects a sandbox MCP server preset (`sandbox.pottekkat`, `sandbox.node-code`, `sandbox.e2b-mcp`, etc.).

### create_ui_asset
```json
{"tool":"create_ui_asset","args":{"format":"html","path":"public/report.html","title":"Report","body":"<p>Hello</p>","css":"body{font-family:serif}"}}
```
Creates HTML, Markdown, CSS, or JSON UI assets. For PDF, create HTML then `run_terminal` with print-to-PDF.

### provision_capability
```json
{"tool":"provision_capability","args":{"name":"game-launcher","description":"Play games on user machine","skillContent":"# Game Launcher\n...","language":"python","packages":["pyautogui"],"terminalSetup":["pip install pyautogui"],"mcpPresetId":"sandbox.pottekkat"}}
```
**Bundled self-control bootstrap** — creates skill, system files, requirements, installs deps, configures terminal, connects MCP in one shot. Use when starting from zero capability.

### web_search
```json
{"tool":"web_search","args":{"query":"mcp server sse github","sources":["github","npm","web"]}}
```
Search GitHub, npm, and DuckDuckGo for packages, repos, and docs.

### fetch_url
```json
{"tool":"fetch_url","args":{"url":"https://example.com/docs","savePath":"agent/generated/docs.md"}}
```
Fetch any URL; optionally save to workspace.

### discover_mcp
```json
{"tool":"discover_mcp","args":{"query":"filesystem mcp server"}}
```
Find open-source MCP servers via GitHub search and local package index.

### connect_mcp
```json
{"tool":"connect_mcp","args":{"name":"My MCP","transport":"sse","url":"https://mcp.example.com/sse"}}
```
Connect SSE/HTTP/stdio MCP servers; writes config to `agent/generated/`.

### install_plugin
```json
{"tool":"install_plugin","args":{"pluginId":"ocean-browser"}}
```
Install from official plugin store via `api.plugins.install`.

### create_plugin_compat
```json
{"tool":"create_plugin_compat","args":{"pluginId":"vscode-extension","shimType":"vscode","config":{"entry":"index.js"}}}
```
Create compatibility shim in `.ocean/plugins/compat/` so any plugin works with Ocean.

### install_app
```json
{"tool":"install_app","args":{"package":"docker.io","manager":"apt"}}
```
Install system apps via apt, brew, npm, or snap on user hardware.

### fetch_store
```json
{"tool":"fetch_store","args":{"store":"npm","query":"mcp-server"}}
```
Search npm, GitHub, or MCP registry stores.

### inspect_system
```json
{"tool":"inspect_system","args":{"checks":["os","disk","memory","processes","docker","gpu","ollama"]}}
```
Hardware-level inspection: OS, disk, memory, processes, Docker, GPU, Ollama.

### download_file
```json
{"tool":"download_file","args":{"url":"https://example.com/file.zip","path":"downloads/file.zip"}}
```
Download files into workspace.

---

## 5. Self-Control (Auto-Bootstrap)

**Default: ON** (`autoBootstrap: true` in vibeCodeStore).

When enabled, agents run the OCEAN_TOOL loop even if the Vibe Code toggle is OFF. Agents must **never refuse** for lack of capability — they bootstrap:

| Missing | Bootstrap action |
|---------|------------------|
| Terminal | `configure_terminal` + install shell tools |
| Code sandbox | `connect_sandbox_mcp` |
| Skill/knowledge | `create_skill` + `create_system_file` |
| Dependencies | `create_requirements` + `install_dependency` |
| UI (HTML/PDF/MD) | `create_ui_asset` |
| Custom tool | `create_custom_function` + `create_plugin_manifest` |
| Everything at once | `provision_capability` |
| Internet search | `web_search` + `fetch_url` |
| MCP discovery | `discover_mcp` + `connect_mcp` |
| Plugin install | `install_plugin` + `create_plugin_compat` |
| System apps | `install_app` + `fetch_store` |
| Hardware inspect | `inspect_system` + `download_file` |

Agent Panel → **Self-Control** badge shows `AUTO` when auto-bootstrap is on, `VIBE` when force-enabled.

Settings (Self-Control panel): **Internet**, **App install**, **MCP auto-connect** — all on by default.

Context **hot-reloads** after each self-modification so new skills and MCP connectors appear in the next iteration.

---

## 5. Apply Modes

| Mode | write_file | run_terminal | install_dependency |
|------|------------|--------------|-------------------|
| review | Confirm dialog | Confirm dialog | Confirm dialog |
| auto | Immediate | Immediate | Immediate |
| bypass | Immediate | Immediate | Immediate |

Config: Vibe Code panel → Apply mode dropdown.
Also respects `agentMode` from workspace config.

---

## 6. Configuration (vibeCodeStore)

```typescript
{
  enabled: boolean,
  applyMode: 'review' | 'auto' | 'bypass',
  maxIterations: 12,
  languages: ['typescript','javascript','python','rust','go','bash','shell',...],
  allowSelfModify: true,
  allowPluginCreate: true,
  allowSkillCreate: true,
  allowInternet: true,
  allowAppInstall: true,
  allowMcpAutoConnect: true,
  writePaths: ['.','src','agent','.ocean','plugins','scripts'],
  systemPaths: ['agent','.ocean/agent','agent/generated'],
}
```

Injected in context as `vibeCode.serialized` + `buildVibeCodeSystemAppendix()`.

---

## 7. Path Security

- `..` paths rejected
- Resolved path must stay under `workspacePath`
- `write_file` / `create_requirements` check `writePaths`
- `create_system_file` checks `systemPaths`

---

## 8. Language Support

Use `run_terminal` for any language on the host:

| Language | Install | Build | Test |
|----------|---------|-------|------|
| Python | pip, requirements.txt | python -m py_compile | pytest |
| Node/TS | npm, package.json | npm run build | npm test |
| Rust | cargo add, Cargo.toml | cargo build | cargo test |
| Go | go get, go.mod | go build | go test |
| Bash | apt/brew/pkg | shell scripts | — |
| Java/Kotlin | maven/gradle via terminal | — | — |
| C/C++ | gcc/cmake via terminal | make | — |

Platform determines what's installed:
- Electron: full host OS packages
- Cloud Shell: apt, pip, gcloud
- Android native: busybox/proot limited set

---

## 9. Multi-Agent Vibe Coder

Archetype: `vibecoder` in `agents/categories.ts`

```typescript
{
  archetype: 'vibecoder',
  defaultSystemPrompt: 'Vibe Coder — use OCEAN_TOOL to write files, create skills...',
  suggestedRole: 'specialist',
}
```

Template: **Vibe Code Team** (`agents/templates.ts`)
- Vibe Lead (head) — plans modifications
- Vibe Coder (vibecoder) — executes OCEAN_TOOL
- Tool Builder (tools) — verifies via terminal

Workers with `vibecoder` or `tools` archetype get vibe loop even if global toggle is off.

---

## 10. Typical Self-Modification Flows

### Missing skill
```
1. OCEAN_TOOL create_skill with full SKILL.md content
2. OCEAN_TOOL done
3. Skill auto-injected on next buildAgentContext via skillsStore
```

### Missing Python package
```
1. OCEAN_TOOL create_requirements { language: python, packages: [...] }
2. OCEAN_TOOL install_dependency { language: python, packages: [...] }
3. OCEAN_TOOL run_terminal { command: "python -c 'import pkg; print(pkg.__version__)'" }
4. OCEAN_TOOL done
```

### Missing plugin
```
1. OCEAN_TOOL create_plugin_manifest with entryContent
2. OCEAN_TOOL run_terminal { command: "cd .ocean/plugins/my-id && npm install" }
3. Guide user to Plugins page to enable
4. OCEAN_TOOL done
```

### Missing system doc
```
1. OCEAN_TOOL read_file existing agent/skill.md (if any)
2. OCEAN_TOOL create_system_file agent/generated/feature-skill.md
3. OCEAN_TOOL create_skill referencing new doc
4. OCEAN_TOOL done
```

---

## 11. Integration Points

| Component | Integration |
|-----------|-------------|
| AgentPanel | VibeCodePanel toggle + sendWithVibe |
| webAgent | isVibeCodeEligible → runVibeCodeAgent |
| agentContext | vibeCode block in every context |
| skillsStore | addAgentSkill from create_skill |
| extensionsStore | addAgentExtension from create_extension |
| modelStore | addCustomFunction from create_custom_function |
| platform.fs | read/write via getOceanAPI() |
| platform.terminal | ocean-vibe-code-terminal session |

---

## 12. Smoke Test

```bash
npm run check:vibe
```

Validates parser, file existence, nested JSON extraction.

---

## 13. Safety Rules

1. Never write outside workspace
2. Never exfiltrate API keys or tokens in created files
3. Review mode: always wait for user approval on writes/commands
4. Prefer `read_file` before `write_file` on existing files
5. Run tests after modifications when possible
6. Use `done` tool to summarize what was created

---

## 14. Related Documentation

| File | Scope |
|------|-------|
| `agent/vibe-code-skill.md` | **This file** |
| `agent/main-agent-skill.md` | Main agent + vibe toggle |
| `agent/multi-agent-skill.md` | Vibe Coder archetype in teams |
| `agent/tools-skill.md` | MCP/plugin creation context |
| `src/lib/vibeCode/tools.ts` | Runtime prompt appendix |
