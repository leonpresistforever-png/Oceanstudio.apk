---
name: ocean-context-injection
description: Inject files, fastflags, and in-app config into agent context for all providers
scope: both
priority: high
---

# Context Injection — Files, FastFlags, App Config

Agents can **inject arbitrary context** into sessions — workspace files, Roblox-style fastflags, Electron app flags, game configs, and env overlays.

## OCEAN_TOOL commands

| Tool | Purpose |
|------|---------|
| `inject_context_file` | Copy or reference a file into agent context — args: `path`, `label?`, `scope?` (session/agent/workspace/playground), `addToSkills?` |
| `inject_fastflag` | Set boolean/string/number flags for an app — args: `app`, `flags` (object), `path?`, `merge?` (default true) |
| `inject_app_config` | Write app config (json/yaml/env/toml) — args: `app`, `format`, `content` or `config`, `path?`, `injectToContext?` |

## Storage paths

- Injected files: `.ocean/injected/files/`
- FastFlags: `.ocean/injected/fastflags/{app}.json`
- App configs: `.ocean/injected/apps/{app}/config.{ext}`

## When to use

- User asks to "inject this file into context" or "@file" style references
- Roblox, Electron, Unity, or mobile **fastflags** / feature toggles
- Override app behavior without rebuilding (debug menus, beta features)
- Playground voice/agent sessions needing extra skill files mid-run

## Workflow

1. `read_file` the source if needed
2. `inject_context_file` or `inject_fastflag` / `inject_app_config`
3. Context appears in **Installed Skills** block + session runtime on next inference
4. Use `addToSkills: true` to persist as an agent skill for future sessions

## Examples

```
OCEAN_TOOL: {"tool":"inject_context_file","args":{"path":"src/config.ts","label":"App config","scope":"session","addToSkills":true}}

OCEAN_TOOL: {"tool":"inject_fastflag","args":{"app":"roblox","flags":{"FFlagDebugGraphics":true,"DFIntTaskSchedulerTargetFps":60}}}

OCEAN_TOOL: {"tool":"inject_app_config","args":{"app":"electron","format":"json","config":{"enableDevTools":true,"voiceChanger":true},"injectToContext":true}}
```

## Platform notes

- Injected context is serialized by `assembleAgentSystemPrompt()` for **all providers**
- FastFlags merge by default — later injections override same keys
- Never inject secrets into skills without user consent
