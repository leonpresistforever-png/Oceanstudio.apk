# Sandbox MCP — Local Code Execution Servers

Ocean.studio lets users run **stdio MCP sandbox servers on their own hardware** — a direct UI alternative to manual terminal setup. Users get full control over runtime, Docker images, mounts, resource limits, and init commands.

## Where to find it

**MCP Connectors → Sandbox MCP tab** (Electron desktop only)

Web/mobile can view presets but cannot spawn stdio processes.

## Supported compatibility layers

| Layer | Description |
|-------|-------------|
| `stdio-host` | Spawn command directly (npx, uvx, go binary, python) |
| `stdio-docker` | `docker run -i --rm <image>` wrapping MCP stdio |
| `stdio-docker-socket` | Docker + `/var/run/docker.sock` for nested containers |
| `npx` | Node package runner |
| `uvx` | Python uv tool runner |
| `go-install` | Go binaries on PATH |
| `pip-uv` | Python venv / uv project |
| `deno` | Deno secure runtime |
| `e2b-cloud` | E2B remote sandboxes via API key |

## Curated presets

### Sandbox MCP (`pottekkat/sandbox-mcp`)
- **Runtime:** host stdio
- **Command:** `sandbox-mcp --stdio`
- **Requires:** Docker + `go install github.com/pottekkat/sandbox-mcp/cmd/sandbox-mcp@latest`
- **Init:** `--pull` and `--build` optional on connect
- LLMs spin up local Docker containers for isolated code execution

### Node Code Sandbox MCP
- **Host:** `npx -y node-code-sandbox-mcp`
- **Docker:** image `mcp/node-code-sandbox` with socket mount
- **Env:** `FILES_DIR`, `SANDBOX_MEMORY_LIMIT`, `SANDBOX_CPU_LIMIT`
- JS/TS in Docker with on-the-fly npm installs

### MCP Run Python (archived)
- `uvx mcp-run-python stdio` — Pyodide/Deno WASM
- **Archived** — recommend **Pydantic Monty** instead

### Pydantic Monty (recommended Python)
- Secure Rust Python subset, microsecond startup
- `pip install pydantic-monty` or `uvx --from pydantic-monty`
- No full Docker required; use for safe local Python execution

### MCP Code Sandbox (`chrishayuk/mcp-code-sandbox`)
- E2B cloud interpreter via `uv run src/main.py`
- **Env:** `E2B_API_KEY`, `INTERPRETER_TYPE=e2b`
- Clone repo to `~/mcp-code-sandbox` or set custom path

### E2B MCP Server
- `npx -y @e2b/mcp-server` with `E2B_API_KEY`

### Custom Docker / Custom Host
- Full user control: image, cmd, mounts, network, memory, CPU, extra `docker run` args

## User configuration options

Users can configure per instance:

- **Runtime:** host | docker | docker-socket
- **Command & args** (host) or **Docker image & cmd** (container)
- **Workspace mount** — host path → `/workspace` in container
- **Init on connect** — run pull/build commands before spawn
- **Advanced:** memory, CPU, network mode (bridge/host/none/isolated), extra docker args, env vars (KEY=value per line)

Configs persist in `ocean-sandbox-mcp-store` (localStorage).

## Electron API

```javascript
// Check Docker before docker-runtime connects
const docker = await window.ocean.mcp.checkDocker();

// Connect sandbox server (same as catalog MCP)
await window.ocean.mcp.connect({
  id: 'sandbox.<uuid>',
  name: 'My Sandbox',
  transport: 'stdio',
  hosting: 'local',
  runtime: 'docker-socket',  // 'host' | 'docker' | 'docker-socket'
  command: 'npx',            // host only
  args: ['-y', 'node-code-sandbox-mcp'],
  docker: {                  // docker runtimes
    image: 'mcp/node-code-sandbox',
    memory: '512m',
    cpus: '1.0',
    mountDockerSocket: true,
    mounts: [{ host: '~/sandbox-files', container: '/files', mode: 'rw' }],
  },
  initCommands: [
    { command: 'sandbox-mcp', args: ['--pull'], optional: true },
  ],
  env: { FILES_DIR: '/files' },
});

await window.ocean.mcp.disconnect('sandbox.<uuid>');
```

## Agent export

Connected sandbox servers appear in `exportAgentMcpConfig()` with:
- `sandbox: true` flag
- `runtime` and `docker` config when applicable
- Connector IDs prefixed `sandbox.<instanceId>`

## Security notes

- Docker socket mount grants nested container control — use only with trusted MCP servers
- Set `--network none` or isolated mode for untrusted code
- Use read-only rootfs and drop capabilities via extra docker args
- E2B/cloud presets send code to remote sandboxes — requires API keys
- Monty runs restricted Python subset locally without full OS access

## Terminal alternative

Users can still configure MCP manually in Claude Desktop / Cursor / `mcp-config.json`:

```json
{
  "mcpServers": {
    "sandbox-mcp": {
      "command": "sandbox-mcp",
      "args": ["--stdio"]
    }
  }
}
```

Ocean's Sandbox MCP tab generates equivalent configs and spawns processes via `McpManager`.

## When to use which preset

| Need | Preset |
|------|--------|
| Multi-lang Docker sandboxes on host | pottekkat/sandbox-mcp |
| JS/TS + npm in Docker | node-code-sandbox-mcp |
| Safe local Python, no Docker | Pydantic Monty |
| Legacy WASM Python | mcp-run-python (archived) |
| E2B cloud + file ops | chrishayuk/mcp-code-sandbox |
| Any custom image | Custom Docker MCP |
| Any local binary | Custom Host Stdio |
