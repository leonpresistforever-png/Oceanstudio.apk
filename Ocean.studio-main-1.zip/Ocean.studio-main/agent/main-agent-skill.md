---
name: ocean-main-agent
description: Main workspace agent — right sidebar Agent Panel on editor page. NOT Playground. Full coding, terminal, vibe code, multi-agent orchestration.
scope: main
priority: critical
---

# Ocean.studio Main Workspace Agent — Complete Context

> **SCOPE: MAIN WORKSPACE ONLY**
> This skill applies to the **Agent Panel** on the editor workspace (right sidebar).
> For Playground tasks (media, 3D, Active Bot, recording, etc.) read **`agent/playground-agent-skill.md`** instead.
> Never mix Playground runners into main agent responses unless user explicitly asks to open Playground.

---

## 1. What Is the Main Agent?

The **main agent** is the primary coding assistant embedded in the workspace editor:

| Property | Value |
|----------|-------|
| UI location | Right sidebar → **Agent** panel |
| Navigation | `useAppStore.setCenterView('editor')` — user stays on editor |
| Context builder | `buildAgentContext({ skillScope: 'main', ... })` |
| Send API | `window.ocean.agent.send(message, agentContext)` |
| Skills injected | `useSkillsStore.getInstalledForScope('main')` + model config skills |
| Log stream | `useAppStore.agentLogs` — thought/action/command/result events |
| Session | `agentSession` — message count, token estimates, session ID |

### Main Agent vs Playground Agent

| Dimension | Main Agent | Playground Agent |
|-----------|------------|------------------|
| Purpose | Code, debug, refactor, terminal, git, MCP tools | Media gen, 3D, bots, recording, scheduled jobs |
| Entry | Agent Panel send button | Playground page → category → Run |
| Runner | `agent.send` / `runVibeCodeAgent` / multi-agent orchestrator | `runPlaygroundAgentTask`, `runPlaygroundMediaJob` |
| Skill scope | `main` | `playground` |
| Skill file | **This file** + `skill.md` + `tools-skill.md` | `playground-agent-skill.md` |
| Custom prompt area | Agent Panel textarea | Playground prompt per category |
| Workspace required | Yes for filesystem tasks | Yes for agent/research tasks |

**Rule:** If user says "generate an image" or "make a 3D model" → suggest Playground. If user says "fix this bug" or "add a feature to my app" → main agent.

---

## 2. Send Flow (AgentPanel.tsx)

```
User types message + optional attachments
  → processOutgoingPrompt (optional enhancer/compress)
  → recordUserMessage (session stats)
  → buildAgentContext({ workspacePath, activeFile, agentMode, terminalType, skillScope: 'main' })
  → IF multiAgentEnabled AND activeCombo:
       runMultiAgentWorkflow → onAgentSend per member
  → ELSE IF vibeCode.enabled AND workspacePath:
       runVibeCodeAgent (OCEAN_TOOL loop)
  → ELSE:
       window.ocean.agent.send(message, agentContext)
  → Events stream to agentLogs via agent.onEvent
```

### Attachments
```typescript
const files = await window.ocean.upload.selectFiles();
const images = await window.ocean.upload.selectImages();
// Passed as attachments: [{ name, mimeType, content }]
```

### Multi-agent on main panel
When team toggle is on, `runMultiAgentWorkflow` coordinates head + workers. Each worker gets scoped context via `buildMemberContext()` in `memberContext.ts`. Sub-agent sends use `_skipMultiAgentOrchestrator: true`.

---

## 3. buildAgentContext — Full Payload (Main Scope)

```typescript
import { buildAgentContext } from '@/lib/agentContext';

const ctx = await buildAgentContext({
  workspacePath,        // required for FS/terminal
  activeFile,           // Monaco active file path
  agentMode: 'review' | 'auto' | 'bypass',
  terminalType: 'shell' | 'cloud' | 'native',
  skillScope: 'main',   // DEFAULT — only main-scoped skills
  attachments: [...],
});
```

### Context keys (always injected)

| Key | Source | Purpose |
|-----|--------|---------|
| `workspacePath` | appStore | Root for fs.read/write |
| `activeFile` | appStore | Current editor file |
| `agentMode` | workspaceConfig | review/auto/bypass |
| `terminalType` | platform router | shell/cloud/native |
| `modelConfig` | modelStore + skills | Model, temp, skills, tools, webhooks |
| `mcpServers` | mcp manager / registry | Connected MCP tool servers |
| `mcpMeta` | connectedCount, updatedAt | MCP health |
| `pluginTools` | plugin manager | Installed plugin tool defs |
| `providers` | provider registry | Vault configs per provider |
| `providerMeta` | activeProviderIds | Which APIs are live |
| `providerContext` | serialized docs | agent.md, skill.md, all injected docs |
| `platform` | platform.get() | electron/web/android flags |
| `capabilities` | platformCapabilities | Feature flags per platform |
| `multiAgent` | multiAgentStore | Combo, head, workers if enabled |
| `routing` | routingContext | Gateway combos, inference profile |
| `fallback` | fallbackStore | Provider fallback chain |
| `promptEnhancer` | promptEnhancerStore | STT/TTS, wake phrase, compress |
| `extensionHealth` | extensionHealth check | Broken extensions warning |
| `openSourceToolsGuide` | openSourceToolsStore + catalog | Claw Code, Aider, Firecrawl CLI, etc. |
| `agentSession` | agentSession | Session ID, message count, tokens |
| `vibeCode` | vibeCodeStore | enabled, config, serialized protocol |

---

## 4. Terminal Routing (CRITICAL)

**Read `agent/skill.md` section 1 before ANY command.**

```typescript
const platform = await window.ocean.platform.get();
const terminalType = platform.preferredTerminal
  ?? resolvePreferredTerminal(platform);
```

| Platform | terminalType | Backend |
|----------|--------------|---------|
| Electron desktop | `shell` | node-pty PowerShell/Bash on host |
| Web browser | `cloud` | Google Cloud Shell OAuth |
| Android APK | `native` | proot/busybox via Capacitor plugin |
| Dev browser + WS | `shell` | `server/terminal-ws.mjs` on port 3847 |

Agent session ID: **`ocean-agent-terminal`**

```typescript
await window.ocean.terminal.create({ id: 'ocean-agent-terminal', type: terminalType, cwd: workspacePath });
await window.ocean.terminal.write('ocean-agent-terminal', 'npm test\n');
```

### Never do this
- Use `shell` on production website builds (no local shell)
- Use `cloud` on Electron unless user requests Cloud Shell explicitly
- Use `shell` or `cloud` on Android APK — use `native`

---

## 5. Agent Modes

| Mode | Main agent behavior | Vibe Code behavior |
|------|---------------------|-------------------|
| `review` | Destructive shell commands need approval | File writes + terminal need confirm dialog |
| `auto` | Safe commands run; catastrophic paused | Tools apply immediately |
| `bypass` | All commands run | Unrestricted tool execution |

Catastrophic patterns (review always): `rm -rf /`, `mkfs`, `dd of=/dev/`, fork bombs.

---

## 6. Vibe Code (Self-Modification)

**Read `agent/vibe-code-skill.md` in full when Vibe Code toggle is ON.**

Toggle: Agent Panel → **Vibe Code** badge (persisted in `vibeCodeStore`).

When enabled, main agent uses `runVibeCodeAgent` instead of single-shot inference:

```
User message
  → LLM response with OCEAN_TOOL JSON
  → executeVibeTool (read/write/terminal/create_skill/...)
  → feed results back to LLM
  → repeat until done or max iterations
```

### OCEAN_TOOL protocol
```
OCEAN_TOOL: {"tool":"write_file","args":{"path":"src/utils.ts","content":"..."}}
OCEAN_TOOLS: [{"tool":"run_terminal","args":{"command":"npm test"}}]
OCEAN_TOOL: {"tool":"done","args":{"summary":"Added utility and tests pass"}}
```

### Self-modification capabilities
- `create_skill` → `skillsStore.addAgentSkill` + optional `agent/generated/*.md`
- `create_extension` → `extensionsStore.addAgentExtension`
- `create_custom_function` → `modelStore.addCustomFunction`
- `create_plugin_manifest` → `.ocean/plugins/<id>/ocean.plugin.json`
- `create_system_file` → `agent/*.md`, `.ocean/agent/*`
- `create_requirements` → requirements.txt, package.json, Cargo.toml, go.mod
- `install_dependency` → pip/npm/cargo/go via terminal

### Vibe Coder sub-agent (multi-agent)
Archetype `vibecoder` auto-enables OCEAN_TOOL loop even if global toggle is off.
Template: **Vibe Code Team** in Multi Agent → templates.

---

## 7. Multi-Agent (Main Panel Integration)

**Read `agent/multi-agent-skill.md`.**

Enable: Multi Agent page → toggle team → select combo → returns to editor with badge.

Modes:
- **Parallel**: Head plans → workers execute → head synthesizes
- **Collaborative**: All agents same prompt → merged output
- **Fusion**: Identity merge or weighted shard (Multi Agent page)

Per-member config: provider, model, role, task, systemPrompt, params, memory, tools, skills, access (terminal/mcp/plugin).

Context injection: `multiAgent.serializedCombo` appended to each send.

---

## 8. Model Configuration (Right Sidebar)

`useModelStore` → `getAgentPayload()` merged into `modelConfig`:

| Field | Purpose |
|-------|---------|
| selectedModelId | Active model |
| temperature, topP, maxTokens | Generation params |
| thinkingLevel | off/low/medium/high/max |
| strictness | relaxed → maximum |
| customInstructions | Override system prompt |
| skills[] | Inline skill files |
| customFunctions[] | Tool definitions for providers |
| webhooks[] | Outbound event hooks |
| scrapingProvider | firecrawl/puppeteer/playwright/fetch |
| agentTimeoutSec | 30s–15min |
| antiTimeout | 600s extended timeout |

UI: ModelSelector dropdown + gear → ModelConfigPanel.

---

## 9. Prompt Enhancer

`usePromptEnhancerStore` — auto-enhance/compress outgoing prompts:

- `autoEnhance` — style improvement before send
- `autoCompress` — token reduction
- STT/TTS settings for voice
- `wakePhrase` — background assistant (Screen Narrator)

Injected as `promptEnhancer` in context.

---

## 10. Provider Inference

Main agent on **web** uses `webAgent.ts` → `runAgentInference` → provider HTTP APIs.

Fallback chain: `fallbackStore` → alternate providers on retriable errors.

Electron may use `AgentService` + `agent.py` for event orchestration; renderer can also use vibe code path directly.

---

## 11. Filesystem API

```typescript
await window.ocean.fs.readDir(workspacePath);
await window.ocean.fs.readFile(`${workspacePath}/src/App.tsx`);
await window.ocean.fs.writeFile(path, content);
await window.ocean.fs.selectWorkspace();
```

Web dev: `/api/fs/*` via Vite middleware (`npm run dev`).
Electron: real disk via `FileSystemService`.

---

## 12. Preview & Ports

```typescript
const ports = await window.ocean.preview.getPorts();
await window.ocean.preview.registerPort(5173, 'Vite dev');
window.ocean.preview.onPortDetected((port, url) => { /* open preview */ });
```

Cloud Shell ports use GCP proxy URLs — see `cloudShellPreview.ts`.

---

## 13. GitHub Integration

```typescript
await window.ocean.github.authenticate();
await window.ocean.github.importRepo(url, workspacePath);
await window.ocean.github.commitAndPush(workspacePath, 'fix: bug');
```

Terminal fallback: `git clone`, `git push` with OAuth-injected token on Electron.

---

## 14. Skills Store (Main Scope)

Access: Sidebar → Tools → Skills Store

```typescript
useSkillsStore.getInstalledForScope('main')  // scope: main | playground | both
```

- 51+ builtin skills + OSS marketplace
- Upload `skill.md` with YAML frontmatter
- Agent-created via `addAgentSkill` or Vibe Code `create_skill`
- Injected into `modelConfig.skills` at context build time

**Do not install playground-only skills for main coding tasks unless scope is `both`.**

---

## 15. Extensions (IDE Guides)

Access: Sidebar → Tools → Extensions

Extensions inject `extensionsGuide` into context — formatter/linter/language server hints.
Extensions ≠ Plugins ≠ MCP.

Read `agent/extensions-skill.md`.

---

## 16. Agent Event Protocol

Events emitted to `agentLogs`:

| type | UI | When |
|------|-----|------|
| `user` | User bubble | User sent message |
| `thought` | Grey shimmer | Planning, inference |
| `action` | Summary line | Tool start, phase change |
| `command` | `$` pill | Terminal command |
| `result` | Response | Completed output |
| `error` | Red | Failure |
| `status` | Info | Session, prompt enhance |

Electron format: `OCEAN_EVENT:{json}` from agent.py.

---

## 17. Agent Workflows (Cursor-style)

Access: Sidebar → Tools → Agent Workflows

Workflows from `cursorWorkflows.ts`:
- codebase-chat, composer-multi-file, bugbot-review
- design-preview, terminal-agent, debug-systematic

Apply: `applyWorkflow(id, params)` — sets agentMode, merges prompt template.

Read `agent/cursor-workflows-skill.md`.

---

## 18. Routing & Gateway

**Read `agent/routing-skill.md` and `agent/gateway-skill.md`.**

- Ocean proxy `:20128` — OAuth callbacks, `/v1/chat/completions`, Cursor IDE bridge
- Gateway combos — multi-provider routing
- Virtual keys for IDE clients
- `routing.serialized` in every main agent context

---

## 19. Fallback & Health

- `fallback.config` — enabled, triggers, chain order
- `extensionHealth` — reports broken/unconfigured extensions
- `providerMeta.connectedCount` — zero providers → local stub response

---

## 20. Security & Profile

```typescript
useUserProfileStore.getState().security
// confirmDestructiveOps, maskApiKeys, sessionLockMinutes, biometricLock
```

Respect user security prefs before destructive operations.

---

## 21. Main Agent Decision Tree

```
User request
├─ Code edit / debug / refactor / test → MAIN AGENT (this skill)
├─ Terminal / install / build → MAIN AGENT + correct terminalType
├─ Missing tool/skill → VIBE CODE (if enabled) or suggest Skills Store
├─ Multi-step team task → MULTI-AGENT combo
├─ Image / video / 3D / music → PLAYGROUND (playground-agent-skill.md)
├─ Screen control / game bot → PLAYGROUND → Active Bot
├─ Screen recording → PLAYGROUND → Recording
├─ MCP connect / plugin install → Guide to Tools pages, then MAIN AGENT uses tools
└─ Provider OAuth / proxy → Providers page, then MAIN AGENT
```

---

## 22. Key Source Files

| File | Role |
|------|------|
| `src/components/workspace/AgentPanel.tsx` | Main agent UI |
| `src/lib/agentContext.ts` | Context assembly |
| `src/lib/webAgent.ts` | Web inference + vibe loop |
| `src/lib/vibeCode/runner.ts` | OCEAN_TOOL iteration |
| `src/lib/multiAgentOrchestrator.ts` | Team workflows |
| `src/lib/providerInference.ts` | Provider HTTP |
| `src/store/modelStore.ts` | Model config |
| `src/skills/skillsStore.ts` | Skill install/scope |
| `electron/services/agent.ts` | Electron agent events |

---

## 23. Injected Documentation Index (Main Agent Reads)

| File | When to mentally load |
|------|----------------------|
| `agent/agent.md` | Platform architecture overview |
| `agent/skill.md` | Terminal routing, workflow |
| `agent/main-agent-skill.md` | **This file — main agent scope** |
| `agent/tools-skill.md` | MCP, plugins, GitHub APIs |
| `agent/mcp-skill.md` | MCP connectors deep dive |
| `agent/vibe-code-skill.md` | Self-modification protocol |
| `agent/multi-agent-skill.md` | Team orchestration |
| `agent/routing-skill.md` | Provider routing |
| `agent/gateway-skill.md` | Proxy / IDE bridge |
| `agent/extensions-skill.md` | IDE extensions |
| `agent/cursor-workflows-skill.md` | Workflow templates |
| `agent/provider-skill.md` | Provider agent dual role |
| `agent/mcp-config.json` | MCP server routing |
| `agent/model-config.json` | Default model params |

**NOT for main agent default context:** `playground-agent-skill.md` (unless user opens Playground).
