---
name: ocean-playground-agent
description: Playground agents — SEPARATE from main workspace agent. Media, 3D, bots, recording, research, marketplace. skillScope playground.
scope: playground
priority: critical
---

# Ocean.studio Playground Agent — Complete Context

> **SCOPE: PLAYGROUND ONLY**
> This skill applies to tasks run from **Sidebar → Tools → Playground**.
> For coding, debugging, terminal work on the editor → read **`agent/main-agent-skill.md`** instead.
> Playground uses `skillScope: 'playground'` — different skills, different runners, different UI.

---

## 1. Playground vs Main Agent

| | Playground | Main Workspace Agent |
|---|------------|---------------------|
| Page | `setCenterView('playground')` | `setCenterView('editor')` |
| UI | Category sidebar + prompt + custom panels | Right sidebar Agent Panel |
| Context | `buildAgentContext({ skillScope: 'playground' })` | `skillScope: 'main'` |
| Primary runners | `runPlaygroundAgentTask`, `runPlaygroundMediaJob` | `agent.send`, `runVibeCodeAgent` |
| Skills | Playground-scoped + `both` | Main-scoped + `both` |
| Custom panels | ActiveBot, Recording, Narrator, 3D Studio, Skills, Marketplace | None (generic prompt) |
| Log target | `playgroundStore` agentTasks + `addAgentLog` | `appStore.agentLogs` |

**Never answer a Playground media request using only main agent.send without the Playground scope prefix.**

---

## 2. Navigation & Store

```typescript
useAppStore.getState().setCenterView('playground');
usePlaygroundStore.getState().setActiveCategory('media-image');
usePlaygroundStore.getState().setActiveTool('pg-imagen');
usePlaygroundStore.getState().setPrompt('A sunset over mountains');
```

### playgroundStore keys
- `activeCategory`, `activeToolId`, `searchQuery`, `prompt`
- `musicConfig` — genre, tempo, voice, instruments
- `agentTasks[]` — title, prompt, scope, status, result
- `mediaJobs[]` — type, provider, status, outputUrl
- `scheduledTasks[]` — cron-like agent jobs
- `customMarketplaceTools[]` — user-added MCP/plugin entries
- `selected3DSourceId` — 3D Studio source selection

---

## 3. Runners (Core APIs)

### Agent tasks (research, filesystem, custom)
```typescript
import { runPlaygroundAgentTask } from '@/lib/playgroundRunner';

await runPlaygroundAgentTask(
  { title: 'Research', prompt: '...', scope: 'filesystem' | 'apps' | 'web' | 'workspace' | 'custom' },
  workspacePath,
  activeFile
);
```

Scopes auto-prefix prompts:
- `filesystem` → `[Playground — Filesystem Research]`
- `web` → `[Playground — Web Research]`
- `custom` → `[Playground]`

Flags: `playground: { task, scope }`, `_skipMultiAgentOrchestrator: true`

### Media jobs (image, video, 3D, upscale, edit)
```typescript
import { runPlaygroundMediaJob } from '@/lib/playgroundRunner';

await runPlaygroundMediaJob(
  { type: 'image' | 'video' | 'upscale-image' | 'upscale-video' | 'edit-image' | 'text-to-3d' | '2d-to-3d', prompt, provider },
  workspacePath
);
```

### Music
```typescript
import { runMusicGeneration, runBeatResearch } from '@/lib/playgroundRunner';
await runMusicGeneration({ ...musicConfig, lyrics: prompt }, workspacePath);
await runBeatResearch(workspacePath);
```

### Feature-specific runners (lib/)
| Runner | Feature |
|--------|---------|
| `activeBotRunner.ts` | Active Bot, game companion |
| `screenNarratorRunner.ts` | Screen Narrator voice/vision |
| `bannerRunner.ts` | Banner Ads (if installed) |
| `playgroundRunner.ts` | Generic agent + media |

---

## 4. All 16 Categories — Detailed

### 4.1 Screen Narrator (`narrator`)
**Panel:** `ScreenNarratorPanel` — replaces generic prompt

| Tool ID | Name |
|---------|------|
| nar-screen-read | Screen Narrator |
| nar-voice-cmd | Voice Commands |
| nar-live-help | Live Helper |
| nar-translate | Screen Translator |

Features:
- Wake phrase (default `ocean`) via `useWakeWord`
- STT continuous listening
- `describeScreen()` — vision + provider inference
- `runVoiceCommand()` — execute user voice commands
- `narrateAndSpeak()` — TTS response
- Background interval: `config.narratorIntervalSec`
- Store: `narratorStore`

**No generic Playground Run button** — uses panel controls.

---

### 4.2 Active Bot (`active-bot`)
**Panel:** `ActiveBotPanel` — full device control UI

Capabilities:
- Screen capture + vision loop
- Accessibility automation (APK)
- Game Companion with presets (Minecraft, Roblox, Fortnite, WoW, Idle)
- Key bindings, anti-AFK macros, vision interval
- `gameplay.md` auto-learning via `activeBotRunner.ensureGameplayMd`
- Risk acknowledgment required
- Store: `gameCompanionStore`, `activeBotRunner`

**Platform:** Electron full access; APK accessibility; web sandbox limited.

---

### 4.3 Recording (`recording`)
**Panel:** `RecordingPanel`

| Tool | Description |
|------|-------------|
| rec-fullscreen | 4K full screen |
| rec-window | App window capture |
| rec-region | Partial region |
| rec-ultra | Hardware bypass encoding |
| rec-bg | Background recording |

Config: resolution, FPS (up to 165), bitrate, codec, audio source, output path.
Store: `recordingStore`
**Platforms:** Electron + APK only (not web).

---

### 4.4 Agent Tasks (`agents`)
| Tool ID | Purpose |
|---------|---------|
| pg-fs-read | Filesystem research |
| pg-app-scan | App/dependency scan |
| pg-task-assign | Delegate to multi-agent |
| pg-batch-jobs | Sequential job queue |
| pg-watch-folder | Folder monitor |

Run via `handleRun()` → `runTask()` with scope `filesystem`.

---

### 4.5 Research (`research`)
| Tool ID | Purpose |
|---------|---------|
| pg-web-scrape | Deep web scrape |
| pg-web-crawl | Firecrawl site crawl |
| pg-docs-research | Documentation research |
| pg-code-search | Semantic codebase search |
| pg-pdf-parse | PDF extraction |

Scope: `web` or `filesystem`. Firecrawl needs plugin/MCP.

---

### 4.6 Image Gen (`media-image`)
| Provider | Tool ID |
|----------|---------|
| Google Imagen | pg-imagen |
| DALL·E 3 | pg-dalle |
| Flux Pro | pg-flux |
| SDXL | pg-sdxl |
| Midjourney | pg-midjourney |
| Ideogram | pg-ideogram |

Run: `runMedia('image', activeTool.provider)`

API keys: `GOOGLE_API_KEY`, `OPENAI_API_KEY`, `REPLICATE_API_TOKEN`, etc.

---

### 4.7 Video Gen (`media-video`)
| Provider | Tool ID |
|----------|---------|
| Veo 3.1 | pg-veo |
| Google Flow | pg-flow (OAuth) |
| Runway | pg-runway |
| Pika | pg-pika |
| Kling | pg-kling |
| Sora | pg-sora |

Run: `runMedia('video', provider)`
OAuth providers need Ocean proxy running.

---

### 4.8 Upscale (`upscale`)
- pg-upscale-img, pg-upscale-vid
- pg-real-esrgan (plugin), pg-topaz (provider)

Run: `runMedia('upscale-image'|'upscale-video', provider)`

---

### 4.9 Image Editor (`editor`)
- pg-img-edit, pg-bg-remove, pg-inpaint, pg-style-transfer

Run: `runMedia('edit-image', 'google')`

---

### 4.10 3D Studio (`media-3d`)
**Panel:** `ThreeDStudioPanel` — platform-aware source picker

Modes: text-to-3d, image-to-3d, 2d-to-3d

**Electron EXE (local GPU):**
TripoSR, InstantMesh, Shap-E, TRELLIS, Blender, Open3D, etc.
Sources: `ELECTRON_3D_SOURCES` in `threeDStudio.ts`

**Android APK / Web (cloud):**
Meshy, Tripo, Luma, Replicate, Fal, HuggingFace — free tiers
Sources: `ANDROID_CLOUD_3D_SOURCES`

```typescript
runMedia('text-to-3d' | '2d-to-3d', selected3DSourceId ?? 'meshy')
```

Store: `selected3DSourceId` in playgroundStore

---

### 4.11 Text to Speech (`audio-tts`)
- pg-google-tts, pg-elevenlabs (MCP), pg-openai-tts, pg-azure-tts

Run: `runTask('TTS', prompt, 'custom')`

---

### 4.12 Music Studio (`audio-music`)
**Inline config panel** in PlaygroundPage (genre, tempo, voice, drums, guitar, piano, bass, SFX)

| Tool | Action |
|------|--------|
| pg-lyria | Google Lyria generation |
| pg-beat-fetch | Beat research |
| pg-suno | Suno AI |
| pg-udio | Udio |

Providers: google-lyria, elevenlabs, suno, auto
Store: `musicConfig` in playgroundStore

---

### 4.13 Schedule (`schedule`)
- pg-cron, pg-reminder, pg-batch-schedule

UI: datetime picker + `addScheduledTask`
Runner: interval checks `getDueScheduledTasks()` every 30s → `runTask`

---

### 4.14 MCP Store (`mcp`)
**Panel:** `PlaygroundMarketplacePanel kind="mcp"`

- 130+ MCP connectors, feature-tagged
- Custom add: env template, feature tags, install guide
- `playgroundStore.addCustomMarketplaceTool`
- Read `agent/mcp-skill.md`

---

### 4.15 Plugin Store (`plugin`)
**Panel:** `PlaygroundMarketplacePanel kind="plugin"`

- 110+ plugins, feature-tagged
- Custom add with `PLUGIN_ENV_TEMPLATE`
- Formats: `ocean.plugin.json`, mcp.json import

---

### 4.16 Skills Store (`skills`)
**Panel:** `SkillsStorePanel scope="playground"`

- Same catalog as main Skills Store but installs with `scope: 'playground'`
- Only injected when `skillScope: 'playground'` in context
- Upload, agent-create, OSS marketplace search

---

## 5. Playground Page Wiring

`PlaygroundPage.tsx`:
- Categories without generic prompt: `active-bot`, `recording`, `skills`, `narrator`
- Custom panels render instead of textarea
- `handleRun()` routes by `activeCategory`
- Results → `addAgentLog` + `agentTasks` / `mediaJobs`

### Agent stream logging
Playground tasks log to main `agentLogs` via `onLog` callbacks for visibility in editor if user switches back.

---

## 6. Marketplace & Feature Tags

`marketplaceCatalog.ts` — keyword → category mapping for auto-tagging.

`MARKETPLACE_FEATURE_FILTERS` — filter MCP/plugin store by feature.

`FEATURE_ENV_HINTS` in `marketplaceMeta.ts`:
- media-3d: MESHY_API_KEY, TRIPO_API_KEY, REPLICATE_API_TOKEN
- media-image: OPENAI_API_KEY, REPLICATE_API_TOKEN
- media-video: GOOGLE_API_KEY, RUNWAY_API_KEY
- audio-tts: ELEVENLABS_API_KEY, OPENAI_API_KEY
- audio-music: SUNO_API_KEY, GOOGLE_API_KEY

Custom install steps: `CUSTOM_INSTALL_STEPS.mcp` / `.plugin`

---

## 7. Playground Agent Context Build

```typescript
const ctx = await buildAgentContext({
  workspacePath,
  activeFile,
  terminalType,
  skillScope: 'playground',  // CRITICAL
});
// ctx includes playground-scoped skills only (plus 'both')
```

Additional flags on send:
```typescript
{
  playground: { task: title, scope },
  _skipMultiAgentOrchestrator: true,
}
```

---

## 8. Provider Requirements by Category

| Category | Typical keys |
|----------|--------------|
| media-image | GOOGLE_API_KEY, OPENAI_API_KEY, REPLICATE_API_TOKEN |
| media-video | GOOGLE_API_KEY, RUNWAY_API_KEY |
| media-3d | MESHY_API_KEY, TRIPO_API_KEY, HF_TOKEN, FAL_KEY |
| audio-tts | ELEVENLABS_API_KEY, OPENAI_API_KEY |
| audio-music | GOOGLE_API_KEY, SUNO_API_KEY |
| research | FIRECRAWL_API_KEY |
| upscale | REPLICATE_API_TOKEN |
| recording | None (native capture) |
| active-bot | Accessibility permissions (APK) |

Guide user to **Providers** page or Playground tool `envRequirements`.

---

## 9. Platform Matrix (Playground)

| Feature | Electron | Web | Android |
|---------|----------|-----|---------|
| 3D local GPU | ✓ | ✗ | ✗ |
| 3D cloud | ✓ | ✓ | ✓ |
| Recording 4K | ✓ | ✗ | ✓ |
| Active Bot full | ✓ | sandbox | accessibility |
| Screen Narrator | ✓ | ✓ | ✓ |
| MCP stdio | ✓ | ✗ | ✗ |
| MCP SSE | ✓ | ✓ | ✓ |
| Terminal for research | shell | cloud | native |

---

## 10. Playground Decision Tree

```
User in Playground
├─ narrator category → ScreenNarratorPanel (no Run button)
├─ active-bot → ActiveBotPanel
├─ recording → RecordingPanel
├─ media-3d → ThreeDStudioPanel + runMedia text-to-3d
├─ skills → SkillsStorePanel
├─ mcp/plugin → MarketplacePanel
├─ audio-music → music config + runMusicGeneration
├─ agents/research → runPlaygroundAgentTask with scope
├─ media-image/video/upscale/editor → runPlaygroundMediaJob
├─ schedule → addScheduledTask
└─ default → runTask with prompt
```

---

## 11. Specialized Feature Runners

### Active Bot (`activeBotRunner.ts`)
- `startActiveBot`, `stopActiveBot`, `tickGameCompanion`
- Vision: screenshot → provider describe → action
- Writes gameplay learnings to `gameplay.md`

### Screen Narrator (`screenNarratorRunner.ts`)
- `describeScreen`, `runVoiceCommand`, `narrateAndSpeak`
- Uses prompt enhancer TTS config

### Banner Ads (`bannerRunner.ts` — when available)
- `researchProductFromUrl` → `createCreativeBrief` → `generateBannerCampaign`
- 18 IAB sizes, Gemini image gen
- Panel: `BannerAdsPanel`, store: `bannerAdsStore`

---

## 12. Playground Agent Timeout

Same as main: `modelConfig.agentTimeoutSec` (30s–15m), `antiTimeout` for 600s.
Enforced in `providerInference.ts` and Electron `AgentService`.

---

## 13. Logging & Results

```typescript
addAgentLog({
  id, type: 'result', timestamp, summary, detail, status: 'completed'
});
addAgentTask({ title, prompt, scope });
updateAgentTask(id, { status: 'completed', result });
addMediaJob({ type, prompt, provider });
updateMediaJob(id, { status: 'done', outputUrl });
```

---

## 14. Key Source Files

| Path | Role |
|------|------|
| `src/pages/PlaygroundPage.tsx` | Main Playground UI |
| `src/playground/catalog.ts` | All tools + categories |
| `src/playground/types.ts` | Category types, media jobs |
| `src/store/playgroundStore.ts` | Playground state |
| `src/lib/playgroundRunner.ts` | Agent + media runners |
| `src/playground/marketplaceCatalog.ts` | MCP/plugin tagging |
| `src/playground/threeDStudio.ts` | 3D sources |
| `src/playground/recordingTypes.ts` | Recording config |
| `agent/playground-skill.md` | Short reference |
| `agent/playground-agent-skill.md` | **This file** |

---

## 15. Documentation Index (Playground Agent)

| File | Use |
|------|-----|
| `agent/playground-agent-skill.md` | **This file — full Playground context** |
| `agent/playground-skill.md` | Quick category reference |
| `agent/mcp-skill.md` | MCP Store connectors |
| `agent/tools-skill.md` | Plugin vs MCP vs Extension |
| `agent/main-agent-skill.md` | When user leaves Playground for coding |

**Do not load main-agent-skill for pure Playground media tasks.**
